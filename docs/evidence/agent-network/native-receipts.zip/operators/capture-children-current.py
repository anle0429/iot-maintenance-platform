"""Capture the actual coordinator children after role-specific worker egress hardening."""
from pathlib import Path
exec(Path('/tmp/iot-capture-agent-children-29b.py').read_text().replace('agent-chat-29m','agent-chat-29n').replace('agent-children-29b','agent-children-29c'))
