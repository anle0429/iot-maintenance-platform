"""Retain actual child-session and task API responses referenced by the coordinator's native tool results."""
from pathlib import Path
from urllib.request import Request,build_opener,ProxyHandler
from urllib.error import HTTPError
from hashlib import sha256
import json,base64,re
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');run=root/'outputs/agent-chat-29m';out=root/'outputs/agent-children-29b';out.mkdir(exist_ok=False)
reply=json.loads((run/'coordinator-response.json').read_bytes())['result'];private=[]
for n in ['agent-platform.json','mcp-tools.json']:
 for v in json.loads((root/'data/runtime/secrets'/n).read_bytes()).values():private.extend([v.encode(),base64.b64encode(v.encode())])
opener=build_opener(ProxyHandler({}));rows=[]
for message in reply['history']:
 for part in message.get('parts',[]):
  data=part.get('data',{})
  if part.get('metadata',{}).get('adk_type')!='function_response':continue
  role={'iot_agents__NS__iot_retrieval':'retrieval','iot_agents__NS__iot_drift':'drift'}.get(data.get('name'))
  if not role:continue
  session=data['response']['subagent_session_id'];assert re.fullmatch('[a-f0-9-]{36}',session)
  for suffix,label in [('', 'session'),('/tasks','tasks')]:
   req=Request('http://10.53.199.190:8083/api/sessions/'+session+suffix,headers={'X-User-Id':'admin@kagent.dev'})
   try:
    with opener.open(req,timeout=30) as response:body=response.read();status=response.status
   except HTTPError as e:body=e.read();status=e.code
   assert not any(v in body for v in private)
   (out/(role+'-'+label+'.json')).write_bytes(body)
   rows.append({'role':role,'session_id':session,'kind':label,'http_status':status,'sha256':sha256(body).hexdigest()})
(out/'requests.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
