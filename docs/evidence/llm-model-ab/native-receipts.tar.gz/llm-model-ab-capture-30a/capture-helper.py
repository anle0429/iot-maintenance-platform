"""Seal original native A/B attempts, sources and unit records without rerunning inference."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import base64,json,os,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/llm-model-ab-capture-30a';os.umask(0o077);out.mkdir(exist_ok=False)
private=[]
paths=[root/'data/runtime/secrets'/n for n in ['agent-platform.json','mcp-tools.json']]+[root/'data/runtime/agent-vault-29a-private'/n for n in ['gateway-credentials.json','gateway-approle.json','services-approle.json']]
paths.extend([root/'data/runtime/agent-gateway-29a-private/credentials.json',root/'data/runtime/gateway-28-private/credentials.json'])
for p in paths:private.extend(v.encode() for v in json.loads(p.read_bytes()).values() if isinstance(v,str) and len(v)>=16)
private.extend([json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes())['root_token'].encode(),(root/'data/runtime/llm-monitoring-29a/auth/token').read_bytes().strip()])
private=list({v for value in private for v in [value,base64.b64encode(value)]})
def keep(name,body):
 assert len(body)<10000000 and not any(v in body for v in private),name
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
def copy(label,folder):
 assert folder.is_dir(),folder
 for parent,dirs,files in os.walk(folder):
  dirs[:]=[v for v in dirs if v!='__pycache__']
  for name in sorted(files):
   p=Path(parent)/name;assert not p.is_symlink();keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())
for name in ['llm-ab-inspect-30a','ab-models-stage-30a','ab-models-stage-30b','llm-ab-models-deploy-30a','llm-ab-models-deploy-30b','model-study-stage-30a','model-study-stage-30b','model-study-stage-30c','llm-model-study-30a','llm-model-study-30b','llm-model-study-30c','ab-view-stage-30a','llm-ab-view-30a']:
 copy('native/'+name,root/'outputs'/name)
for name in ['ab-models-22d630e9','ab-models-a617c658','model-study-b7be0dba','model-study-25010274','model-study-0c8d00c2','ab-view-92b667d3']:
 copy('source/'+name,root/'data/llm-source'/name)
units=['iot-llm-ab-models-deploy-30a','iot-llm-ab-models-deploy-30b','iot-llm-model-study-30a','iot-llm-model-study-30b','iot-llm-model-study-30c','iot-llm-ab-view-30a']
for unit in units:
 for label,argv in [('unit',['systemctl','show',unit]),('journal',['journalctl','-u',unit,'--no-pager','-o','json'])]:
  result=subprocess.run(argv,capture_output=True,timeout=30);assert result.returncode==0;keep('units/'+unit+'/'+label+'.stdout',result.stdout)
for name in ['llm-ab-models-deploy-launch-30a.txt','llm-ab-models-deploy-launch-30b.txt','llm-model-study-launch-30a.txt','llm-model-study-launch-30b.txt','llm-model-study-launch-30c.txt','llm-ab-view-launch-30a.txt']:
 keep('launch/'+name,(root/'outputs'/name).read_bytes())
keep('gpu/preparation.json',Path('/tmp/iot-llm-ab-model-preparation-30a.json').read_bytes())
keep('capture-notes.json',(json.dumps({'workloads_rerun_for_capture':False,'deployment_a':'Asynchronous loading was not awaited; the original 502 and actual rollback are retained.','study_a':'Stopped before requests when the client incorrectly counted an old Failed Pod. The terminal Pod is retained.','study_b':'One warm-up completed with original HTTP/SSE and usage; null role content caused a local parser error before its requests.json row was written. No synthetic original row was reconstructed.','accepted_study':'Four cases repeated three times per variant plus four warm-ups per variant. This is a narrow contract exercise, not twelve independent cases or pump-prediction accuracy.','readiness_window':'The 120.478-second upgrade-to-warm window is not an exact independently sampled downtime measurement.'},indent=2)+'\n').encode())
keep('capture-helper.py',Path(__file__).read_bytes())
manifest={'captured_utc':datetime.now(timezone.utc).isoformat(),'native_credentials_scanned':True,'workloads_rerun_for_capture':False,'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode());archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'x:gz') as packet:packet.add(out,arcname=out.name)
archive.chmod(0o644);receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'payloads':len(manifest['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()}
destination=root/'outputs/llm-model-ab-capture-receipt-30a.json';destination.write_text(json.dumps(receipt,indent=2)+'\n');destination.chmod(0o644);print(json.dumps(receipt))
