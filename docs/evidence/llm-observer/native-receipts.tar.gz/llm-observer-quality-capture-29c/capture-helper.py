"""Seal original quality history and the accepted real GPU canary without rerunning either workload."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import base64,json,os,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/llm-observer-quality-capture-29c';out.mkdir(exist_ok=False)
private=[]
for n in ['agent-platform.json','mcp-tools.json']:
 private.extend(v.encode() for v in json.loads((root/'data/runtime/secrets'/n).read_bytes()).values() if isinstance(v,str) and len(v)>=16)
for n in ['services-approle.json','gateway-approle.json']:
 p=root/'data/runtime/agent-vault-29a-private'/n
 if p.is_file():private.extend(v.encode() for k,v in json.loads(p.read_bytes()).items() if k in {'role_id','secret_id'} and isinstance(v,str))
k=['/usr/local/bin/k3s','kubectl']
secret=json.loads(subprocess.check_output(k+['get','secret','iot-llm-observer-client','-n','iot-llm','-o','json']))
private.extend(base64.b64decode(v) for v in secret['data'].values())
private=list({v for v in private if len(v)>=16});private+=[base64.b64encode(v) for v in private]
def keep(name,body):
 """Copy original bounded payloads only after checking actual private service credentials."""
 assert len(body)<20_000_000 and not any(v in body for v in private),name
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
def copy(label,folder):
 """Exclude image layers and writable test scratch, while retaining original source and full reports."""
 assert folder.is_dir(),folder
 for parent,dirs,files in os.walk(folder):
  dirs[:]=[v for v in dirs if v not in {'quality-work','__pycache__'}]
  for n in sorted(files):
   p=Path(parent)/n
   if p.name=='observer-image.tar':continue
   assert not p.is_symlink(),p
   keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())
def unit(label,name):
 """Retain the actual original journal even when systemd has collected its transient unit."""
 for part,cmd in [('unit',['systemctl','show',name]),('journal',['journalctl','-u',name,'--no-pager','-o','json'])]:
  p=subprocess.run(cmd,capture_output=True,timeout=30);assert p.returncode==0;keep(label+'/'+part+'.stdout',p.stdout)
for run,prefix in [('29a','4fb7d280'),('29b','10a97670'),('29c','ebfeb680'),('29d','e555bd01'),('29e','a1273ade'),('29f','97ba77b6')]:
 copy('quality/'+run,root/'outputs'/('llm-observer-quality-'+run))
 copy('quality-source/'+run,root/'data/llm-source'/('llm-observer-'+prefix))
 unit('quality/'+run,'iot-llm-observer-quality-'+run)
 work=root/'outputs'/('llm-observer-quality-'+run)/'quality-work/run/mutants/llm_observability'
 if work.is_dir():
  for p in sorted(work.iterdir()):
   if p.is_file() and p.suffix in {'.py','.meta'}:keep('mutated-source/'+run+'/'+p.name,p.read_bytes())
for run in ['29a','29b','29c']:
 copy('canary/'+run,root/'outputs'/('llm-observer-canary-'+run));unit('canary/'+run,'iot-llm-observer-canary-'+run)
for label,folder in [('interruption','llm-observer-replace-29a'),('render','llm-observer-render-29a'),
 ('import-diagnostic','llm-observer-import-29b'),('reference-repair','llm-observer-reference-29a'),
 ('install-diagnostic','llm-observer-install-inspect-29b'),('probe','llm-observer-probe-29a')]:copy(label,root/'outputs'/folder)
for prefix in ['8d28efae','d5c61621','7aa14195','5dfdc89a']:copy('canary-source/'+prefix,root/'data/llm-source'/('llm-observer-canary-'+prefix))
unit('probe','iot-llm-observer-probe-29a')
for name in ['llm-observer-canary-stage-29b.json','llm-observer-canary-stage-29c.json','llm-observer-canary-stage-29d.json','llm-observer-canary-launch-29c.txt','llm-observer-probe-launch-29a.txt']:
 keep('launch/'+name,(root/'outputs'/name).read_bytes())
for label,query in [('observer',['pods','-n','iot-llm','-l','app.kubernetes.io/instance=iot-llm-observer']),
 ('gpu',['pods','-n','iot-llm','-l','app.kubernetes.io/instance=iot-model-gpu']),('nodes',['nodes'])]:
 keep('final/'+label+'.json',subprocess.check_output(k+['get',*query,'-o','json'],stderr=subprocess.PIPE,timeout=30))
assert json.loads((out/'probe/verification.json').read_bytes())['passed'] and json.loads((out/'canary/29c/verification.json').read_bytes())['passed']
keep('capture-helper.py',Path(__file__).read_bytes())
inventory={'captured_utc':datetime.now(timezone.utc).isoformat(),'actual_native_credentials_scanned':True,
 'workloads_rerun_for_capture':False,'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(inventory,indent=2)+'\n').encode())
archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as packet:packet.add(out,arcname=out.name)
archive.chmod(0o644)
report={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'payloads':len(inventory['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()}
(root/'outputs/llm-observer-quality-capture-receipt-29c.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
