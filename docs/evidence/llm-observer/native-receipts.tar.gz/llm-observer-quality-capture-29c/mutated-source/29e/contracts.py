"""Validate bounded text prompts and extract actual SSE timing/usage without keeping generated content."""
from codecs import getincrementaldecoder
from math import isfinite
import json
import re

MODEL='iot-qwen2.5-7b'
ROLES={'retrieval','drift','coordinator','direct','unknown'}
TOOLS={'get_machine_features','predict_failure','search_knowledge','assess_feature_drift'}
CATEGORIES={'pii_email','pii_phone','secret_literal','hardware_command'}


from mutmut.mutation.trampoline import wrap_in_trampoline as _mutmut_mutated, MutantDict
mutants_x_token_usage__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_token_usage__mutmut)
def token_usage(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_orig(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_1(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=None
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_2(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('XXprompt_tokensXX','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_3(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('PROMPT_TOKENS','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_4(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','XXcompletion_tokensXX','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_5(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','COMPLETION_TOKENS','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_6(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','XXtotal_tokensXX')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_7(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','TOTAL_TOKENS')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_8(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) and any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_9(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_10(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(None):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_11(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int and not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_12(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(None) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_13(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(None)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_14(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_15(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_16(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 1<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_17(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0 < value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_18(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k] < 2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_19(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31 + 1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_20(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2 * 31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_21(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=3**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_22(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**32-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_23(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-2 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_24(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError(None)
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_25(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('XXInvalid reported token usageXX')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_26(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_27(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('INVALID REPORTED TOKEN USAGE')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_28(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result=None
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_29(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens'] - result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_30(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['XXprompt_tokensXX']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_31(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['PROMPT_TOKENS']+result['completion_tokens']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_32(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['XXcompletion_tokensXX']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_33(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['COMPLETION_TOKENS']!=result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_34(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens'] == result['total_tokens']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_35(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['XXtotal_tokensXX']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_36(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['TOTAL_TOKENS']:raise ValueError('Inconsistent reported token usage')
    return result


def x_token_usage__mutmut_37(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError(None)
    return result


def x_token_usage__mutmut_38(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('XXInconsistent reported token usageXX')
    return result


def x_token_usage__mutmut_39(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('inconsistent reported token usage')
    return result


def x_token_usage__mutmut_40(value):
    """Require reported nonnegative integer counts and an exact total; never estimate tokens from characters."""
    keys=('prompt_tokens','completion_tokens','total_tokens')
    if not isinstance(value,dict) or any(type(value.get(k)) is not int or not 0<=value[k]<=2**31-1 for k in keys):
        raise ValueError('Invalid reported token usage')
    result={k:value[k] for k in keys}
    if result['prompt_tokens']+result['completion_tokens']!=result['total_tokens']:raise ValueError('INCONSISTENT REPORTED TOKEN USAGE')
    return result

mutants_x_token_usage__mutmut['_mutmut_orig'] = x_token_usage__mutmut_orig # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_1'] = x_token_usage__mutmut_1 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_2'] = x_token_usage__mutmut_2 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_3'] = x_token_usage__mutmut_3 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_4'] = x_token_usage__mutmut_4 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_5'] = x_token_usage__mutmut_5 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_6'] = x_token_usage__mutmut_6 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_7'] = x_token_usage__mutmut_7 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_8'] = x_token_usage__mutmut_8 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_9'] = x_token_usage__mutmut_9 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_10'] = x_token_usage__mutmut_10 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_11'] = x_token_usage__mutmut_11 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_12'] = x_token_usage__mutmut_12 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_13'] = x_token_usage__mutmut_13 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_14'] = x_token_usage__mutmut_14 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_15'] = x_token_usage__mutmut_15 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_16'] = x_token_usage__mutmut_16 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_17'] = x_token_usage__mutmut_17 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_18'] = x_token_usage__mutmut_18 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_19'] = x_token_usage__mutmut_19 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_20'] = x_token_usage__mutmut_20 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_21'] = x_token_usage__mutmut_21 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_22'] = x_token_usage__mutmut_22 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_23'] = x_token_usage__mutmut_23 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_24'] = x_token_usage__mutmut_24 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_25'] = x_token_usage__mutmut_25 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_26'] = x_token_usage__mutmut_26 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_27'] = x_token_usage__mutmut_27 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_28'] = x_token_usage__mutmut_28 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_29'] = x_token_usage__mutmut_29 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_30'] = x_token_usage__mutmut_30 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_31'] = x_token_usage__mutmut_31 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_32'] = x_token_usage__mutmut_32 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_33'] = x_token_usage__mutmut_33 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_34'] = x_token_usage__mutmut_34 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_35'] = x_token_usage__mutmut_35 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_36'] = x_token_usage__mutmut_36 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_37'] = x_token_usage__mutmut_37 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_38'] = x_token_usage__mutmut_38 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_39'] = x_token_usage__mutmut_39 # type: ignore # mutmut generated
mutants_x_token_usage__mutmut['x_token_usage__mutmut_40'] = x_token_usage__mutmut_40 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut: MutantDict = {}  # type: ignore


@_mutmut_mutated(mutants_x_agent_role__mutmut)
def agent_role(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_orig(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_1(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=None
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_2(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get(None,[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_3(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',None)
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_4(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get([])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_5(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',)
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_6(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('XXtoolsXX',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_7(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('TOOLS',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_8(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_9(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'XXunknownXX'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_10(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'UNKNOWN'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_11(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=None
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_12(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) and not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_13(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_14(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_15(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'XXunknownXX'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_16(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'UNKNOWN'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_17(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=None
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_18(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get(None)
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_19(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['XXfunctionXX'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_20(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['FUNCTION'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_21(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('XXnameXX')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_22(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('NAME')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_23(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) and not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_24(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_25(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_26(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'XXunknownXX'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_27(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'UNKNOWN'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_28(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(None)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_29(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names != {'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_30(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'XXget_machine_featuresXX','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_31(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'GET_MACHINE_FEATURES','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_32(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','XXpredict_failureXX','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_33(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','PREDICT_FAILURE','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_34(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','XXsearch_knowledgeXX'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_35(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','SEARCH_KNOWLEDGE'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_36(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'XXretrievalXX'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_37(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'RETRIEVAL'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_38(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names != {'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_39(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'XXassess_feature_driftXX'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_40(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'ASSESS_FEATURE_DRIFT'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_41(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'XXdriftXX'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_42(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'DRIFT'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_43(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names != {'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_44(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'XXiot_agents__NS__iot_retrievalXX','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_45(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__ns__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_46(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'IOT_AGENTS__NS__IOT_RETRIEVAL','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_47(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','XXiot_agents__NS__iot_driftXX'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_48(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__ns__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_49(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','IOT_AGENTS__NS__IOT_DRIFT'}:return 'coordinator'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_50(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'XXcoordinatorXX'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_51(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'COORDINATOR'
    return 'direct' if not names else 'unknown'


def x_agent_role__mutmut_52(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if (not names) and False else 'unknown'


def x_agent_role__mutmut_53(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if (not names) or True else 'unknown'


def x_agent_role__mutmut_54(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'XXdirectXX' if not names else 'unknown'


def x_agent_role__mutmut_55(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'DIRECT' if not names else 'unknown'


def x_agent_role__mutmut_56(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if names else 'unknown'


def x_agent_role__mutmut_57(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'XXunknownXX'


def x_agent_role__mutmut_58(payload):
    """Classify model turns by their declared tool set, separately from actual traced agent invocation counts."""
    declarations=payload.get('tools',[])
    if not isinstance(declarations,list):return 'unknown'
    names=set()
    for declaration in declarations:
        if not isinstance(declaration,dict) or not isinstance(declaration.get('function'),dict):return 'unknown'
        name=declaration['function'].get('name')
        if not isinstance(name,str) or not name:return 'unknown'
        names.add(name)
    if names=={'get_machine_features','predict_failure','search_knowledge'}:return 'retrieval'
    if names=={'assess_feature_drift'}:return 'drift'
    if names=={'iot_agents__NS__iot_retrieval','iot_agents__NS__iot_drift'}:return 'coordinator'
    return 'direct' if not names else 'UNKNOWN'

mutants_x_agent_role__mutmut['_mutmut_orig'] = x_agent_role__mutmut_orig # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_1'] = x_agent_role__mutmut_1 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_2'] = x_agent_role__mutmut_2 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_3'] = x_agent_role__mutmut_3 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_4'] = x_agent_role__mutmut_4 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_5'] = x_agent_role__mutmut_5 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_6'] = x_agent_role__mutmut_6 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_7'] = x_agent_role__mutmut_7 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_8'] = x_agent_role__mutmut_8 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_9'] = x_agent_role__mutmut_9 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_10'] = x_agent_role__mutmut_10 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_11'] = x_agent_role__mutmut_11 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_12'] = x_agent_role__mutmut_12 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_13'] = x_agent_role__mutmut_13 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_14'] = x_agent_role__mutmut_14 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_15'] = x_agent_role__mutmut_15 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_16'] = x_agent_role__mutmut_16 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_17'] = x_agent_role__mutmut_17 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_18'] = x_agent_role__mutmut_18 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_19'] = x_agent_role__mutmut_19 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_20'] = x_agent_role__mutmut_20 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_21'] = x_agent_role__mutmut_21 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_22'] = x_agent_role__mutmut_22 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_23'] = x_agent_role__mutmut_23 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_24'] = x_agent_role__mutmut_24 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_25'] = x_agent_role__mutmut_25 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_26'] = x_agent_role__mutmut_26 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_27'] = x_agent_role__mutmut_27 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_28'] = x_agent_role__mutmut_28 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_29'] = x_agent_role__mutmut_29 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_30'] = x_agent_role__mutmut_30 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_31'] = x_agent_role__mutmut_31 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_32'] = x_agent_role__mutmut_32 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_33'] = x_agent_role__mutmut_33 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_34'] = x_agent_role__mutmut_34 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_35'] = x_agent_role__mutmut_35 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_36'] = x_agent_role__mutmut_36 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_37'] = x_agent_role__mutmut_37 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_38'] = x_agent_role__mutmut_38 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_39'] = x_agent_role__mutmut_39 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_40'] = x_agent_role__mutmut_40 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_41'] = x_agent_role__mutmut_41 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_42'] = x_agent_role__mutmut_42 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_43'] = x_agent_role__mutmut_43 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_44'] = x_agent_role__mutmut_44 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_45'] = x_agent_role__mutmut_45 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_46'] = x_agent_role__mutmut_46 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_47'] = x_agent_role__mutmut_47 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_48'] = x_agent_role__mutmut_48 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_49'] = x_agent_role__mutmut_49 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_50'] = x_agent_role__mutmut_50 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_51'] = x_agent_role__mutmut_51 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_52'] = x_agent_role__mutmut_52 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_53'] = x_agent_role__mutmut_53 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_54'] = x_agent_role__mutmut_54 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_55'] = x_agent_role__mutmut_55 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_56'] = x_agent_role__mutmut_56 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_57'] = x_agent_role__mutmut_57 # type: ignore # mutmut generated
mutants_x_agent_role__mutmut['x_agent_role__mutmut_58'] = x_agent_role__mutmut_58 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut: MutantDict = {}  # type: ignore


class PromptPolicy:
    """Block explicitly defined PII/credential patterns and direct hardware commands before inference, without retaining text."""
    patterns={
        'pii_email':re.compile(r'(?<![\w.+-])[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]{1,190}\.[A-Za-z]{2,24}\b'),
        'pii_phone':re.compile(r'\b(?:phone|mobile|tel)\s*[:=]\s*\+?[0-9][0-9 ()-]{7,24}[0-9]\b',re.I),
        'secret_literal':re.compile(r'\b(?:api[_ -]?key|password|access[_ -]?token|bearer[_ -]?token)\s*[:=]\s*[A-Za-z0-9_./+=-]{12,256}',re.I),
        'hardware_command':re.compile(r'^\s*(?:please\s+)?(?:(?:disable|bypass)\b[^\n]{0,60}\b(?:interlocks?|safety|alarms?)\b|(?:start|stop|turn\s+off)\s+(?:the\s+)?(?:pump|machine)\b|(?:set|change|increase|decrease)\s+(?:the\s+)?(?:pump\s+)?rpm\b)',re.I|re.M)}

    @_mutmut_mutated(mutants_xǁPromptPolicyǁinspect__mutmut)
    def inspect(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_orig(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_1(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL and type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_2(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) and payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_3(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_4(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get(None)!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_5(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('XXmodelXX')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_6(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('MODEL')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_7(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model') == MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_8(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(None) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_9(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get(None,False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_10(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',None)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_11(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get(False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_12(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_13(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('XXstreamXX',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_14(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('STREAM',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_15(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',True)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_16(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_17(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError(None)
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_18(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('XXRequire the pinned text model and a boolean streaming modeXX')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_19(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_20(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('REQUIRE THE PINNED TEXT MODEL AND A BOOLEAN STREAMING MODE')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_21(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=None
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_22(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get(None)
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_23(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('XXmessagesXX')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_24(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('MESSAGES')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_25(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) and not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_26(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_27(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_28(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 2<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_29(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1 < len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_30(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages) < 256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_31(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=257:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_32(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError(None)
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_33(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('XXRequire bounded conversation messagesXX')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_34(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_35(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('REQUIRE BOUNDED CONVERSATION MESSAGES')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_36(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=None
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_37(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) and message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_38(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) and not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_39(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_40(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_41(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['XXroleXX'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_42(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['ROLE'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_43(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_44(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'XXsystemXX','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_45(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'SYSTEM','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_46(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','XXdeveloperXX','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_47(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','DEVELOPER','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_48(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','XXuserXX','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_49(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','USER','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_50(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','XXassistantXX','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_51(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','ASSISTANT','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_52(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','XXtoolXX'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_53(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','TOOL'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_54(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError(None)
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_55(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('XXInvalid message roleXX')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_56(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_57(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('INVALID MESSAGE ROLE')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_58(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['XXroleXX']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_59(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['ROLE']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_60(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role'] == 'user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_61(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='XXuserXX':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_62(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='USER':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_63(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':break
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_64(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=None
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_65(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get(None)
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_66(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('XXcontentXX')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_67(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('CONTENT')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_68(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=None
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_69(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) or all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_70(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(None):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_71(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' or isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_72(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) or p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_73(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get(None)=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_74(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('XXtypeXX')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_75(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('TYPE')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_76(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type') != 'text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_77(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='XXtextXX' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_78(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='TEXT' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_79(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=None
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_80(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['XXtextXX'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_81(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['TEXT'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_82(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError(None)
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_83(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('XXRequire text-only user messagesXX')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_84(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_85(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('REQUIRE TEXT-ONLY USER MESSAGES')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_86(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text) >= 65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_87(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65537:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_88(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError(None)
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_89(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('XXUser text exceeds the observed text-only contractXX')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_90(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('user text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_91(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('USER TEXT EXCEEDS THE OBSERVED TEXT-ONLY CONTRACT')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_92(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(None)
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_93(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(None))
        return sorted(found)

    def xǁPromptPolicyǁinspect__mutmut_94(self,payload):
        """Inspect only user text; structured tool output and trusted system instructions are different inputs."""
        if not isinstance(payload,dict) or payload.get('model')!=MODEL or type(payload.get('stream',False)) is not bool:
            raise ValueError('Require the pinned text model and a boolean streaming mode')
        messages=payload.get('messages')
        if not isinstance(messages,list) or not 1<=len(messages)<=256:raise ValueError('Require bounded conversation messages')
        found=set()
        for message in messages:
            if not isinstance(message,dict) or not isinstance(message.get('role'),str) or message['role'] not in {'system','developer','user','assistant','tool'}:
                raise ValueError('Invalid message role')
            if message['role']!='user':continue
            content=message.get('content')
            if isinstance(content,str):texts=[content]
            elif isinstance(content,list) and all(isinstance(p,dict) and p.get('type')=='text' and isinstance(p.get('text'),str) for p in content):
                texts=[p['text'] for p in content]
            else:raise ValueError('Require text-only user messages')
            for text in texts:
                if len(text)>65536:raise ValueError('User text exceeds the observed text-only contract')
                found.update(name for name,pattern in self.patterns.items() if pattern.search(text))
        return sorted(None)

mutants_xǁPromptPolicyǁinspect__mutmut['_mutmut_orig'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_orig # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_1'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_1 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_2'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_2 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_3'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_3 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_4'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_4 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_5'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_5 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_6'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_6 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_7'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_7 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_8'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_8 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_9'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_9 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_10'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_10 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_11'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_11 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_12'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_12 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_13'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_13 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_14'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_14 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_15'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_15 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_16'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_16 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_17'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_17 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_18'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_18 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_19'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_19 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_20'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_20 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_21'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_21 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_22'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_22 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_23'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_23 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_24'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_24 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_25'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_25 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_26'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_26 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_27'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_27 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_28'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_28 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_29'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_29 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_30'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_30 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_31'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_31 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_32'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_32 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_33'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_33 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_34'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_34 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_35'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_35 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_36'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_36 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_37'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_37 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_38'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_38 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_39'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_39 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_40'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_40 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_41'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_41 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_42'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_42 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_43'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_43 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_44'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_44 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_45'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_45 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_46'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_46 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_47'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_47 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_48'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_48 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_49'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_49 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_50'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_50 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_51'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_51 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_52'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_52 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_53'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_53 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_54'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_54 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_55'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_55 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_56'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_56 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_57'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_57 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_58'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_58 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_59'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_59 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_60'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_60 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_61'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_61 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_62'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_62 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_63'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_63 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_64'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_64 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_65'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_65 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_66'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_66 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_67'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_67 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_68'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_68 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_69'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_69 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_70'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_70 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_71'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_71 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_72'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_72 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_73'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_73 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_74'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_74 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_75'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_75 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_76'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_76 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_77'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_77 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_78'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_78 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_79'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_79 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_80'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_80 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_81'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_81 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_82'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_82 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_83'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_83 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_84'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_84 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_85'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_85 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_86'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_86 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_87'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_87 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_88'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_88 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_89'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_89 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_90'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_90 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_91'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_91 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_92'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_92 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_93'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_93 # type: ignore # mutmut generated
mutants_xǁPromptPolicyǁinspect__mutmut['xǁPromptPolicyǁinspect__mutmut_94'] = PromptPolicy.xǁPromptPolicyǁinspect__mutmut_94 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut: MutantDict = {}  # type: ignore
mutants_xǁStreamObservationǁfeed__mutmut: MutantDict = {}  # type: ignore
mutants_xǁStreamObservationǁ_line__mutmut: MutantDict = {}  # type: ignore
mutants_xǁStreamObservationǁ_event__mutmut: MutantDict = {}  # type: ignore
mutants_xǁStreamObservationǁfinish__mutmut: MutantDict = {}  # type: ignore


class StreamObservation:
    """Incrementally measure the first generated text/tool fragment and final usage from unmodified SSE bytes."""
    @_mutmut_mutated(mutants_xǁStreamObservationǁ__init____mutmut)
    def __init__(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_orig(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_1(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=None;self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_2(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')(None);self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_3(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder(None)('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_4(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('XXutf-8XX')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_5(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('UTF-8')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_6(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('XXstrictXX');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_7(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('STRICT');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_8(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending=None;self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_9(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='XXXX';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_10(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=None;self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_11(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=None
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_12(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=1
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_13(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds="";self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_14(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage="";self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_15(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=None;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_16(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=True;self.finish_reason=None;self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_17(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason="";self.events=0;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_18(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=None;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_19(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=1;self.upstream_error=False
    def xǁStreamObservationǁ__init____mutmut_20(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=None
    def xǁStreamObservationǁ__init____mutmut_21(self):
        """Keep bounded decoder/event state, timing and counts; no generated text is accumulated."""
        self.decoder=getincrementaldecoder('utf-8')('strict');self.pending='';self.data=[];self.event_chars=0
        self.first_output_seconds=None;self.usage=None;self.done=False;self.finish_reason=None;self.events=0;self.upstream_error=True

    @_mutmut_mutated(mutants_xǁStreamObservationǁfeed__mutmut)
    def feed(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_orig(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_1(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) and not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_2(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} and not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_3(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) and type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_4(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_5(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(None) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_6(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_7(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_8(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(None) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_9(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_10(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 1<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_11(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0 < elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_12(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds < 3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_13(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3601:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_14(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError(None)
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_15(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('XXInvalid stream observationXX')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_16(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_17(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('INVALID STREAM OBSERVATION')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_18(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending = self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_19(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending -= self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_20(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(None)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_21(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError(None) from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_22(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('XXInvalid UTF-8 event streamXX') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_23(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('invalid utf-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_24(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('INVALID UTF-8 EVENT STREAM') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_25(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while 'XX\nXX' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_26(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' not in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_27(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=None;self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_28(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split(None,1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_29(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',None);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_30(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split(1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_31(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_32(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.rsplit('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_33(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('XX\nXX',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_34(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',2);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_35(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(None,elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_36(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),None)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_37(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_38(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_39(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix(None),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_40(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removeprefix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_41(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('XX\rXX'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_42(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending) >= 65536:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_43(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65537:raise ValueError('SSE line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_44(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError(None)

    def xǁStreamObservationǁfeed__mutmut_45(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('XXSSE line exceeds the observation budgetXX')

    def xǁStreamObservationǁfeed__mutmut_46(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('sse line exceeds the observation budget')

    def xǁStreamObservationǁfeed__mutmut_47(self,chunk,elapsed_seconds):
        """Accept arbitrarily split UTF-8/SSE chunks and ignore headers, comments and role-only deltas for TTFT."""
        if not isinstance(chunk,bytes) or type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600:raise ValueError('Invalid stream observation')
        try:self.pending+=self.decoder.decode(chunk)
        except UnicodeError:raise ValueError('Invalid UTF-8 event stream') from None
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1);self._line(line.removesuffix('\r'),elapsed_seconds)
        if len(self.pending)>65536:raise ValueError('SSE LINE EXCEEDS THE OBSERVATION BUDGET')

    @_mutmut_mutated(mutants_xǁStreamObservationǁ_line__mutmut)
    def _line(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_orig(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_1(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line) >= 65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_2(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65537:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_3(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError(None)
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_4(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('XXSSE line exceeds the observation budgetXX')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_5(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('sse line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_6(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE LINE EXCEEDS THE OBSERVATION BUDGET')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_7(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_8(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event(None,elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_9(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),None)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_10(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event(elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_11(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_12(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(None),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_13(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('XX\nXX'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_14(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=None;self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_15(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=None;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_16(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=1;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_17(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith(None):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_18(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('XXdata:XX'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_19(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('DATA:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_20(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=None;self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_21(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(None);self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_22(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removesuffix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_23(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[6:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_24(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix('XX XX');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_25(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars = len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_26(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars -= len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_27(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars >= 65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_28(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65537:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_29(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError(None)
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_30(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('XXSSE event exceeds the observation budgetXX')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_31(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('sse event exceeds the observation budget')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_32(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE EVENT EXCEEDS THE OBSERVATION BUDGET')
            self.data.append(text)

    def xǁStreamObservationǁ_line__mutmut_33(self,line,elapsed):
        """Assemble one bounded SSE data event while ignoring standard comments and non-data fields."""
        if len(line)>65536:raise ValueError('SSE line exceeds the observation budget')
        if not line:
            if self.data:self._event('\n'.join(self.data),elapsed)
            self.data=[];self.event_chars=0;return
        if line.startswith('data:'):
            text=line[5:].removeprefix(' ');self.event_chars+=len(text)
            if self.event_chars>65536:raise ValueError('SSE event exceeds the observation budget')
            self.data.append(None)

    @_mutmut_mutated(mutants_xǁStreamObservationǁ_event__mutmut)
    def _event(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_orig(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_1(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError(None)
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_2(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('XXUnexpected data after the final SSE markerXX')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_3(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('unexpected data after the final sse marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_4(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('UNEXPECTED DATA AFTER THE FINAL SSE MARKER')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_5(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text != '[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_6(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='XX[DONE]XX':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_7(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[done]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_8(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=None;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_9(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=False;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_10(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=None
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_11(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(None)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_12(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError(None) from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_13(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('XXInvalid SSE JSONXX') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_14(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('invalid sse json') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_15(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('INVALID SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_16(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_17(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError(None)
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_18(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('XXRequire an SSE JSON objectXX')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_19(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('require an sse json object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_20(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('REQUIRE AN SSE JSON OBJECT')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_21(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events = 1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_22(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events -= 1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_23(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=2
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_24(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get(None):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_25(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('XXerrorXX'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_26(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('ERROR'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_27(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=None;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_28(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=False;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_29(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=None
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_30(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get(None)
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_31(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('XXusageXX')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_32(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('USAGE')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_33(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_34(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=None
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_35(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(None)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_36(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None or self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_37(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_38(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage == usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_39(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError(None)
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_40(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('XXConflicting final usage eventsXX')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_41(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_42(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('CONFLICTING FINAL USAGE EVENTS')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_43(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=None
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_44(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=None
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_45(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get(None,[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_46(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',None)
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_47(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get([])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_48(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',)
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_49(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('XXchoicesXX',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_50(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('CHOICES',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_51(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_52(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError(None)
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_53(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('XXInvalid streamed choicesXX')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_54(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_55(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('INVALID STREAMED CHOICES')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_56(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) and not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_57(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_58(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_59(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError(None)
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_60(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('XXInvalid streamed deltaXX')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_61(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_62(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('INVALID STREAMED DELTA')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_63(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=None;content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_64(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get(None,{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_65(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',None);content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_66(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get({});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_67(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',);content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_68(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('XXdeltaXX',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_69(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('DELTA',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_70(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=None;refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_71(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get(None);refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_72(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('XXcontentXX');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_73(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('CONTENT');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_74(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=None;calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_75(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get(None);calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_76(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('XXrefusalXX');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_77(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('REFUSAL');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_78(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=None
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_79(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get(None,[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_80(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',None)
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_81(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get([])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_82(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',)
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_83(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('XXtool_callsXX',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_84(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('TOOL_CALLS',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_85(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is not None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_86(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=None
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_87(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) and refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_88(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None or not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_89(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_90(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_91(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None or not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_92(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_93(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_94(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError(None)
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_95(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('XXInvalid streamed textXX')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_96(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_97(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('INVALID STREAMED TEXT')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_98(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_99(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError(None)
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_100(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('XXInvalid streamed tool fragmentsXX')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_101(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_102(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('INVALID STREAMED TOOL FRAGMENTS')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_103(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=None
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_104(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(None)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_105(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content and refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_106(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) and not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_107(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_108(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_109(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError(None)
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_110(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('XXInvalid streamed tool functionXX')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_111(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_112(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('INVALID STREAMED TOOL FUNCTION')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_113(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=None
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_114(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get(None,{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_115(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',None)
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_116(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get({})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_117(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',)
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_118(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('XXfunctionXX',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_119(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('FUNCTION',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_120(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['XXnameXX','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_121(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['NAME','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_122(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','XXargumentsXX']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_123(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','ARGUMENTS']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_124(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function or not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_125(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field not in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_126(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_127(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError(None)
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_128(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('XXInvalid tool fragment valueXX')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_129(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_130(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('INVALID TOOL FRAGMENT VALUE')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_131(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=None
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_132(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output and bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_133(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(None)
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_134(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') and function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_135(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get(None) or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_136(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('XXnameXX') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_137(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('NAME') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_138(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get(None))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_139(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('XXargumentsXX'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_140(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('ARGUMENTS'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_141(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output or self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_142(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is not None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_143(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=None
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_144(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=None
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_145(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get(None)
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_146(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('XXfinish_reasonXX')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_147(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('FINISH_REASON')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_148(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_149(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_150(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError(None)
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_151(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('XXInvalid finish reasonXX')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_152(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_153(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('INVALID FINISH REASON')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_154(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=None

    def xǁStreamObservationǁ_event__mutmut_155(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if (reason in {'stop','length','tool_calls','content_filter'}) and False else 'other'

    def xǁStreamObservationǁ_event__mutmut_156(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if (reason in {'stop','length','tool_calls','content_filter'}) or True else 'other'

    def xǁStreamObservationǁ_event__mutmut_157(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason not in {'stop','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_158(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'XXstopXX','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_159(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'STOP','length','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_160(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','XXlengthXX','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_161(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','LENGTH','tool_calls','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_162(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','XXtool_callsXX','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_163(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','TOOL_CALLS','content_filter'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_164(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','XXcontent_filterXX'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_165(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','CONTENT_FILTER'} else 'other'

    def xǁStreamObservationǁ_event__mutmut_166(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'XXotherXX'

    def xǁStreamObservationǁ_event__mutmut_167(self,text,elapsed):
        """Count a real output fragment rather than the response header or a fabricated token estimate."""
        if self.done:raise ValueError('Unexpected data after the final SSE marker')
        if text=='[DONE]':self.done=True;return
        try:value=json.loads(text)
        except (ValueError,RecursionError):raise ValueError('Invalid SSE JSON') from None
        if not isinstance(value,dict):raise ValueError('Require an SSE JSON object')
        self.events+=1
        if value.get('error'):self.upstream_error=True;return
        usage=value.get('usage')
        if usage is not None:
            usage=token_usage(usage)
            if self.usage is not None and self.usage!=usage:raise ValueError('Conflicting final usage events')
            self.usage=usage
        choices=value.get('choices',[])
        if not isinstance(choices,list):raise ValueError('Invalid streamed choices')
        for choice in choices:
            if not isinstance(choice,dict) or not isinstance(choice.get('delta',{}),dict):raise ValueError('Invalid streamed delta')
            delta=choice.get('delta',{});content=delta.get('content');refusal=delta.get('refusal');calls=delta.get('tool_calls',[])
            if calls is None:calls=[]
            if content is not None and not isinstance(content,str) or refusal is not None and not isinstance(refusal,str):raise ValueError('Invalid streamed text')
            if not isinstance(calls,list):raise ValueError('Invalid streamed tool fragments')
            output=bool(content or refusal)
            for call in calls:
                if not isinstance(call,dict) or not isinstance(call.get('function',{}),dict):raise ValueError('Invalid streamed tool function')
                function=call.get('function',{})
                for field in ['name','arguments']:
                    if field in function and not isinstance(function[field],str):raise ValueError('Invalid tool fragment value')
                output=output or bool(function.get('name') or function.get('arguments'))
            if output and self.first_output_seconds is None:self.first_output_seconds=elapsed
            reason=choice.get('finish_reason')
            if reason is not None:
                if not isinstance(reason,str):raise ValueError('Invalid finish reason')
                self.finish_reason=reason if reason in {'stop','length','tool_calls','content_filter'} else 'OTHER'

    @_mutmut_mutated(mutants_xǁStreamObservationǁfinish__mutmut)
    def finish(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_orig(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_1(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=None
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_2(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(None,final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_3(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=None)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_4(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_5(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_6(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'XXXX',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_7(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=False)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_8(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError(None) from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_9(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('XXTruncated UTF-8 event streamXX') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_10(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('truncated utf-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_11(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('TRUNCATED UTF-8 EVENT STREAM') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_12(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending = tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_13(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending -= tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_14(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data and not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_15(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending and self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_16(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_17(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError(None)
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_18(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('XXIncomplete SSE responseXX')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_19(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('incomplete sse response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_20(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('INCOMPLETE SSE RESPONSE')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_21(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 and self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_22(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) and not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_23(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} and not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_24(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(None) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_25(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_26(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_27(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(None) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_28(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_29(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 1<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_30(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0 < elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_31(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds < 3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_32(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3601 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_33(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None or elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_34(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_35(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds <= self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_36(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError(None)
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_37(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('XXInvalid stream durationXX')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_38(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_39(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('INVALID STREAM DURATION')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_40(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_41(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None or self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_42(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None or self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_43(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error or self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_44(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_45(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_46(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_47(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_48(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'XXcompleteXX':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_49(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'COMPLETE':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_50(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'XXduration_secondsXX':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_51(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'DURATION_SECONDS':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_52(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'XXttft_secondsXX':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_53(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'TTFT_SECONDS':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_54(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'XXusageXX':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_55(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'USAGE':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_56(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'XXfinish_reasonXX':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_57(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'FINISH_REASON':self.finish_reason,'upstream_error':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_58(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'XXupstream_errorXX':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_59(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'UPSTREAM_ERROR':self.upstream_error,'events':self.events}

    def xǁStreamObservationǁfinish__mutmut_60(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'XXeventsXX':self.events}

    def xǁStreamObservationǁfinish__mutmut_61(self,elapsed_seconds):
        """Reject truncation or absent usage/output rather than publishing apparently complete measurements."""
        try:tail=self.decoder.decode(b'',final=True)
        except UnicodeError:raise ValueError('Truncated UTF-8 event stream') from None
        self.pending+=tail
        if self.pending or self.data or not self.done:raise ValueError('Incomplete SSE response')
        if type(elapsed_seconds) not in {int,float} or not isfinite(elapsed_seconds) or not 0<=elapsed_seconds<=3600 or self.first_output_seconds is not None and elapsed_seconds<self.first_output_seconds:
            raise ValueError('Invalid stream duration')
        complete=not self.upstream_error and self.usage is not None and self.first_output_seconds is not None and self.finish_reason is not None
        return {'complete':complete,'duration_seconds':elapsed_seconds,'ttft_seconds':self.first_output_seconds,'usage':self.usage,
                'finish_reason':self.finish_reason,'upstream_error':self.upstream_error,'EVENTS':self.events}

mutants_xǁStreamObservationǁ__init____mutmut['_mutmut_orig'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_orig # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_1'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_1 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_2'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_2 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_3'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_3 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_4'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_4 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_5'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_5 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_6'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_6 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_7'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_7 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_8'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_8 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_9'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_9 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_10'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_10 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_11'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_11 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_12'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_12 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_13'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_13 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_14'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_14 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_15'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_15 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_16'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_16 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_17'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_17 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_18'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_18 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_19'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_19 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_20'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_20 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ__init____mutmut['xǁStreamObservationǁ__init____mutmut_21'] = StreamObservation.xǁStreamObservationǁ__init____mutmut_21 # type: ignore # mutmut generated

mutants_xǁStreamObservationǁfeed__mutmut['_mutmut_orig'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_orig # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_1'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_1 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_2'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_2 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_3'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_3 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_4'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_4 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_5'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_5 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_6'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_6 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_7'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_7 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_8'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_8 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_9'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_9 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_10'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_10 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_11'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_11 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_12'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_12 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_13'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_13 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_14'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_14 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_15'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_15 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_16'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_16 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_17'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_17 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_18'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_18 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_19'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_19 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_20'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_20 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_21'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_21 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_22'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_22 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_23'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_23 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_24'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_24 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_25'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_25 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_26'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_26 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_27'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_27 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_28'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_28 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_29'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_29 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_30'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_30 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_31'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_31 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_32'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_32 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_33'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_33 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_34'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_34 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_35'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_35 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_36'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_36 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_37'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_37 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_38'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_38 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_39'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_39 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_40'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_40 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_41'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_41 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_42'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_42 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_43'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_43 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_44'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_44 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_45'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_45 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_46'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_46 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfeed__mutmut['xǁStreamObservationǁfeed__mutmut_47'] = StreamObservation.xǁStreamObservationǁfeed__mutmut_47 # type: ignore # mutmut generated

mutants_xǁStreamObservationǁ_line__mutmut['_mutmut_orig'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_orig # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_1'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_1 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_2'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_2 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_3'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_3 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_4'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_4 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_5'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_5 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_6'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_6 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_7'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_7 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_8'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_8 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_9'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_9 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_10'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_10 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_11'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_11 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_12'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_12 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_13'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_13 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_14'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_14 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_15'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_15 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_16'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_16 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_17'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_17 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_18'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_18 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_19'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_19 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_20'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_20 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_21'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_21 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_22'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_22 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_23'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_23 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_24'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_24 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_25'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_25 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_26'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_26 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_27'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_27 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_28'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_28 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_29'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_29 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_30'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_30 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_31'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_31 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_32'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_32 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_line__mutmut['xǁStreamObservationǁ_line__mutmut_33'] = StreamObservation.xǁStreamObservationǁ_line__mutmut_33 # type: ignore # mutmut generated

mutants_xǁStreamObservationǁ_event__mutmut['_mutmut_orig'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_orig # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_1'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_1 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_2'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_2 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_3'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_3 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_4'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_4 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_5'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_5 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_6'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_6 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_7'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_7 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_8'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_8 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_9'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_9 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_10'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_10 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_11'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_11 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_12'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_12 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_13'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_13 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_14'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_14 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_15'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_15 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_16'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_16 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_17'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_17 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_18'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_18 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_19'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_19 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_20'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_20 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_21'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_21 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_22'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_22 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_23'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_23 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_24'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_24 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_25'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_25 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_26'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_26 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_27'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_27 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_28'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_28 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_29'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_29 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_30'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_30 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_31'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_31 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_32'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_32 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_33'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_33 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_34'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_34 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_35'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_35 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_36'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_36 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_37'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_37 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_38'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_38 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_39'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_39 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_40'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_40 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_41'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_41 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_42'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_42 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_43'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_43 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_44'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_44 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_45'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_45 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_46'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_46 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_47'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_47 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_48'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_48 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_49'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_49 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_50'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_50 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_51'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_51 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_52'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_52 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_53'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_53 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_54'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_54 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_55'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_55 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_56'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_56 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_57'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_57 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_58'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_58 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_59'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_59 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_60'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_60 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_61'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_61 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_62'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_62 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_63'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_63 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_64'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_64 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_65'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_65 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_66'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_66 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_67'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_67 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_68'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_68 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_69'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_69 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_70'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_70 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_71'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_71 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_72'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_72 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_73'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_73 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_74'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_74 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_75'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_75 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_76'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_76 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_77'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_77 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_78'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_78 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_79'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_79 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_80'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_80 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_81'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_81 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_82'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_82 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_83'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_83 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_84'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_84 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_85'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_85 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_86'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_86 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_87'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_87 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_88'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_88 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_89'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_89 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_90'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_90 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_91'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_91 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_92'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_92 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_93'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_93 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_94'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_94 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_95'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_95 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_96'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_96 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_97'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_97 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_98'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_98 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_99'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_99 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_100'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_100 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_101'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_101 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_102'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_102 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_103'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_103 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_104'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_104 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_105'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_105 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_106'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_106 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_107'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_107 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_108'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_108 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_109'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_109 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_110'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_110 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_111'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_111 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_112'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_112 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_113'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_113 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_114'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_114 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_115'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_115 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_116'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_116 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_117'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_117 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_118'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_118 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_119'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_119 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_120'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_120 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_121'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_121 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_122'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_122 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_123'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_123 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_124'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_124 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_125'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_125 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_126'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_126 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_127'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_127 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_128'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_128 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_129'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_129 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_130'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_130 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_131'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_131 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_132'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_132 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_133'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_133 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_134'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_134 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_135'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_135 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_136'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_136 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_137'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_137 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_138'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_138 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_139'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_139 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_140'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_140 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_141'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_141 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_142'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_142 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_143'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_143 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_144'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_144 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_145'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_145 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_146'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_146 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_147'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_147 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_148'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_148 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_149'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_149 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_150'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_150 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_151'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_151 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_152'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_152 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_153'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_153 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_154'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_154 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_155'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_155 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_156'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_156 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_157'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_157 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_158'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_158 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_159'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_159 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_160'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_160 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_161'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_161 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_162'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_162 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_163'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_163 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_164'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_164 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_165'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_165 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_166'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_166 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁ_event__mutmut['xǁStreamObservationǁ_event__mutmut_167'] = StreamObservation.xǁStreamObservationǁ_event__mutmut_167 # type: ignore # mutmut generated

mutants_xǁStreamObservationǁfinish__mutmut['_mutmut_orig'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_orig # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_1'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_1 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_2'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_2 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_3'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_3 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_4'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_4 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_5'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_5 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_6'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_6 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_7'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_7 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_8'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_8 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_9'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_9 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_10'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_10 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_11'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_11 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_12'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_12 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_13'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_13 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_14'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_14 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_15'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_15 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_16'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_16 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_17'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_17 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_18'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_18 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_19'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_19 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_20'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_20 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_21'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_21 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_22'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_22 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_23'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_23 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_24'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_24 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_25'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_25 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_26'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_26 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_27'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_27 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_28'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_28 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_29'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_29 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_30'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_30 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_31'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_31 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_32'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_32 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_33'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_33 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_34'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_34 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_35'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_35 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_36'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_36 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_37'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_37 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_38'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_38 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_39'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_39 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_40'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_40 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_41'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_41 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_42'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_42 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_43'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_43 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_44'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_44 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_45'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_45 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_46'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_46 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_47'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_47 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_48'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_48 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_49'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_49 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_50'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_50 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_51'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_51 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_52'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_52 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_53'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_53 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_54'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_54 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_55'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_55 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_56'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_56 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_57'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_57 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_58'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_58 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_59'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_59 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_60'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_60 # type: ignore # mutmut generated
mutants_xǁStreamObservationǁfinish__mutmut['xǁStreamObservationǁfinish__mutmut_61'] = StreamObservation.xǁStreamObservationǁfinish__mutmut_61 # type: ignore # mutmut generated
