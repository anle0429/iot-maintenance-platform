"""Capture original source, Jenkins phases, native Airflow tasks, persisted RAG checks and independently read-back CI governance."""
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
from urllib.request import ProxyHandler,Request,build_opener
import base64,json,shutil,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform')
out=root/'outputs/rag-ci-capture-29a';assert not out.exists()
secret=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes())
client=build_opener(ProxyHandler({}));headers={'Authorization':'Basic '+base64.b64encode(('learner:'+secret['admin_password']).encode()).decode()}
def read(path):
 with client.open(Request('http://127.0.0.1:18787'+path,headers=headers),timeout=35) as response:return response.read()
builds={number:read('/job/iot-llm-rag/'+str(number)+'/api/json') for number in [1,2,3]}
assert [(json.loads(raw)['building'],json.loads(raw)['result']) for raw in builds.values()]==[(False,'FAILURE'),(False,'SUCCESS'),(False,'SUCCESS')]
out.mkdir()
def keep(name,raw):
 path=out/name;path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb') as stream:stream.write(raw)
def copy(name,path):keep(name,path.read_bytes())
for number,raw in builds.items():
 base='/job/iot-llm-rag/'+str(number);keep('jenkins/'+str(number)+'/build.json',raw)
 keep('jenkins/'+str(number)+'/console.txt',read(base+'/consoleText'))
 keep('jenkins/'+str(number)+'/stages.json',read(base+'/wfapi/describe'))
 value=json.loads(raw);commit=next(p['value'] for a in value['actions'] for p in a.get('parameters',[]) if p['name']=='SOURCE_COMMIT')
 source=root/'data/ci/source'/commit
 copy('source/'+str(number)+'/manifest.json',source/'manifest.json')
 seal=json.loads((source/'manifest.json').read_bytes())
 for name,digest in seal['files'].items():
  body=(source/'tree'/name).read_bytes();assert sha256(body).hexdigest()==digest;keep('source/'+str(number)+'/tree/'+name,body)
 release=root/'data/ci/releases'/('llm-rag-jenkins-'+str(number))/'outputs'
 for path in release.iterdir():
  assert path.is_file();copy('release/'+str(number)+'/'+path.name,path)
 if number>1:
  run='rag-ci-'+commit[:8]+'-'+str(number)
  copy('run/'+str(number)+'/manifest.json',root/'data/rag-releases'/(run+'.json'))
  for path in (root/'outputs'/run).iterdir():
   assert path.is_file();copy('run/'+str(number)+'/native/'+path.name,path)
  state=root/'data/rag'/run
  for path in state.iterdir():
   if path.is_file() and path.suffix in {'.json','.parquet'}:copy('run/'+str(number)+'/state/'+path.name,path)
keep('jenkins/job-config.xml',read('/job/iot-llm-rag/config.xml'))
copy('capture/source.py',Path(__file__))
copy('session.json',root/'data/runtime/ci/session.json')
# Scan actual active values in memory. Credential names/IDs are useful evidence; values never enter the packet.
private=[secret[k].encode() for k in secret if 'password' in k.lower()]
for filename in ['agent-platform.json','mcp-tools.json']:
 for key,value in json.loads((root/'data/runtime/secrets'/filename).read_bytes()).items():
  if isinstance(value,str) and len(value)>=24 and any(part in key.lower() for part in ['password','token','secret','key']):private.append(value.encode())
private += [base64.b64encode(value) for value in list(private)]
for path in out.rglob('*'):
 if path.is_file():
  raw=path.read_bytes();assert not any(value in raw for value in private), 'Credential-bearing original refused'
result={'passed':True,'job':'iot-llm-rag','accepted_build':3,'source_commit':'9b77c06fe872d588e4f7e55af8c5834f2b03448e',
 'failed_builds_retained':[1],'preceding_success_retained':[2],'credential_values_archived':False,
 'captured_utc':datetime.now(timezone.utc).isoformat(),'coursework_complete':False}
keep('capture.json',(json.dumps(result,indent=2)+'\n').encode())
inventory={'files':{p.relative_to(out).as_posix():{'sha256':sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
                    for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(inventory,indent=2)+'\n').encode())
archive=root/'outputs/rag-ci-capture-29a.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as package:package.add(out,arcname=out.name)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),
 'payloads':len(inventory['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()},indent=2))
