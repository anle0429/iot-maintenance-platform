"""Preserve native private gateway, Vault, failed predecessors and accepted real GPU conversations without credentials."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from io import BytesIO
import argparse,base64,json,os,subprocess,tarfile
parser=argparse.ArgumentParser();parser.add_argument('--packet',type=Path,required=True);parser.add_argument('--sha256',required=True);args=parser.parse_args()
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/agent-gateway-capture-29b'
raw=args.packet.read_bytes();assert sha256(raw).hexdigest()==args.sha256
members={}
with tarfile.open(fileobj=BytesIO(raw),mode='r:gz') as packet:
 for m in packet:
  assert m.isfile() and '..' not in Path(m.name).parts and not Path(m.name).is_absolute() and m.name not in members
  members[m.name]=packet.extractfile(m).read()
seal=json.loads(members['manifest.json']);assert seal['format']=='iot-agent-gateway-final-v1' and len(seal['files'])==16
assert set(members)=={'manifest.json'}|{'tree/'+n for n in seal['files']}
for n,d in seal['files'].items():assert sha256(members['tree/'+n]).hexdigest()==d
source=root/'data/llm-source'/('agent-gateway-final-'+seal['commit'][:8]);assert source.is_dir()
for n,v in members.items():assert (source/n).read_bytes()==v,n
os.environ['KUBECONFIG']='/etc/rancher/k3s/k3s.yaml';k=['/usr/local/bin/k3s','kubectl']
for name in ['agent-vault-29a','agent-gateway-probe-29d','agent-gateway-chat-29c','agent-ui-identity-29a']:
 assert json.loads((root/'outputs'/name/'verification.json').read_bytes())['passed']
out.mkdir(exist_ok=False);private=[]
for name in ['agent-platform.json','mcp-tools.json']:
 private.extend(v.encode() for v in json.loads((root/'data/runtime/secrets'/name).read_bytes()).values() if len(v)>=16)
for name in ['gateway-approle.json','services-approle.json','gateway-credentials.json']:
 private.extend(v.encode() for key,v in json.loads((root/'data/runtime/agent-vault-29a-private'/name).read_bytes()).items() if key!='username')
private.append(json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes())['root_token'].encode())
private=list(set(private+[base64.b64encode(v) for v in private]))
def keep(name,body):
 """Refuse any actual credential value before writing a retained original payload."""
 assert not any(v in body for v in private),name
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
def folder(prefix,directory):
 """Copy only bounded explicitly selected non-private directories without following symlinks."""
 assert directory.is_dir(),str(directory)
 for p in directory.rglob('*'):
  assert not p.is_symlink()
  if p.is_file():keep(prefix+'/'+p.relative_to(directory).as_posix(),p.read_bytes())
runs=['agent-vault-29a','agent-gateway-29a','agent-gateway-update-29b','agent-gateway-update-29c',
 'agent-gateway-probe-29a','agent-gateway-probe-29b','agent-gateway-probe-29c','agent-gateway-probe-29d',
 'agent-gateway-chat-29a','agent-gateway-chat-29c','agent-ui-identity-29a','agent-feature-29k','agent-feature-29l','gpu-gateway-session-29b']
for name in runs:folder('native/'+name,root/'outputs'/name)
assert not (root/'outputs/agent-gateway-chat-29b').exists()
keep('failed-chat-packet-path.json',(json.dumps({'output_directory_absent':True,'unit':'iot-agent-gateway-chat-29b','business_request_sent':False,'reason':'The ten-file BCF9 packet did not include the separately uploaded conversation runner; Python exited2 before main.'},indent=2)+'\n').encode())
for name in ['agent-gateway-1c5faee0','agent-gateway-7c9a5856','agent-gateway-bcf9c436','agent-gateway-5f0a8c5e',source.name]:
 directory=root/'data/llm-source'/name
 if not directory.exists() and name=='agent-gateway-5f0a8c5e':directory=root/'data/llm-source/agent-ui-5f0a8c5e'
 folder('source/'+name,directory)
directory=root/'data/llm-source/ci-daee5d3f/tree'
if not directory.exists():
 options=list((root/'data/llm-source').glob('ci-daee*/tree'));assert len(options)==1;directory=options[0]
folder('source/accepted-agent',directory.parent)
for name in ['iot-probe-agent-gateway-conversation-29a.py','iot-probe-agent-gateway-conversation-29b.py',
 'iot-view-agent-gateway-29a.py','iot-view-agent-gateway-29b.py','iot-view-agent-gateway-29c.py','iot-view-agent-gateway-29d.py','iot-view-agent-gateway-29e.py',
 'iot-record-gpu-gateway-session-29b.py','iot-observe-feature-lease-29a.py','iot-refresh-demo-feature-29k.py']:
 keep('executed-scripts/'+name,(Path('/tmp')/name).read_bytes())
keep('executed-scripts/capture-agent-gateway-29a.py',Path('/tmp/iot-capture-agent-gateway-29a.py').read_bytes())
keep('executed-scripts/capture-agent-gateway-29b.py',Path(__file__).read_bytes())
units=['iot-'+n for n in runs if n!='gpu-gateway-session-29b']+['iot-agent-gateway-chat-29b','iot-agent-gateway-tests-29a']
for role,tag in [('agents','29a'),('registry','29a'),('agents','29b'),('registry','29b'),('agents','29c'),('agents','29d'),('agents','29e')]:
 unit='iot-agent-gateway-view-'+role+'-'+tag;units.append(unit)
 p=root/'outputs'/('agent-gateway-view-'+tag)/(role+'.jsonl')
 if p.exists():
  body=p.read_bytes();assert not body or body.endswith(b'\n');keep('viewer-audit/'+tag+'/'+role+'.jsonl',body)
for unit in units:
 for suffix,cmd in [('unit.txt',['systemctl','show',unit,'-p','Id','-p','ActiveState','-p','SubState','-p','Result','-p','ExecMainStatus','-p','ExecStart','-p','InvocationID']),
                    ('journal.jsonl',['journalctl','-u',unit,'--no-pager','-o','json'])]:
  p=subprocess.run(cmd,capture_output=True,timeout=30);keep('process/'+unit+'.'+suffix,p.stdout);keep('process/'+unit+'.'+suffix+'.exit',str(p.returncode).encode()+b'\n')
for name,query in [('gateway-deployment',['deployment','iot-gateway','-n','iot-gateway']),('gateway-service',['service','iot-gateway','-n','iot-gateway']),
 ('agent-ingresses',['ingress','-n','iot-agents']),('agent-gateway-role',['role','iot-agent-gateway-read','-n','iot-agents']),
 ('agent-gateway-rolebinding',['rolebinding','iot-agent-gateway-read','-n','iot-agents']),('ui-deployment',['deployment','kagent-ui','-n','iot-agents']),
 ('agents',['sandboxagents','-n','iot-agents']),('pools',['workerpools','-n','iot-agents']),('modelconfig',['modelconfig','default-model-config','-n','iot-agents']),
 ('llm-pods',['pods','-n','iot-llm']),('nodes',['nodes'])]:
 keep('final-cluster/'+name+'.json',subprocess.check_output(k+['get']+query+['-o','json'],stderr=subprocess.PIPE,timeout=30))
for n in ['stdout.txt','stderr.txt','exit.txt']:keep('current-tests/'+n,(root/'outputs/agent-gateway-capture-29a/current-tests'/n).read_bytes())
assert (out/'current-tests/exit.txt').read_bytes()==b'0\n'
keep('credential-scan.json',(json.dumps({'passed':True,'actual_agent_service_credentials_checked':True,'vault_approle_and_root_checked':True,'password_and_base64_variants_checked':True,'private_debug_payloads_excluded':True},indent=2)+'\n').encode())
files={p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in out.rglob('*') if p.is_file()}
keep('manifest.json',(json.dumps({'files':files,'captured_utc':datetime.now(timezone.utc).isoformat(),'current_source_commit':seal['commit'],'full_coursework_complete':False},sort_keys=True,indent=2)+'\n').encode())
archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=6) as packet:packet.add(out,arcname=out.name)
print(json.dumps({'passed':True,'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'native_payloads':len(files),'source_files':len(seal['files'])}))
