"""Read the physical feature-key expiry and current immutable seed without updating either."""
from datetime import datetime,timezone,timedelta
from pathlib import Path
import json,subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');k=['/usr/local/bin/k3s','kubectl']
def get(kind,name):return json.loads(subprocess.check_output(k+['get',kind,name,'-n','iot-features','-o','json']))
deployment=get('deployment','iot-feature-api');seed=next(v['configMap']['name'] for v in deployment['spec']['template']['spec']['volumes'] if v['name']=='seed')
mapping=get('configmap',seed);context=json.loads(mapping['data']['context.json'])
redis=get('service','online-serve-jenkins-8')['spec']['clusterIP']
code='import json,redis; r=redis.Redis(host='+repr(redis)+',port=6379,socket_timeout=2); keys=list(r.scan_iter(match=b"*iot_serving_demo",count=256)); print(json.dumps({"keys":len(keys),"remaining_pttl_ms":[r.pttl(k) for k in keys]}))'
raw=subprocess.check_output(['docker','run','--rm','--network','host','--memory','256m','--cpus','.5','--entrypoint','python',
 'iot-coursework-feast-versioned:0.67.0-3.17.2','-B','-c',code],timeout=40)
result=json.loads(raw);ttl=result.pop('remaining_pttl_ms');result.update(checked_utc=datetime.now(timezone.utc).isoformat(),
 seed=seed,seed_uid=mapping['metadata']['uid'],prepared_wall_utc=context['prepared_wall_utc'],
 lease_expires_utc=(datetime.fromisoformat(context['prepared_wall_utc'])+timedelta(hours=1)).isoformat(),
 minimum_pttl_ms=min(ttl) if ttl else None,maximum_pttl_ms=max(ttl) if ttl else None,mutating_commands=0)
print(json.dumps(result,indent=2))
