"""Preserve the expired session and record only the actual unchanged Compute descriptor's new eight-hour start."""
from datetime import datetime,timezone,timedelta
from pathlib import Path
from hashlib import sha256
import json,subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/gpu-gateway-session-29b';out.mkdir()
record=Path('/tmp/iot-gpu-gateway-session-29b.json').read_bytes();new=json.loads(record)
assert set(new)=={'last_start_utc','max_duration_seconds','termination_action','status','private_ip'}
assert new['max_duration_seconds']==28800 and new['termination_action']=='STOP' and new['status']=='RUNNING' and new['private_ip']=='10.42.0.7'
path=root/'data/runtime/ci/gpu-session.json';old=path.read_bytes();assert sha256(old).hexdigest()=='4c9509de280d7eb2c4a047fcd130ae7fffa9d1f70ee19e31eb111aacd50f09b4'
assert datetime.fromisoformat(new['last_start_utc'])>datetime.fromisoformat(json.loads(old)['last_start_utc'])
(out/'previous-session.json').write_bytes(old);(out/'new-session.json').write_bytes(record)
pending=path.with_suffix('.gateway-pending')
with pending.open('xb') as stream:stream.write(record)
pending.chmod(0o644);pending.replace(path)
k=['/usr/local/bin/k3s','kubectl']
nodes=json.loads(subprocess.check_output(k+['get','nodes','-o','json'],stderr=subprocess.PIPE))
node=next(n for n in nodes['items'] if any(a['type']=='InternalIP' and a['address']=='10.42.0.7' for a in n['status']['addresses']))
safe={'name':node['metadata']['name'],'labels':node['metadata']['labels'],'conditions':node['status']['conditions'],'allocatable':node['status']['allocatable']}
(out/'gpu-node.json').write_text(json.dumps(safe,indent=2)+'\n')
pods=json.loads(subprocess.check_output(k+['get','pods','-n','iot-llm','-o','json'],stderr=subprocess.PIPE))
safe_pods=[{'name':p['metadata']['name'],'uid':p['metadata']['uid'],'node':p['spec'].get('nodeName'),
            'phase':p['status'].get('phase'),'conditions':p['status'].get('conditions',[]),'containers':p['status'].get('containerStatuses',[])} for p in pods['items']]
(out/'llm-pods.json').write_text(json.dumps(safe_pods,indent=2)+'\n')
ready=any(c['type']=='Ready' and c['status']=='True' for c in node['status']['conditions'])
result={'passed':True,'checked_utc':datetime.now(timezone.utc).isoformat(),'descriptor_record_sha256':sha256(record).hexdigest(),
        'actual_start_utc':new['last_start_utc'],'auto_stop_utc':(datetime.fromisoformat(new['last_start_utc'])+timedelta(hours=8)).isoformat(),
        'gpu_node_ready':ready,'gpu_allocatable':node['status']['allocatable'].get('nvidia.com/gpu'),'previous_session_preserved':True,
        'scope':'Same authorized private GPU VM, unchanged8hSTOP and resources; native application acceptance remains separate.'}
(out/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
