"""Reuse the retained gateway, CA and administrative login for bounded loopback viewers after VM restart."""
from pathlib import Path
from hashlib import sha256
import argparse,json,subprocess,socket
p=argparse.ArgumentParser();p.add_argument('--sha256',required=True);a=p.parse_args();root=Path('/srv/iot-data/workspace/iot-maintenance-platform');helper=Path('/tmp/view-llm-monitoring-30a.py')
assert sha256(helper.read_bytes()).hexdigest()==a.sha256
for port in [18100,18101,18102]:
 with socket.socket() as test:assert test.connect_ex(('127.0.0.1',port))!=0
k=['/usr/local/bin/k3s','kubectl'];svc=json.loads(subprocess.check_output(k+['get','service','iot-gateway','-n','iot-gateway','-o','json']));assert svc['spec']['type']=='ClusterIP'
out=root/'outputs/llm-monitoring-view-30a';out.mkdir(exist_ok=False);units={}
for role in ['metrics','logs','traces']:
 unit='iot-llm-view-'+role+'-30a';subprocess.run(['systemd-run','--unit='+unit,'--property=RuntimeMaxSec=3600','--property=MemoryMax=256M','--property=NoNewPrivileges=yes','/usr/bin/python3','-B',str(helper),'--role',role,'--gateway-ip',svc['spec']['clusterIP'],'--credentials',str(root/'data/runtime/gateway-28-private/credentials.json'),'--ca',str(root/'outputs/agent-gateway-29a/ca.crt'),'--audit',str(out/(role+'.jsonl'))],check=True)
 units[role]=subprocess.check_output(['systemctl','show',unit,'-p','InvocationID','-p','ActiveState'],text=True)
(out/'launch.json').write_text(json.dumps({'source_sha256':a.sha256,'units':units,'new_gateway_or_certificates':False},indent=2)+'\n');(out/'operator.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(units))
