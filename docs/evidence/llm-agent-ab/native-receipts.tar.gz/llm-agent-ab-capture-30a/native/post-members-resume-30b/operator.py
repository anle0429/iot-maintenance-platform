"""Reuse the completed controller rollout and original SDK preparation, without rerunning either workload."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,os
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/post-members-resume-30b';os.umask(0o077);out.mkdir(exist_ok=False)
k=['/usr/local/bin/k3s','kubectl'];assert json.loads((root/'outputs/substrate-members-30b/verification.json').read_bytes())['passed']
raw=subprocess.check_output(k+['get','deployment','kagent-controller','-n','iot-agents','-o','json']);(out/'controller.json').write_bytes(raw);current=json.loads(raw)
assert current['status']['observedGeneration']==current['metadata']['generation'] and current['status']['updatedReplicas']==current['status']['availableReplicas']==current['spec']['replicas']==1
helper=Path('/tmp/iot-refresh-demo-feature-29k.py');assert sha256(helper.read_bytes()).hexdigest()=='ec2be13e02a218a5e583c7006ce418648ee8bb1829acb1c5d9b10f89e41552c0'
assert not (root/'outputs/feature-refresh-30b').exists()
subprocess.run(['systemd-run','--unit=iot-feature-refresh-30c','--property=RuntimeMaxSec=900','--property=MemoryMax=3G','/usr/bin/python3','-B',str(helper),'--runtime-root',str(root),'--runtime-source',str(root/'data/observability-source-2fceb32/tree'),'--run','demo-agents-30a','--resume-deploy','--output',str(root/'outputs/feature-refresh-30b')],check=True)
identity=subprocess.check_output(['systemctl','show','iot-feature-refresh-30c','-p','InvocationID','-p','ActiveState','-p','Result'],text=True)
(out/'feature-launch.txt').write_text(identity);(out/'operator.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'controller_ready':True,'controller_restarted_again':False,'original_feature_preparation_resumed':True}));print(identity)
