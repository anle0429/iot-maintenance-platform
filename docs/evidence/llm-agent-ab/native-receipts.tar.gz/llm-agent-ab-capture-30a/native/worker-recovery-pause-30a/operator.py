"""Temporarily reserve the existing two-worker baseline during actual KEDA fallback; retain exact original scaler metadata for restoration."""
from pathlib import Path
import json,subprocess,os
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/worker-recovery-pause-30a';os.umask(0o077);out.mkdir(exist_ok=False)
k=['/usr/local/bin/k3s','kubectl'];active=subprocess.check_output(['systemctl','list-units','--state=running','--no-legend','iot-agent-chat-*']);assert not active.strip()
before={}
for role in ['retrieval','drift','coordinator']:
 name='iot-'+role+'-workers';raw=subprocess.check_output(k+['get','scaledobject',name,'-n','iot-agents','-o','json']);item=json.loads(raw)
 assert item['spec']['scaleTargetRef']['name']=='iot-'+role+'-pool' and item['spec']['minReplicaCount']==2 and item['spec']['maxReplicaCount']==4
 assert not any(key.startswith('autoscaling.keda.sh/paused') for key in item['metadata'].get('annotations',{}))
 assert any(c['type']=='Fallback' and c['status']=='True' for c in item['status']['conditions'])
 (out/(name+'-before.json')).write_bytes(raw);before[name]=item
for name,item in before.items():
 patch=[{'op':'test','path':'/metadata/uid','value':item['metadata']['uid']},{'op':'test','path':'/metadata/resourceVersion','value':item['metadata']['resourceVersion']},
  {'op':'add','path':'/metadata/annotations/autoscaling.keda.sh~1paused-replicas','value':'2'}]
 result=subprocess.run(k+['patch','scaledobject',name,'-n','iot-agents','--type=json','-p',json.dumps(patch),'-o','json'],capture_output=True);(out/(name+'-pause.stdout')).write_bytes(result.stdout);(out/(name+'-pause.stderr')).write_bytes(result.stderr);assert result.returncode==0
(out/'operator.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'paused':True,'roles':list(before),'replicas_per_pool':2,'specs_changed':False,'requires_unpause':True}))
