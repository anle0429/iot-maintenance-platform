"""Seal native recovery and both agent cohorts without rerunning requests or exporting runtime Secret bodies."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from urllib.parse import quote
import base64,json,os,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/llm-agent-ab-capture-30a';os.umask(0o077);out.mkdir(exist_ok=False);private=[]
paths=[root/'data/runtime/secrets'/n for n in ['agent-platform.json','mcp-tools.json']]
paths.extend(root/'data/runtime/agent-vault-29a-private'/n for n in ['gateway-credentials.json','gateway-approle.json','services-approle.json'])
paths.extend([root/'data/runtime/agent-gateway-29a-private/credentials.json',root/'data/runtime/gateway-28-private/credentials.json'])
paths.extend(root/'data/runtime/vault-28-private'/n for n in ['ci-approle.json','gateway-approle.json'])
for path in paths:
 value=json.loads(path.read_bytes());private.extend(v.encode() for v in value.values() if isinstance(v,str) and len(v)>=16)
 if {'username','password'}<=set(value):private.append(base64.b64encode((value['username']+':'+value['password']).encode()))
bootstrap=json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes());private.append(bootstrap['root_token'].encode());private.extend(v.encode() for v in bootstrap['keys_base64']);bootstrap=None
private.append((root/'data/runtime/llm-monitoring-29a/auth/token').read_bytes().strip())
k=['/usr/local/bin/k3s','kubectl']
for name,namespace in [('iot-llm-observer-client','iot-llm'),('iot-local-model-client','iot-agents')]:
 secret=json.loads(subprocess.check_output(k+['get','secret',name,'-n',namespace,'-o','json']));private.extend(base64.b64decode(v) for v in secret['data'].values());secret=None
private=list({v for raw in private for v in [raw,base64.b64encode(raw),base64.b64encode(b'Bearer '+raw),quote(raw.decode(),safe='').encode()]})
def keep(name,body):
 assert len(body)<10000000 and not any(v in body for v in private),name
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
def copy(label,folder):
 assert folder.is_dir(),folder
 for parent,dirs,files in os.walk(folder):
  dirs[:]=[v for v in dirs if v!='__pycache__']
  for name in sorted(files):
   p=Path(parent)/name;assert not p.is_symlink();keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())
folders=['demo-resume-stage-30a','demo-resume-30a','demo-resume-30b','demo-resume-inspect-30a',
 'substrate-members-stage-30a','substrate-members-30a','substrate-members-30b','worker-recovery-pause-30a',
 'post-members-resume-30a','post-members-resume-30b','cpu-model-standby-30a','feature-refresh-30a','feature-refresh-30b',
 'worker-address-recovery-30a','worker-recovery-unpause-30a','worker-recovery-unpause-30b','retrieval-mcp-recovery-30a',
 'agent-ab-stage-30a','agent-ab-stage-30b','agent-ab-deploy-30a','agent-ab-deploy-30b','agent-ab-study-30a','agent-ab-study-30b','agent-ab-view-30a','llm-monitoring-view-30a']
for name in folders:copy('native/'+name,root/'outputs'/name)
for name in ['demo-resume-5b234e25','substrate-members-224ef519','agent-ab-c6cb12a8','agent-ab-7c59f103','cpu-standby-f10af11a','worker-address-4e6ed69f','agent-study-23fa0ed7','agent-study-2015d649','agent-ab-view-2015d649']:
 copy('source/'+name,root/'data/llm-source'/name)
units=['iot-demo-resume-30a','iot-demo-resume-30b','iot-feature-refresh-30a','iot-feature-refresh-30b','iot-feature-refresh-30c',
 'iot-substrate-members-30a','iot-substrate-members-30b','iot-cpu-model-standby-30a','iot-worker-address-recovery-30a',
 'iot-agent-ab-deploy-30a','iot-agent-ab-deploy-30b','iot-agent-ab-study-30a','iot-agent-ab-study-30b','iot-agent-ab-view-30a',
 'iot-llm-view-metrics-30a','iot-llm-view-logs-30a','iot-llm-view-traces-30a']
for unit in units:
 for label,argv in [('unit',['systemctl','show',unit]),('journal',['journalctl','-u',unit,'--no-pager','-o','json'])]:
  result=subprocess.run(argv,capture_output=True,timeout=30);assert result.returncode==0;keep('units/'+unit+'/'+label+'.stdout',result.stdout)
for name in ['agent-ab-deploy-launch-30a.txt','agent-ab-deploy-launch-30b.txt','agent-ab-study-launch-30a.txt','agent-ab-study-launch-30b.txt','agent-ab-view-launch-30a.txt','feature-refresh-launch-30b.txt','substrate-members-launch-30a.txt','worker-address-recovery-launch-30a.txt','cpu-model-standby-launch-30a.txt']:
 keep('launch/'+name,(root/'outputs'/name).read_bytes())
for name in ['resume-post-members-30a.py','unpause-recovery-workers-30a.py','reconcile-unpause-status-30b.py','restart-unavailable-retrieval-mcp-30a.py','iot-refresh-demo-feature-29k.py','view-llm-monitoring-30a.py']:
 keep('helpers/'+name,(Path('/tmp')/name).read_bytes())
keep('native/agent-ab-study-diagnosis-30a.json',(root/'outputs/agent-ab-study-diagnosis-30a.json').read_bytes())
for name in ['model-pin.json','portable.json']:keep('models/'+name,(root/'data/ci/releases/serve-jenkins-8/bundle'/name).read_bytes())
keep('capture-notes.json',(json.dumps({'workloads_rerun_for_capture':False,'model_requests_rerun_for_capture':0,
 'member_recovery_a':'Initial topology validation passed; six CONFIG SET and five CLUSTER MEET operations reconnected original IDs. A real epoch8-to9 automatic failover then changed primary/replica assignment, so the post-check failed. B accepted only the subsequently converged topology; no reset, flush or reshard.',
 'agent_cohort_a':'The six HTTP200 envelopes contain FAILED tasks during MCP initialization: connection refused, no final artifacts/tool outputs. Runner exit0 means the complete failed-outcome inventory was recorded; it is not functional agent success or a model-quality comparison.',
 'agent_cohort_b':'A distinct cohort ran only after the actual unavailable retrieval MCP release was recovered and readiness preflight strengthened. All six answers and18 successful MCP events were verified. Failed A originals remain separate.',
 'unpause_a':'Annotations were removed but the first observer timed out while native Paused conditions remained True. KEDA restart B reconciled all three conditions to False without manual status editing. Original scaler UIDs/specs/annotations were restored.',
 'feature_lease':'Only one genuine SDK preparation at01:01:53.221866Z. Failed Helm45/rollback46 precede a resume-deploy of the same immutable state; no timestamp or TTL extension. Lease expires02:01:53.221866Z.',
 'omissions':'No weights, data bulk, full generated Secret data, private controller log candidates, credentials or cloud instance bootstrap metadata. Viewer audit files are original byte snapshots at capture time.'},indent=2)+'\n').encode())
keep('capture-helper.py',Path(__file__).read_bytes())
manifest={'captured_utc':datetime.now(timezone.utc).isoformat(),'current_native_credentials_scanned':True,'workloads_rerun_for_capture':False,
 'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode());archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'x:gz') as packet:packet.add(out,arcname=out.name)
archive.chmod(0o644);receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'payloads':len(manifest['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()}
destination=root/'outputs/llm-agent-ab-capture-receipt-30a.json';destination.write_text(json.dumps(receipt,indent=2)+'\n');destination.chmod(0o644);print(json.dumps(receipt))
