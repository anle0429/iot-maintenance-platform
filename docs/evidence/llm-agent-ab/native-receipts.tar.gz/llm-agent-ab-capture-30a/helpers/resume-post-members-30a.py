"""Remove controller crash backoff after native Substrate readiness and resume the original, still-valid feature preparation."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,os
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/post-members-resume-30a';os.umask(0o077);out.mkdir(exist_ok=False)
k=['/usr/local/bin/k3s','kubectl'];report=json.loads((root/'outputs/substrate-members-30b/verification.json').read_bytes());assert report['passed']
def command(label,args):
 result=subprocess.run(args,capture_output=True,timeout=180);(out/(label+'.stdout')).write_bytes(result.stdout);(out/(label+'.stderr')).write_bytes(result.stderr);assert result.returncode==0
command('ate-ready',k+['wait','deployment/ate-api-server-deployment','-n','ate-system','--for=condition=Available','--timeout=90s'])
before=subprocess.check_output(k+['get','deployment','kagent-controller','-n','iot-agents','-o','json']);(out/'controller-before.json').write_bytes(before)
command('controller-restart',k+['rollout','restart','deployment/kagent-controller','-n','iot-agents'])
command('controller-ready',k+['rollout','status','deployment/kagent-controller','-n','iot-agents','--timeout=120s'])
after=subprocess.check_output(k+['get','deployment','kagent-controller','-n','iot-agents','-o','json']);(out/'controller-after.json').write_bytes(after)
a=json.loads(before);b=json.loads(after);assert a['metadata']['uid']==b['metadata']['uid']
assert a['spec']['template']['spec']==b['spec']['template']['spec']
helper=Path('/tmp/iot-refresh-demo-feature-29k.py');assert sha256(helper.read_bytes()).hexdigest()=='ec2be13e02a218a5e583c7006ce418648ee8bb1829acb1c5d9b10f89e41552c0'
subprocess.run(['systemd-run','--unit=iot-feature-refresh-30c','--property=RuntimeMaxSec=900','--property=MemoryMax=3G','/usr/bin/python3','-B',str(helper),'--runtime-root',str(root),'--runtime-source',str(root/'data/observability-source-2fceb32/tree'),'--run','demo-agents-30a','--resume-deploy','--output',str(root/'outputs/feature-refresh-30b')],check=True)
identity=subprocess.check_output(['systemctl','show','iot-feature-refresh-30c','-p','InvocationID','-p','ActiveState','-p','Result'],text=True)
(out/'feature-launch.txt').write_text(identity);(out/'operator.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'controller_ready':True,'controller_image_args_and_env_preserved':True,'original_feature_preparation_resumed':True}));print(identity)
