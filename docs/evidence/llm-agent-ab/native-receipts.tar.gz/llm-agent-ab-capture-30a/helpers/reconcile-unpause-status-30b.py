"""Reconcile native KEDA status after pause removal without editing status fields or changing scaling policies."""
from pathlib import Path
import json,subprocess,os,time
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/worker-recovery-unpause-30b';os.umask(0o077);out.mkdir(exist_ok=False)
k=['/usr/local/bin/k3s','kubectl'];originals={}
for role in ['retrieval','drift','coordinator']:
 name='iot-'+role+'-workers';original=json.loads((root/'outputs/worker-recovery-pause-30a'/(name+'-before.json')).read_bytes());originals[name]=original
 raw=subprocess.check_output(k+['get','scaledobject',name,'-n','iot-agents','-o','json']);item=json.loads(raw);(out/(name+'-before.json')).write_bytes(raw)
 assert item['metadata']['uid']==original['metadata']['uid'] and item['spec']==original['spec']
 assert item['metadata'].get('annotations',{})==original['metadata'].get('annotations',{})
raw=subprocess.check_output(k+['get','deployment','keda-operator','-n','iot-autoscale','-o','json']);(out/'operator-before.json').write_bytes(raw);before=json.loads(raw)
for label,args in [('restart',['rollout','restart','deployment/keda-operator']),('ready',['rollout','status','deployment/keda-operator','--timeout=120s'])]:
 result=subprocess.run(k+args+['-n','iot-autoscale'],capture_output=True,timeout=150);(out/(label+'.stdout')).write_bytes(result.stdout);(out/(label+'.stderr')).write_bytes(result.stderr);assert result.returncode==0
raw=subprocess.check_output(k+['get','deployment','keda-operator','-n','iot-autoscale','-o','json']);(out/'operator-after.json').write_bytes(raw);after=json.loads(raw)
assert before['metadata']['uid']==after['metadata']['uid'] and before['spec']['template']['spec']==after['spec']['template']['spec']
for attempt in range(45):
 raw=subprocess.check_output(k+['get','scaledobjects','-n','iot-agents','-o','json']);(out/('scalers-after-'+str(attempt)+'.json')).write_bytes(raw);items=json.loads(raw)['items']
 if all(not any(c['type']=='Paused' and c['status']=='True' for c in v['status']['conditions']) for v in items):break
 time.sleep(2)
hpas=json.loads(subprocess.check_output(k+['get','hpa','-n','iot-agents','-o','json']));(out/'hpas-after.json').write_text(json.dumps(hpas,indent=2)+'\n')
assert len(hpas['items'])==3 and all(any(c['type']=='ScalingActive' and c['status']=='True' for c in v['status']['conditions']) for v in hpas['items'])
for item in items:
 original=originals[item['metadata']['name']];assert item['metadata']['uid']==original['metadata']['uid'] and item['spec']==original['spec'] and item['metadata'].get('annotations',{})==original['metadata'].get('annotations',{})
 native_paused={v['metadata']['name']:next(c['status'] for c in v['status']['conditions'] if c['type']=='Paused') for v in items}
report={'passed':True,'original_uids_specs_and_annotations_preserved':True,'temporary_pause_annotations_remaining':0,'active_hpas':3,
 'native_paused_conditions':native_paused,'status_was_manually_edited':False,'scope':'Original policies and annotations restored; native HPA scaling-active checks. Any remaining native Paused condition is retained as a status inconsistency, not rewritten.'}
(out/'operator.py').write_bytes(Path(__file__).read_bytes());(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
