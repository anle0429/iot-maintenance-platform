"""Preserve the reboot's unavailable MCP Pods, then restart only that owned unavailable release with unchanged application spec."""
from pathlib import Path
from urllib.request import build_opener,ProxyHandler
import json,subprocess,os
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/retrieval-mcp-recovery-30a';os.umask(0o077);out.mkdir(exist_ok=False)
k=['/usr/local/bin/k3s','kubectl'];opener=build_opener(ProxyHandler({}));private=[]
for name in ['agent-platform.json','mcp-tools.json']:
 private.extend(v.encode() for v in json.loads((root/'data/runtime/secrets'/name).read_bytes()).values() if isinstance(v,str) and len(v)>5)
def get(label,*args):
 raw=subprocess.check_output(k+['get',*args,'-o','json']);assert not any(v in raw for v in private);(out/(label+'.json')).write_bytes(raw);return json.loads(raw)
controller=get('controller-service','service','kagent-controller','-n','iot-agents')
with opener.open('http://'+controller['spec']['clusterIP']+':8083/api/substrate/status',timeout=20) as response:inventory=response.read()
assert not any(v in inventory for v in private);(out/'actors-before.json').write_bytes(inventory);assert not any(v['atespace']=='iot-agents' and v['status']=='Running' for v in json.loads(inventory)['data']['actors'])
before=get('deployment-before','deployment','iot-retrieval-mcp','-n','iot-agents');assert before['spec']['replicas']==2 and before['status'].get('availableReplicas',0)==0
selector=','.join(key+'='+value for key,value in sorted(before['spec']['selector']['matchLabels'].items()))
get('pods-before','pods','-n','iot-agents','-l',selector);service=get('service-before','service','iot-retrieval-mcp','-n','iot-agents')
slices=get('endpoint-slices-before','endpointslices','-n','iot-agents','-l','kubernetes.io/service-name=iot-retrieval-mcp');assert not any(e.get('conditions',{}).get('ready') is True for s in slices['items'] for e in s['endpoints'])
for label,args in [('restart',['rollout','restart','deployment/iot-retrieval-mcp']),('ready',['rollout','status','deployment/iot-retrieval-mcp','--timeout=180s'])]:
 result=subprocess.run(k+args+['-n','iot-agents'],capture_output=True,timeout=210);assert not any(v in result.stdout+result.stderr for v in private);(out/(label+'.stdout')).write_bytes(result.stdout);(out/(label+'.stderr')).write_bytes(result.stderr);assert result.returncode==0
after=get('deployment-after','deployment','iot-retrieval-mcp','-n','iot-agents');assert before['metadata']['uid']==after['metadata']['uid'] and before['spec']['template']['spec']==after['spec']['template']['spec'] and after['status']['availableReplicas']==2
assert get('service-after','service','iot-retrieval-mcp','-n','iot-agents')['spec']==service['spec'];get('pods-after','pods','-n','iot-agents','-l',selector);get('endpoint-slices-after','endpointslices','-n','iot-agents','-l','kubernetes.io/service-name=iot-retrieval-mcp')
(out/'operator.py').write_bytes(Path(__file__).read_bytes());(out/'verification.json').write_text(json.dumps({'passed':True,'before_ready':0,'after_ready':2,'application_image_args_env_and_mounts_preserved':True,'service_and_deployment_uid_preserved':True},indent=2)+'\n');print('Owned retrieval MCP recovered: two actual ready replicas; original failure retained.')
