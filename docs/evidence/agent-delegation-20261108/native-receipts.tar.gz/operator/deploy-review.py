"""Apply narrowly guarded, source-bound specialist gateway rollout in explicit phases."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import base64,json,os,secrets,subprocess,sys,time
R=Path('/srv/iot-data/workspace/iot-maintenance-platform');S=R/'data/llm-source/delegation-review-9471bfe';T=S/'tree';O=R/'outputs/delegation-review-20261108'
sys.path.insert(0,str(T));os.environ['KUBECONFIG']='/etc/rancher/k3s/k3s.yaml'
from infra.agentgateway.candidate import NAME,NAMESPACE,PORTS,bearer_hash,config
from infra.agentgateway.delegation import plan
from agents.admission import deployment_envelope,evaluate
K=['/usr/local/bin/k3s','kubectl'];H=str(R/'data/runtime/kubernetes-assets-27/helm/helm');RUN='agw-delegation-20261108a'
assert (datetime.fromisoformat(json.loads((R/'data/runtime/ci/session.json').read_bytes())['auto_stop_utc'])-datetime.now(timezone.utc)).total_seconds()>2400
seal=json.loads((S/'manifest.json').read_bytes())
for n,h in seal['files'].items():assert sha256((T/n).read_bytes()).hexdigest()==h,n
def save(n,v):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def cmd(n,a,t=60,data=None):
 p=subprocess.run(a,input=data,capture_output=True,timeout=t);d=O/n;d.parent.mkdir(parents=True,exist_ok=True)
 d.with_suffix('.stdout').write_bytes(p.stdout);d.with_suffix('.stderr').write_bytes(p.stderr);d.with_suffix('.exit').write_text(str(p.returncode)+'\n')
 assert p.returncode==0,n;return p.stdout
def get(kind,name=None):return json.loads(subprocess.check_output(K+['get',kind,*([name] if name else []),'-n',NAMESPACE,'-o','json'],stderr=subprocess.PIPE,timeout=45))
def secret(name,key):return base64.b64decode(get('secret',name)['data'][key]).decode()
phase=sys.argv[1]
if phase=='prepare':
 assert not (O/'plan.json').exists()
 observed=[get(k,NAME) for k in ['configmap','deployment','networkpolicy','service']]
 for obj in observed:save('readbacks/gateway-'+obj['kind'].lower()+'.json',obj)
 controller=get('deployment','kagent-controller');save('readbacks/controller.json',controller)
 policies=get('networkpolicy');save('readbacks/policies.json',policies)
 current=json.loads(observed[0]['data']['config.yaml']);hashes={}
 for role,bind in zip(PORTS,current['binds']):hashes[role]=bind['listeners'][0]['routes'][0]['policies']['apiKey']['keys'][0]['keyHash']
 for role,n,key in [('model','iot-local-model-client','API_KEY'),('retrieval','iot-retrieval-mcp-auth','token'),('drift','iot-drift-mcp-auth','token')]:assert bearer_hash(secret(n,key))==hashes[role]
 assert json.loads(observed[0]['data']['config.yaml'])==config(hashes,tracing=True)
 token=secrets.token_urlsafe(36);private=O/'.delegation-bearer';private.write_text(token);private.chmod(0o600)
 sec={'apiVersion':'v1','kind':'Secret','metadata':{'name':'iot-agentgateway-delegation-client','namespace':NAMESPACE,'annotations':{'iot.coursework/delegation-run':RUN}},'type':'Opaque','stringData':{'Authorization':'Bearer '+token}}
 # Never persist secret-bearing command input or output; capture only public identity.
 p=subprocess.run(K+['create','-f','-','-o','json'],input=json.dumps(sec).encode(),capture_output=True,timeout=30);assert p.returncode==0,'Create distinct delegation credential'
 obj=json.loads(p.stdout);save('delegation-secret-identity.json',{'name':obj['metadata']['name'],'uid':obj['metadata']['uid'],'key_names':list(obj['data']),'credential_sha256':bearer_hash(token)})
 P=plan(observed,policies['items'],controller['spec']['template']['metadata']['labels'],hashes,bearer_hash(token),RUN);save('plan.json',P)
 vals=json.loads(cmd('agents-values-before',[H,'get','values','iot-agents','-n',NAMESPACE,'--all','-o','json']));assert vals['agentgateway']['enabled'] is True;save('agents-values.json',vals)
 rendered=cmd('agents-render',[H,'template','iot-agents',str(T/'infra/charts/iot-agents'),'-n',NAMESPACE,'-f',str(O/'agents-values.json'),'--post-renderer',str(T/'scripts/render-agent-responses.py')])
 import yaml
 model=get('modelconfig','default-model-config');save('readbacks/model.json',model)
 envelope=deployment_envelope(list(yaml.safe_load_all(rendered)),model);save('observed.json',envelope)
 decision=evaluate(T,R/'data/runtime/policy-assets-28/opa',envelope,O/'predeploy-opa');assert decision['allowed']
 policyfiles=['agents/admission.py','agents/admission_cases.py','agents/policy_execution.py','scripts/check-agent-admission.py','infra/policy/agent-admission.rego','infra/policy/agent-admission-approved.json','agents/response-policy.json','infra/policy/opa-assets.json']
 save('policy-source.json',{'format':'iot-agent-admission-source-v1','commit':seal['commit'],'files':{n:seal['files'][n] for n in policyfiles}})
 cmd('policy-suite',['python3','-B',str(T/'scripts/check-agent-admission.py'),'--opa',str(R/'data/runtime/policy-assets-28/opa'),'--source-manifest',str(O/'policy-source.json'),'--observed',str(O/'observed.json'),'--output',str(O/'policy')],180)
 save('prepared.json',{'passed':True,'source':seal['commit'],'utc':datetime.now(timezone.utc).isoformat(),'planned_resource_count':len(envelope['resources'])})
elif phase=='gateway':
 assert json.loads((O/'prepared.json').read_bytes())['passed']
 P=json.loads((O/'plan.json').read_bytes())
 for p in P['patches']:
  if p['kind']=='NetworkPolicy':cmd('apply/gateway-ingress',K+['patch',p['kind'],p['name'],'-n',NAMESPACE,'--type=json','--patch-file=/dev/stdin'],data=json.dumps(p['operations']).encode())
 for p in P['additions']:cmd('apply/'+p['metadata']['name'],K+['create','-f','-'],data=json.dumps(p).encode())
 for kind in ['ConfigMap','Deployment']:
  p=next(v for v in P['patches'] if v['kind']==kind);cmd('apply/'+kind.lower(),K+['patch',kind,p['name'],'-n',NAMESPACE,'--type=json','--patch-file=/dev/stdin'],data=json.dumps(p['operations']).encode())
 cmd('gateway-ready',K+['rollout','status','deployment/'+NAME,'-n',NAMESPACE,'--timeout=180s'],210)
 for kind in ['configmap','deployment','networkpolicy','service']:save('gateway-after-'+kind+'.json',get(kind,NAME))
elif phase=='agents':
 assert json.loads((O/'policy/verification.json').read_bytes())['passed']
 cmd('agents-server-dry-run',K+['apply','--dry-run=server','-f','-','-o','json'],data=(O/'agents-render.stdout').read_bytes())
 cmd('agents-upgrade',[H,'upgrade','iot-agents',str(T/'infra/charts/iot-agents'),'-n',NAMESPACE,'-f',str(O/'agents-values.json'),'--post-renderer',str(T/'scripts/render-agent-responses.py'),'--atomic','--wait','--timeout','240s'],300)
 save('agents-after.json',get('sandboxagents'));save('tools-after.json',get('remotemcpservers'))
elif phase=='controller':
 values=json.loads(cmd('kagent-values-before',[H,'get','values','kagent','-n',NAMESPACE,'--all','-o','json']))
 import yaml
 overlay=yaml.safe_load((T/'infra/agentgateway/kagent-default.yaml').read_bytes())
 for k,v in overlay.items():
  if k in ['controller','proxy']:values[k].update(v)
  else:values[k]['openAI']['config'].update(v['openAI']['config'])
 assert values['controller']['substrate']['enabled'] is True
 save('kagent-values.json',values)
 chart=R/'outputs/agent-foundation-research/kagent-0.10.3.tgz';assert sha256(chart.read_bytes()).hexdigest()=='d8e7f41b27920e92e1929fb7502dae3cda9a2c450abe9db6488f04fe4118e744'
 cmd('kagent-render',[H,'template','kagent',str(chart),'-n',NAMESPACE,'-f',str(O/'kagent-values.json')])
 cmd('kagent-upgrade',[H,'upgrade','kagent',str(chart),'-n',NAMESPACE,'-f',str(O/'kagent-values.json'),'--atomic','--wait','--timeout','240s'],300)
 cmd('controller-ready',K+['rollout','status','deployment/kagent-controller','-n',NAMESPACE,'--timeout=180s'],210)
 save('controller-after.json',get('deployment','kagent-controller'));save('model-after.json',get('modelconfig','default-model-config'))
 assert json.loads((O/'model-after.json').read_bytes())['spec']==json.loads((O/'readbacks/model.json').read_bytes())['spec']
else:raise ValueError('Explicit phase required')
print(json.dumps({'phase':phase,'passed':True,'utc':datetime.now(timezone.utc).isoformat()}),flush=True)
