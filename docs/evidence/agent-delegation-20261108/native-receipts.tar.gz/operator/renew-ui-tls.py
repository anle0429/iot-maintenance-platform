"""Renew only the expired retained UI leaf; preserve CA, key and old receipt bytes."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,base64,os,ssl,socket,time
R=Path('/srv/iot-data/workspace/iot-maintenance-platform');O=R/'outputs/delegation-review-20261108/ui-tls';O.mkdir(mode=0o700)
K=['/usr/local/bin/k3s','kubectl'];old=R/'outputs/agent-gateway-29a';P=R/'data/runtime/agent-gateway-29a-private'
def cmd(n,a):
 p=subprocess.run(a,capture_output=True,timeout=35);(O/(n+'.stdout')).write_bytes(p.stdout);(O/(n+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,n;return p.stdout
ca=old/'ca.crt';key=P/'server.key';assert key.is_file();keysha=sha256(key.read_bytes()).hexdigest();cash=sha256(ca.read_bytes()).hexdigest()
cmd('authority',['openssl','x509','-in',str(ca),'-checkend','172800','-noout'])
obj=json.loads(subprocess.check_output(K+['get','secret','agent-gateway-tls','-n','iot-agents','-o','json']))
before=base64.b64decode(obj['data']['tls.crt']);(O/'previous-server.crt').write_bytes(before);(O/'ca.crt').write_bytes(ca.read_bytes())
assert base64.b64decode(obj['data']['tls.key'])==key.read_bytes()
cmd('verify-original-authority',['openssl','verify','-no_check_time','-CAfile',str(ca),str(O/'previous-server.crt')])
cmd('request',['openssl','req','-new','-key',str(key),'-out',str(O/'server.csr'),'-subj','/CN=agents.iot.test'])
cmd('sign',['openssl','x509','-req','-in',str(O/'server.csr'),'-CA',str(ca),'-CAkey',str(R/'data/runtime/gateway-28-private/ca.key'),'-set_serial','0x'+os.urandom(16).hex(),'-out',str(O/'server.crt'),'-days','2','-extfile',str(P/'extensions.cnf')])
for host in ['agents.iot.test','registry.iot.test']:cmd('verify-'+host,['openssl','verify','-verify_hostname',host,'-purpose','sslserver','-CAfile',str(ca),str(O/'server.crt')])
patch=[{'op':'test','path':'/metadata/uid','value':obj['metadata']['uid']},{'op':'test','path':'/metadata/resourceVersion','value':obj['metadata']['resourceVersion']},{'op':'test','path':'/data/tls.crt','value':obj['data']['tls.crt']},{'op':'replace','path':'/data/tls.crt','value':base64.b64encode((O/'server.crt').read_bytes()).decode()}]
p=subprocess.run(K+['patch','secret','agent-gateway-tls','-n','iot-agents','--type=json','--patch-file=/dev/stdin'],input=json.dumps(patch).encode(),capture_output=True,timeout=30);assert p.returncode==0
(O/'patch.stdout').write_bytes(p.stdout);assert sha256(key.read_bytes()).hexdigest()==keysha and sha256(ca.read_bytes()).hexdigest()==cash
svc=json.loads(subprocess.check_output(K+['get','svc','iot-gateway','-n','iot-gateway','-o','json']))['spec']['clusterIP'];context=ssl.create_default_context(cafile=str(ca));expected=sha256(ssl.PEM_cert_to_DER_cert((O/'server.crt').read_text())).hexdigest()
for attempt in range(30):
 try:
  with context.wrap_socket(socket.create_connection((svc,443),timeout=5),server_hostname='agents.iot.test') as peer:actual=sha256(peer.getpeercert(binary_form=True)).hexdigest()
  if actual==expected:break
 except OSError:pass
 time.sleep(2)
else:raise RuntimeError('Gateway did not load renewed leaf')
v={'passed':True,'utc':datetime.now(timezone.utc).isoformat(),'secret_uid':obj['metadata']['uid'],'same_ca_sha256':cash,'same_key_sha256':keysha,'old_leaf_sha256':sha256(before).hexdigest(),'new_leaf_der_sha256':actual,'ca_and_hostname_verified':True,'old_receipts_unchanged':True};(O/'verification.json').write_text(json.dumps(v,indent=2));print(json.dumps(v))
