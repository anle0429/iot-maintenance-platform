"""Capture one actual Jenkins state and independent post-terminal resource/model observations."""
from pathlib import Path
from urllib.request import build_opener,ProxyHandler,Request
import json,base64,subprocess,sys
R=Path('/srv/iot-data/workspace/iot-maintenance-platform');tag=sys.argv[1];assert tag in ['delegation-20261108-denied','delegation-20261108-allowed','delegation-20261108-denied-c']
O=R/'outputs'/('agent-policy-ci-trigger-'+tag);launch=json.loads((O/'launch.json').read_bytes());n=launch['expected_build'];token=json.loads((R/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes())['admin_password'];auth='Basic '+base64.b64encode(('learner:'+token).encode()).decode();op=build_opener(ProxyHandler({}));base='http://127.0.0.1:18787/job/iot-llm-coordinator/'+str(n)
for label,suffix in [('build','/api/json'),('console','/consoleText'),('stages','/wfapi/describe')]:
 with op.open(Request(base+suffix,headers={'Authorization':auth}),timeout=35) as r:b=r.read()
 assert token.encode() not in b and auth.encode() not in b;(O/(label+('.txt' if label=='console' else '.json'))).write_bytes(b)
v=json.loads((O/'build.json').read_bytes());print(json.dumps({'build':n,'building':v['building'],'result':v.get('result')}),flush=True)
if not v['building']:
 assert not (O/'resources-after.json').exists(),'Keep the first terminal observation; never overwrite it later'
 K=['/usr/local/bin/k3s','kubectl'];inventory={}
 for kind in ['sandboxagents','modelconfigs','remotemcpservers','workerpools','deployments']:
  inventory[kind]=json.loads(subprocess.check_output(K+['get',kind,'-n','iot-agents','-o','json'],timeout=40))
 (O/'resources-after.json').write_text(json.dumps(inventory,indent=2))
 H=[str(R/'data/runtime/kubernetes-assets-27/helm/helm'),'--kubeconfig','/etc/rancher/k3s/k3s.yaml'];revs={}
 for release in ['iot-agents','iot-retrieval-mcp','iot-drift-mcp']:revs[release]=json.loads(subprocess.check_output(H+['history',release,'-n','iot-agents','--max','1','-o','json'],timeout=35))
 (O/'helm-after.json').write_text(json.dumps(revs,indent=2));gpu=json.loads(subprocess.check_output(K+['get','svc','iot-model-gpu','-n','iot-llm','-o','json']))['spec']['clusterIP']
 with op.open('http://'+gpu+':8080/metrics?model=iot-qwen2.5-7b',timeout=20) as r:(O/'model-after.prom').write_bytes(r.read())
 D=R/'data/ci/releases'/('llm-coordinator-jenkins-'+str(n))/'outputs'
 print(json.dumps({'artifact_names':sorted(p.name for p in D.iterdir()) if D.is_dir() else [],'console_tail':(O/'console.txt').read_text()[-3000:]}),flush=True)
