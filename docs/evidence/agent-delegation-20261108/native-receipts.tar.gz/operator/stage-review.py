"""Stage exact current source and restore only retained lab runtime prerequisites."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, subprocess, tarfile, os
R=Path('/srv/iot-data/workspace/iot-maintenance-platform')
S=R/'data/llm-source/delegation-review-9471bfe'; O=R/'outputs/delegation-review-20261108'
assert (datetime.fromisoformat(json.loads((R/'data/runtime/ci/session.json').read_bytes())['auto_stop_utc'])-datetime.now(timezone.utc)).total_seconds()>3600
assert sha256(Path('/tmp/review-source.tar.gz').read_bytes()).hexdigest()=='03afbc2527b9d4a3d10db41876110843561b04e2060116b209c5d155974b046b'
S.mkdir(mode=0o755);O.mkdir(mode=0o700)
with tarfile.open('/tmp/review-source.tar.gz') as t:
 for m in t:
  p=(S/m.name).resolve();assert p.is_relative_to(S) and m.isfile() and m.size<15000000
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read());p.chmod(m.mode)
for d in [S,*[p for p in S.rglob('*') if p.is_dir()]]:d.chmod(0o755)
seal=json.loads((S/'manifest.json').read_bytes())
for n,h in seal['files'].items():assert sha256((S/'tree'/n).read_bytes()).hexdigest()==h,n
link=R/'data/ci/source'/seal['commit'];assert not link.exists();link.symlink_to(S,target_is_directory=True)
(O/'source.json').write_bytes((S/'manifest.json').read_bytes())
K=['/usr/local/bin/k3s','kubectl']
def unit(name,command,seconds=600):
 subprocess.run(['systemd-run','--unit=iot-review-'+name+'-20261108','--property=RuntimeMaxSec='+str(seconds),'--property=MemoryMax=1G','--property=StandardOutput=append:'+str(O/(name+'.log')),'--property=StandardError=append:'+str(O/(name+'.log')),*command],check=True,capture_output=True)
P=R/'data/llm-source/autoscale-recovery-20261106/tree'
unit('members',['python3','-B',str(P/'scripts/restore-substrate-members.py'),'--runtime-root',str(R),'--output',str(O/'members')])
unit('workers',['python3','-B',str(P/'scripts/restore-substrate-workers.py'),'--runtime-root',str(R),'--output',str(O/'workers'),'--restart-workers'])
for n in ['iot-retrieval-mcp','iot-drift-mcp']:
 d=json.loads(subprocess.check_output(K+['get','deployment',n,'-n','iot-agents','-o','json']))
 (O/(n+'-resume-before.json')).write_text(json.dumps(d,indent=2))
 if d['status'].get('availableReplicas',0)==0:
  p=subprocess.run(K+['rollout','restart','deployment/'+n,'-n','iot-agents'],capture_output=True,check=True)
  (O/(n+'-resume-restart.stdout')).write_bytes(p.stdout)
unit('features',['python3','-B',str(R/'data/llm-source/autoscale-operator-20261106/tree/scripts/refresh-agent-features.py'),'--runtime-root',str(R),'--runtime-source',str(R/'data/observability-source-2fceb32/tree'),'--run','demo-delegation-20261108a','--output',str(O/'features')],1800)
print(json.dumps({'source':seal['commit'],'files':len(seal['files']),'staged':True,'bounded_recovery_units':['members','workers','features']}))
