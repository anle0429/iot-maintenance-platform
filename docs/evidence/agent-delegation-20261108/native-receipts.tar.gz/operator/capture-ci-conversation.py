"""Join original child histories to native gateway logs and actual worker Pod identities."""
from pathlib import Path
import subprocess,json,sys
R=Path('/srv/iot-data/workspace/iot-maintenance-platform');S=R/'data/llm-source/delegation-review-9471bfe/tree';O=R/'outputs/delegation-review-20261108';D=O/'ci-conversation';sys.path.insert(0,str(S))
from agents.delegation_acceptance import verify_coordinator
from agents.gateway_acceptance import verify_delegation_paths
C=R/'data/ci/releases/llm-coordinator-jenkins-18/outputs';assert json.loads((C/'verify.json').read_bytes())['passed'];D.mkdir(mode=0o700)
for p in (C/'agent-request').iterdir():
 if p.is_file():(D/p.name).write_bytes(p.read_bytes())
K=['/usr/local/bin/k3s','kubectl'];pods=subprocess.check_output(K+['get','pods','-n','iot-agents','-o','json'],timeout=30);(D/'worker-pods.json').write_bytes(pods)
workers={}
for p in json.loads(pods)['items']:
 pool=p['metadata']['labels'].get('ate.dev/worker-pool','');role=pool.removeprefix('iot-').removesuffix('-pool')
 if role in ['retrieval','drift','coordinator'] and p['status']['phase']=='Running':workers[p['status']['podIP']]={'role':role,'pod':p['metadata']['name'],'uid':p['metadata']['uid']}
(D/'workers.json').write_text(json.dumps(workers,indent=2))
raw=subprocess.check_output(K+['logs','deployment/iot-agentgateway-candidate','-n','iot-agents'],timeout=45);(D/'gateway.log').write_bytes(raw)
records=[]
for line in raw.splitlines():
 try:records.append(json.loads(line))
 except json.JSONDecodeError:pass
reply=json.loads((D/'coordinator-response.json').read_bytes());children={r:{k:json.loads((D/(r+'-'+k+'.json')).read_bytes()) for k in ['session','tasks']} for r in ['retrieval','drift']}
content=verify_coordinator(reply,children,knowledge_root=S/'knowledge')
v=verify_delegation_paths(records,content['context_id'],{r:x['context_id'] for r,x in content['children'].items()},workers)
(D/'transport-acceptance.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({'passed':True,'parent_context':content['context_id'],'children':{r:x['context_id'] for r,x in content['children'].items()},'worker_pods':len(workers),'gateway_records':len(records)}))
