"""Recover only retained services in the newly authorized bounded session."""
from pathlib import Path
from datetime import datetime, timezone
import json, subprocess
R=Path('/srv/iot-data/workspace/iot-maintenance-platform')
O=R/'outputs/ab-gateway-20261108/recovery-b';O.mkdir(mode=0o700,exist_ok=False)
S=R/'data/llm-source/autoscale-operator-20261106/tree'
def unit(name,args,seconds=900):
 subprocess.run(['systemd-run','--unit=iot-ab-gateway-'+name+'-20261108','--property=RuntimeMaxSec='+str(seconds),'--property=MemoryMax=2G','--property=StandardOutput=append:'+str(O/(name+'.log')),'--property=StandardError=append:'+str(O/(name+'.log')),*args],check=True,capture_output=True)
for role in ['cpu','gpu']:
 p=Path('/tmp/ab-'+role+('-ready.json' if role=='gpu' else '-running.json'));d=json.loads(p.read_bytes())
 assert d['status']=='RUNNING' and d['scheduling']['maxRunDuration']['seconds']=='28800' and d['scheduling']['instanceTerminationAction']=='STOP'
 (O/(role+'-running.json')).write_bytes(p.read_bytes())
unit('cpu-resume',['python3','-B',str(S/'scripts/resume-demo-services.py'),'--runtime-root',str(R),'--descriptor','/tmp/ab-cpu-running.json','--renew-consumers','--output',str(O/'cpu-resume')])
unit('gpu-resume',['python3','-B',str(S/'scripts/resume-gpu-services.py'),'--runtime-root',str(R),'--descriptor','/tmp/ab-gpu-ready.json','--output',str(O/'gpu-resume')])
print(json.dumps({'started_recovery':True,'checked_utc':datetime.now(timezone.utc).isoformat()}))
