"""Extract only the authenticated committed runtime packet into a new source directory."""
from pathlib import Path
from hashlib import sha256
import json,tarfile
R=Path('/srv/iot-data/workspace/iot-maintenance-platform');S=R/'data/llm-source/ab-gateway-1e883f4'
raw=Path('/tmp/ab-gateway-source.tar.gz');assert sha256(raw.read_bytes()).hexdigest()=='45740340c8edf19f0da030a8b9d74e5a62efd7131a4a41ed3f4e2a1151404a1c'
S.mkdir(mode=0o755,exist_ok=False)
with tarfile.open(raw) as t:
 for m in t:
  p=(S/m.name).resolve();assert m.isfile() and p.is_relative_to(S) and m.size<2000000
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read());p.chmod(0o644)
for p in S.rglob('*'):
 if p.is_dir():p.chmod(0o755)
seal=json.loads((S/'manifest.json').read_bytes())
for n,h in seal['files'].items():assert sha256((S/'tree'/n).read_bytes()).hexdigest()==h,n
print(json.dumps({'staged':True,'commit':seal['commit'],'files':len(seal['files'])}))
