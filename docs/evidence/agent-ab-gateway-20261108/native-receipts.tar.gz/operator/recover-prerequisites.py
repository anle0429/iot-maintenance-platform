"""Retry bounded retained recovery and snapshot only public workload state."""
from pathlib import Path
import json,subprocess,sys
R=Path('/srv/iot-data/workspace/iot-maintenance-platform');O=R/'outputs/ab-gateway-20261108'
S=R/'data/llm-source/autoscale-operator-20261106/tree';P=R/'data/llm-source/autoscale-recovery-20261106/tree'
K=['/usr/local/bin/k3s','kubectl'];phase=sys.argv[1]
def unit(n,a,t=900):
 subprocess.run(['systemd-run','--unit=iot-ab-'+n+'-20261108','--property=RuntimeMaxSec='+str(t),'--property=MemoryMax=2G','--property=StandardOutput=append:'+str(O/(n+'.log')),'--property=StandardError=append:'+str(O/(n+'.log')),*a],check=True,capture_output=True)
if phase=='retry-cpu':
 unit('cpu-retry',['python3','-B',str(S/'scripts/resume-demo-services.py'),'--runtime-root',str(R),'--descriptor','/tmp/ab-cpu-running.json','--renew-consumers','--output',str(O/'cpu-retry')])
elif phase=='members':
 unit('members',['python3','-B',str(P/'scripts/restore-substrate-members.py'),'--runtime-root',str(R),'--output',str(O/'members')])
elif phase=='workers':
 unit('workers',['python3','-B',str(P/'scripts/restore-substrate-workers.py'),'--runtime-root',str(R),'--output',str(O/'workers'),'--restart-workers'])
elif phase=='features':
 unit('features',['python3','-B',str(S/'scripts/refresh-agent-features.py'),'--runtime-root',str(R),'--runtime-source',str(R/'data/observability-source-2fceb32/tree'),'--run','demo-ab-gateway-20261108','--output',str(O/'features')],1800)
elif phase=='inspect':
 D=O/'readbacks';D.mkdir(mode=0o700,exist_ok=False)
 for kind in ['sandboxagents','modelconfigs','remotemcpservers','workerpools','pods','actortemplates']:
  raw=subprocess.check_output(K+['get',kind,'-n','iot-agents','-o','json'],timeout=45);(D/(kind+'.json')).write_bytes(raw)
  v=json.loads(raw)
  if kind=='pods':print(json.dumps([{'name':x['metadata']['name'],'phase':x['status']['phase'],'ready':[c['ready'] for c in x['status'].get('containerStatuses',[])]} for x in v['items']]))
 for name in ['iot-retrieval-mcp','iot-drift-mcp']:
  d=json.loads(subprocess.check_output(K+['get','deployment',name,'-n','iot-agents','-o','json']))
  (D/(name+'.json')).write_text(json.dumps(d,indent=2))
  if d['status'].get('availableReplicas',0)==0:
   p=subprocess.run(K+['rollout','restart','deployment/'+name,'-n','iot-agents'],capture_output=True,check=True)
   (D/(name+'-restart.stdout')).write_bytes(p.stdout)
else:raise ValueError('Explicit phase required')
print(json.dumps({'phase':phase,'started':True}))
