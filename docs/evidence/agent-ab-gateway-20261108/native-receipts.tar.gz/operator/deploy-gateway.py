"""Opt into two bounded A/B operator paths on the retained selected gateway."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from copy import deepcopy
import base64,json,subprocess,sys
R=Path('/srv/iot-data/workspace/iot-maintenance-platform');S=Path(sys.argv[1]);T=S/'tree';O=R/'outputs/ab-gateway-20261108/gateway'
sys.path.insert(0,str(T));from infra.agentgateway.candidate import config,PORTS,NAME,NAMESPACE,bearer_hash,IMAGE
seal=json.loads((S/'manifest.json').read_bytes())
for n,h in seal['files'].items():assert sha256((T/n).read_bytes()).hexdigest()==h,n
assert (datetime.fromisoformat(json.loads((R/'data/runtime/ci/session.json').read_bytes())['auto_stop_utc'])-datetime.now(timezone.utc)).total_seconds()>2400
O.mkdir(mode=0o700,exist_ok=False);K=['/usr/local/bin/k3s','kubectl']
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def get(kind,name):return json.loads(subprocess.check_output(K+['get',kind,name,'-n',NAMESPACE,'-o','json'],timeout=45,stderr=subprocess.PIPE))
observed={kind:get(kind,NAME) for kind in ['configmap','deployment','service','networkpolicy']}
for kind,obj in observed.items():save(kind+'-before.json',obj)
current=json.loads(observed['configmap']['data']['config.yaml']);hashes={}
for role,bind in zip(PORTS,current['binds']):
 assert bind['port']==PORTS[role]
 routes=bind['listeners'][0]['routes'];name={'model':'model','retrieval':'retrieval','drift':'drift','a2a':'a2a-retrieval'}[role]
 selected=next(r for r in routes if r['name']==name);hashes[role]=selected['policies']['apiKey']['keys'][0]['keyHash']
secret=get('secret','iot-agentgateway-delegation-client');auth=base64.b64decode(secret['data']['Authorization']).decode();assert auth.startswith('Bearer ')
delegation=bearer_hash(auth[7:]);secret=None;auth=None
assert current==config(hashes,tracing=True,delegation_hash=delegation)
desired=config(hashes,tracing=True,delegation_hash=delegation,ab_operator_routes=True)
assert observed['service']['spec']['type']=='ClusterIP'
assert {p['port'] for p in observed['service']['spec']['ports']}==set(PORTS.values())
assert observed['deployment']['spec']['template']['spec']['containers'][0]['image']==IMAGE
patches=[]
for kind,field,value in [('configmap','data',{'config.yaml':json.dumps(desired,indent=2)})]:
 obj=observed[kind];ops=[{'op':'test','path':'/metadata/uid','value':obj['metadata']['uid']},{'op':'test','path':'/metadata/resourceVersion','value':obj['metadata']['resourceVersion']},{'op':'test','path':'/'+field,'value':obj[field]},{'op':'replace','path':'/'+field,'value':value}]
 patches.append({'kind':kind,'operations':ops});p=subprocess.run(K+['patch',kind,NAME,'-n',NAMESPACE,'--type=json','--patch-file=/dev/stdin','-o','json'],input=json.dumps(ops).encode(),capture_output=True,timeout=45)
 (O/(kind+'-patch.stdout')).write_bytes(p.stdout);(O/(kind+'-patch.stderr')).write_bytes(p.stderr);assert p.returncode==0
obj=get('deployment',NAME);spec=deepcopy(obj['spec']);spec['template']['metadata'].setdefault('annotations',{})['iot.coursework/ab-gateway-source']=seal['commit']
ops=[{'op':'test','path':'/metadata/uid','value':obj['metadata']['uid']},{'op':'test','path':'/metadata/resourceVersion','value':obj['metadata']['resourceVersion']},{'op':'test','path':'/spec','value':obj['spec']},{'op':'replace','path':'/spec','value':spec}]
patches.append({'kind':'deployment','operations':ops});save('plan.json',patches)
p=subprocess.run(K+['patch','deployment',NAME,'-n',NAMESPACE,'--type=json','--patch-file=/dev/stdin','-o','json'],input=json.dumps(ops).encode(),capture_output=True,timeout=45)
(O/'deployment-patch.stdout').write_bytes(p.stdout);(O/'deployment-patch.stderr').write_bytes(p.stderr);assert p.returncode==0
p=subprocess.run(K+['rollout','status','deployment/'+NAME,'-n',NAMESPACE,'--timeout=180s'],capture_output=True,timeout=210)
(O/'rollout.stdout').write_bytes(p.stdout);(O/'rollout.stderr').write_bytes(p.stderr);assert p.returncode==0
for kind,before in observed.items():
 after=get(kind,NAME);save(kind+'-after.json',after);assert after['metadata']['uid']==before['metadata']['uid']
 if kind in ['service','networkpolicy']:assert after['spec']==before['spec']
assert json.loads(get('configmap',NAME)['data']['config.yaml'])==desired
save('source.json',seal);save('verification.json',{'passed':True,'source_commit':seal['commit'],'checked_utc':datetime.now(timezone.utc).isoformat(),'same_ports_and_service_and_policy':True,'ab_operator_routes':True})
print(json.dumps({'passed':True,'ab_operator_routes':True,'source':seal['commit']}))
