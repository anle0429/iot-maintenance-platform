"""Finish the interrupted release transaction using its exact already-prepared candidate, without regenerating data or editing Helm storage."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/feature-rollout-recovery-29a';out.mkdir(exist_ok=False)
os.environ['KUBECONFIG']='/etc/rancher/k3s/k3s.yaml';helm=str(root/'data/runtime/kubernetes-assets-27/helm/helm')
def command(name,args):
 r=subprocess.run([helm]+args,capture_output=True,timeout=240)
 (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);(out/(name+'.exit')).write_text(str(r.returncode)+'\n')
 assert r.returncode==0,name
 return r.stdout
before=json.loads(command('history-before',['history','iot-feature-api','-n','iot-features','--max','8','-o','json']))
assert before[-1]['revision']==37 and before[-1]['status']=='pending-rollback'
candidate=json.loads(subprocess.check_output([helm,'get','values','iot-feature-api','--revision','36','-n','iot-features','-o','json']))
expected=(root/'outputs/agent-feature-29g/values.json').read_bytes()
assert candidate==json.loads(expected) and candidate['revisionMarker']=='demo-agent-29g'
assert next(v for v in candidate['volumes'] if v['name']=='seed')['configMap']['name']=='demo-agent-29g'
(out/'candidate-binding.json').write_text(json.dumps({'release':'iot-feature-api','namespace':'iot-features','candidate_revision':36,'interrupted_revision':37,'expected_values_sha256':sha256(expected).hexdigest(),'revision_marker':candidate['revisionMarker'],'regenerated_data':False,'edited_helm_storage':False},indent=2)+'\n')
command('rollback',['rollback','iot-feature-api','36','-n','iot-features','--wait','--timeout','180s'])
after=json.loads(command('history-after',['history','iot-feature-api','-n','iot-features','--max','8','-o','json']))
assert after[-1]['revision']==38 and after[-1]['status']=='deployed'
print(json.dumps({'passed':True,'restored_exact_candidate_revision':36,'new_deployed_revision':38,'regenerated_data':False,'edited_helm_storage':False},indent=2))
