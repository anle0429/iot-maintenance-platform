"""Seal original OPA suites, three production pipelines and the actual controlled denial without another model or deployment run."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from urllib.parse import quote
import base64,json,os,re,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/rag-drift-capture-30a';os.umask(0o077);out.mkdir(exist_ok=False);private=[]

def credential(raw):
 if isinstance(raw,str):raw=raw.encode()
 if len(raw)>=12:
  private.append(raw)
  if raw.startswith(b'Bearer '):private.append(raw[7:])
def walk(value,key=''):
 if isinstance(value,dict):
  if value.get('name')=='Authorization' and isinstance(value.get('value'),str):credential(value['value'])
  if {'username','password'}<=set(value):credential(base64.b64encode((value['username']+':'+value['password']).encode()))
  for name,child in value.items():walk(child,name)
 elif isinstance(value,list):
  for child in value:walk(child,key)
 elif isinstance(value,str) and re.search('password|token|apikey|secretid|roleid|keysbase64|authorization',re.sub('[^a-z]','',key.lower())):credential(value)
paths=[root/'data/runtime/secrets'/n for n in ['agent-platform.json','mcp-tools.json']]
paths.extend(root/'data/runtime/agent-vault-29a-private'/n for n in ['gateway-credentials.json','gateway-approle.json','services-approle.json'])
paths.extend([root/'data/runtime/agent-gateway-29a-private/credentials.json',root/'data/runtime/gateway-28-private/credentials.json',root/'data/runtime/ci/jenkins-private/bootstrap.json'])
paths.extend(root/'data/runtime/vault-28-private'/n for n in ['ci-approle.json','gateway-approle.json','bootstrap.json'])
for path in paths:walk(json.loads(path.read_bytes()))
jenkins=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());credential(base64.b64encode(('learner:'+jenkins['admin_password']).encode()));jenkins=None
credential((root/'data/runtime/llm-monitoring-29a/auth/token').read_bytes().strip())
k=['/usr/local/bin/k3s','kubectl'];refs={('iot-llm','iot-llm-observer-client','API_KEY'),('iot-agents','iot-local-model-client','API_KEY')}
def get(*args):return json.loads(subprocess.check_output(k+['get',*args,'-o','json'],timeout=30,stderr=subprocess.PIPE))
for deployment in get('deployments','-n','iot-agents')['items']:
 for container in deployment['spec']['template']['spec']['containers']:
  for item in container.get('env',[]):
   ref=item.get('valueFrom',{}).get('secretKeyRef')
   if ref and re.search('password|token|key|auth',ref['key'],re.I):refs.add(('iot-agents',ref['name'],ref['key']))
for remote in get('remotemcpservers','-n','iot-agents')['items']:
 for header in remote['spec'].get('headersFrom',[]):
  ref=header.get('valueFrom',{})
  if ref.get('type')=='Secret':refs.add(('iot-agents',ref['name'],ref['key']))
for namespace,name,key in sorted(refs):
 secret=get('secret',name,'-n',namespace);credential(base64.b64decode(secret['data'][key]));secret=None
for value in json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes())['keys_base64']:credential(value)
private=list({v for raw in private for v in [raw,base64.b64encode(raw),base64.b64encode(b'Bearer '+raw),quote(raw.decode(),safe='').encode()]})
def keep(name,body):
 assert len(body)<10000000 and not any(v in body for v in private),name
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
def copy(label,folder):
 assert folder.is_dir(),folder
 for parent,dirs,files in os.walk(folder):
  dirs[:]=[v for v in dirs if v!='__pycache__']
  for name in sorted(files):
   p=Path(parent)/name;assert not p.is_symlink();keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())

from urllib.request import ProxyHandler,Request,build_opener
authorization='Basic '+base64.b64encode(('learner:'+json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes())['admin_password']).encode()).decode()
client=build_opener(ProxyHandler({}))
def read(path):
 with client.open(Request('http://127.0.0.1:18787'+path,headers={'Authorization':authorization}),timeout=35) as response:return response.read()
for number,expected in [(4,'FAILURE'),(5,'SUCCESS')]:
 base='/job/iot-llm-rag/'+str(number);raw=read(base+'/api/json');value=json.loads(raw)
 assert not value['building'] and value['result']==expected
 keep('jenkins/'+str(number)+'/build.json',raw)
 keep('jenkins/'+str(number)+'/stages.json',read(base+'/wfapi/describe'))
 keep('jenkins/'+str(number)+'/console.txt',read(base+'/consoleText'))
 copy('release/'+str(number),root/'data/ci/releases'/('llm-rag-jenkins-'+str(number))/'outputs')
commit='a4a69138740113c291a1f6bfe23c3705014a884b';source=root/'data/ci/source'/commit
keep('source/manifest.json',(source/'manifest.json').read_bytes());seal=json.loads((source/'manifest.json').read_bytes())
for name,digest in seal['files'].items():
 raw=(source/'tree'/name).read_bytes();assert sha256(raw).hexdigest()==digest;keep('source/tree/'+name,raw)
copy('operator',root/'outputs/rag-drift-30a')
run='rag-ci-'+commit[:8]+'-5'
copy('run/native',root/'outputs'/run)
for path in (root/'data/rag'/run).iterdir():
 if path.is_file() and path.suffix in {'.json','.parquet'}:keep('run/state/'+path.name,path.read_bytes())
keep('run/manifest.json',(root/'data/rag-releases'/(run+'.json')).read_bytes())
keep('session.json',(root/'data/runtime/ci/session.json').read_bytes())
keep('suite-unit.txt',subprocess.check_output(['systemctl','show','iot-rag-drift-suite-30a','--property=InvocationID,Result,ExecMainStatus,ActiveState,InactiveEnterTimestamp']))
keep('suite-journal.txt',subprocess.check_output(['journalctl','-u','iot-rag-drift-suite-30a','--no-pager','-o','short-iso']))
keep('helper-install-a.py',Path('/tmp/native-rag-drift-30a.py').read_bytes())
keep('helper-install-b.py',Path('/tmp/native-rag-drift-30b.py').read_bytes())
keep('capture-helper.py',Path(__file__).read_bytes())
manifest={'captured_utc':datetime.now(timezone.utc).isoformat(),'current_native_credentials_scanned':True,'vault_root_and_unseal_scanned':True,
 'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode());archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'x:gz') as t:t.add(out,arcname=out.name)
archive.chmod(0o644)
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'payloads':len(manifest['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()}
target=root/'outputs/rag-drift-capture-receipt-30a.json';target.write_text(json.dumps(receipt,indent=2)+'\n');target.chmod(0o644);print(json.dumps(receipt))
