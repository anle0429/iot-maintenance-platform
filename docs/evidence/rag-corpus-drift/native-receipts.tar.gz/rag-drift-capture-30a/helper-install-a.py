"""Stage exact source, narrowly update the owned idle RAG job, and observe the same negative/positive CI builds."""
from pathlib import Path
from hashlib import sha256
from urllib.request import ProxyHandler,Request,HTTPCookieProcessor,build_opener
from urllib.parse import urlencode
from http.cookiejar import CookieJar
from datetime import datetime,timezone
import argparse,base64,json,subprocess,tarfile,time,xml.etree.ElementTree as ET
root=Path('/srv/iot-data/workspace/iot-maintenance-platform')
p=argparse.ArgumentParser();p.add_argument('mode',choices=['install','launch','observe','suite']);p.add_argument('--commit',required=True);p.add_argument('--archive');p.add_argument('--sha256');p.add_argument('--scenario',default='out-of-domain');p.add_argument('--build',type=int);a=p.parse_args()
out=root/'outputs/rag-drift-30a';out.mkdir(exist_ok=True)
secret=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes())
authorization='Basic '+base64.b64encode(('learner:'+secret['admin_password']).encode()).decode()
client=build_opener(ProxyHandler({}),HTTPCookieProcessor(CookieJar()))
def request(path,data=None,headers=None):
 return client.open(Request('http://127.0.0.1:18787'+path,data=data,headers={'Authorization':authorization,**(headers or {})}),timeout=35)
def read(path):
 with request(path) as r:return r.read()
def save(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def post(path,body,typ):
 crumb=json.loads(read('/crumbIssuer/api/json'))
 with request(path,body,{crumb['crumbRequestField']:crumb['crumb'],'Content-Type':typ}) as r:return {'http':r.status,'location':r.headers.get('Location')}
stage=root/'data/llm-source'/('ci-drift-'+a.commit);link=root/'data/ci/source'/a.commit
if a.mode=='install':
 archive=Path(a.archive);assert sha256(archive.read_bytes()).hexdigest()==a.sha256
 assert not stage.exists() and not link.exists()
 with tarfile.open(archive) as t:
  for m in t:assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  stage.mkdir();t.extractall(stage,filter='data')
 seal=json.loads((stage/'manifest.json').read_bytes());assert seal['commit']==a.commit
 for n,h in seal['files'].items():assert sha256((stage/'tree'/n).read_bytes()).hexdigest()==h
 link.symlink_to(stage,target_is_directory=True)
 old=read('/job/iot-llm-rag/config.xml');config=ET.fromstring(old)
 active=json.loads(read('/job/iot-llm-rag/api/json?tree=inQueue,lastBuild[building,number,result]'))
 assert not active['inQueue'] and not active['lastBuild']['building']
 script=config.find('definition/script');assert script.text==(stage/'tree/infra/ci/Rag.Jenkinsfile').read_text()
 (out/'job-before.xml').write_bytes(old)
 script.text=(stage/'tree/infra/ci/RagDrift.Jenkinsfile').read_text()
 params=config.findall('.//hudson.model.StringParameterDefinition');selected=next(x for x in params if x.find('name').text=='SOURCE_COMMIT')
 parents={c:p for p in config.iter() for c in p};parent=parents[selected]
 assert not any(x.find('name').text=='CORPUS_SCENARIO' for x in params)
 param=ET.SubElement(parent,'hudson.model.StringParameterDefinition')
 for key,value in [('name','CORPUS_SCENARIO'),('description','production or non-deployable out-of-domain control'),('defaultValue','production'),('trim','true')]:ET.SubElement(param,key).text=value
 ack=post('/job/iot-llm-rag/config.xml',ET.tostring(config),'application/xml')
 actual=read('/job/iot-llm-rag/config.xml');(out/'job-after.xml').write_bytes(actual)
 observed=ET.fromstring(actual);assert observed.find('definition/script').text==script.text
 # Compare the actual job after dropping only the deliberately changed pipeline and new parameter.
 def stripped(raw,new):
  x=ET.fromstring(raw);x.find('definition/script').text='PIPELINE';parents={c:p for p in x.iter() for c in p}
  if new:
   for item in x.findall('.//hudson.model.StringParameterDefinition'):
    if item.find('name').text=='CORPUS_SCENARIO':parents[item].remove(item)
  return ET.tostring(x)
 assert stripped(old,False)==stripped(actual,True)
 save('install.json',{'passed':True,'commit':a.commit,'files':len(seal['files']),'packet_sha256':a.sha256,'job':active,'ack':ack,'unrelated_job_fields_preserved':True})
elif a.mode=='launch':
 assert a.scenario in ['production','out-of-domain']
 job=json.loads(read('/job/iot-llm-rag/api/json?tree=inQueue,lastBuild[building],nextBuildNumber'))
 assert not job['inQueue'] and not job['lastBuild']['building']
 number=job['nextBuildNumber'];release=root/'data/ci/releases'/('llm-rag-jenkins-'+str(number))
 assert not release.exists()
 dag=root/'airflow/dags/ci/iot_ci_rag.py'
 before={'dag_sha256':sha256(dag.read_bytes()).hexdigest(),'releases':sorted(p.name for p in (root/'data/rag-releases').glob('*.json')),
         'run_directories':sorted(p.name for p in (root/'data/rag').iterdir()),'source_commit':a.commit,'scenario':a.scenario,'build':number}
 save(str(number)+'-before.json',before)
 ack=post('/job/iot-llm-rag/buildWithParameters',urlencode({'SOURCE_COMMIT':a.commit,'CORPUS_SCENARIO':a.scenario}).encode(),'application/x-www-form-urlencoded')
 save(str(number)+'-launch.json',{'commit':a.commit,'scenario':a.scenario,'build':number,**ack,'submitted_utc':datetime.now(timezone.utc).isoformat()});print(json.dumps({'build':number,**ack}))
elif a.mode=='observe':
 base='/job/iot-llm-rag/'+str(a.build);report={}
 for label,path in [('build','/api/json'),('stages','/wfapi/describe'),('console','/consoleText')]:
  raw=read(base+path);(out/(str(a.build)+'-'+label+('.txt' if label=='console' else '.json'))).write_bytes(raw)
  if label=='build':value=json.loads(raw);report={k:value.get(k) for k in ['number','building','result','duration']}
  elif label=='stages':report['stages']=[{'name':s['name'],'status':s['status']} for s in json.loads(raw)['stages']]
  elif not report['building']:report['console_tail']='\n'.join(raw.decode().splitlines()[-18:])
 print(json.dumps(report))
elif a.mode=='suite':
 build=json.loads((root/'data/ci/releases'/('llm-rag-jenkins-'+str(a.build))/'outputs/build.json').read_bytes())
 dest=out/'suite';dest.mkdir();dest.chmod(0o1777)
 cmd=['docker','run','--name','iot-rag-drift-suite-30a','--read-only','--network','none','--user','10001:10001','--memory','4g','--memory-swap','4g','--cpus','2','--pids-limit','256','--cap-drop','ALL','--security-opt','no-new-privileges','--tmpfs','/tmp:rw,nosuid,size=512m',
  '--env','HF_HOME=/models','--env','HF_HUB_OFFLINE=1','--env','TRANSFORMERS_OFFLINE=1','--mount','type=bind,src=/srv/iot-fast/models/iot-rag-embeddings,dst=/models,readonly','--mount','type=bind,src='+str(stage/'tree/infra/rag')+',dst=/policy,readonly','--mount','type=bind,src='+str(dest)+',dst=/result','--entrypoint','python',build['image_id'],'-B','-m','rag.corpus_drift','--source','/opt/iot-rag-release','--reference','/policy/corpus-reference.json','--protocol','/policy/corpus-drift-protocol.json','--output','/result/distance-report.json','--scenario','suite']
 with (dest/'console.txt').open('x') as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=660)
 value=json.loads(subprocess.check_output(['docker','inspect','iot-rag-drift-suite-30a']))[0]
 save('suite-container.json',{'image':value['Image'],'id':value['Id'],'state':value['State'],'memory_bytes':value['HostConfig']['Memory'],'nano_cpus':value['HostConfig']['NanoCpus']})
 assert result.returncode==0 and not value['State']['OOMKilled']
 print(json.dumps({k:v['decision'] for k,v in json.loads((dest/'distance-report.json').read_bytes())['candidates'].items()}))
