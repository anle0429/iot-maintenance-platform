from pathlib import Path
from urllib.request import build_opener,ProxyHandler
from time import monotonic
from urllib.error import HTTPError
import json,subprocess,sqlite3
r=Path('/srv/iot-data/workspace/iot-maintenance-platform');o=r/'outputs/observer-health-diagnosis-30a';o.mkdir(exist_ok=False);k=['/usr/local/bin/k3s','kubectl'];result={}
d=json.loads(subprocess.check_output(k+['get','deployment','iot-llm-observer','-n','iot-llm','-o','json']));(o/'deployment.json').write_text(json.dumps(d,indent=2)+'\n')
p=json.loads(subprocess.check_output(k+['get','pods','-n','iot-llm','-l','app.kubernetes.io/instance=iot-llm-observer','-o','json']));(o/'pods.json').write_text(json.dumps(p,indent=2)+'\n')
result['containers']=[v['status'].get('containerStatuses',[]) for v in p['items']]
for pod in p['items']:
 if pod['status']['phase']!='Running':continue
 for previous in [False,True]:
  cmd=k+['logs',pod['metadata']['name'],'-n','iot-llm','-c','observer','--tail=70','--timestamps']+(['--previous'] if previous else [])
  v=subprocess.run(cmd,capture_output=True,timeout=30);(o/('previous-logs.txt' if previous else 'current-logs.txt')).write_bytes(v.stdout+v.stderr)
path=next(v['hostPath']['path'] for v in d['spec']['template']['spec']['volumes'] if v['name']=='ledger');db=Path(path)/'telemetry.sqlite'
with sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True,timeout=5) as c:
 result['ledger_rows']=list(c.execute('select kind,count(*) from telemetry_events group by kind'))
 result['ledger_bytes']=db.stat().st_size
s=json.loads(subprocess.check_output(k+['get','service','iot-llm-observer','-n','iot-llm','-o','json']));(o/'service.json').write_text(json.dumps(s,indent=2)+'\n')
client=build_opener(ProxyHandler({}));health=[]
for path in ['/health/live','/health/ready']:
 start=monotonic()
 try:
  with client.open('http://'+s['spec']['clusterIP']+':8081'+path,timeout=20) as response:status=response.status;raw=response.read()
 except HTTPError as e:status=e.code;raw=e.read()
 except OSError as e:status=None;raw=type(e).__name__.encode()
 health.append({'path':path,'status':status,'elapsed':monotonic()-start,'body':raw.decode()})
result['health']=health
v=subprocess.run(k+['top','pod','-n','iot-llm','-l','app.kubernetes.io/instance=iot-llm-observer','--containers'],capture_output=True,timeout=20);(o/'top.txt').write_bytes(v.stdout+v.stderr);result['top']=v.stdout.decode()
(o/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
