"""Validate the retained demo substrate and stage one genuine fresh feature preparation, without rerunning completed jobs."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from urllib.request import build_opener,ProxyHandler
import json,subprocess,tarfile,os
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/learner-demo-preflight-30b';out.mkdir(exist_ok=False)
packet=Path('/tmp/learner-demo-source-30a.tar.gz');assert packet.stat().st_size==20124 and sha256(packet.read_bytes()).hexdigest()=='15ce64491e7a34ef7bfd2122567dc2a0f8a9c07350f6df0d00397a24b756e2e2'
source=root/'data/llm-source/learner-demo-f845b5b';assert source.is_dir()
seal=json.loads((source/'manifest.json').read_bytes());assert seal['commit']=='f845b5b604d341e335442c2f262a12b608da0c6e' and len(seal['files'])==14
for name,pin in seal['files'].items():assert sha256((source/'tree'/name).read_bytes()).hexdigest()==pin
(out/'source.json').write_bytes((source/'manifest.json').read_bytes())
tests=subprocess.run(['python3','-B','-m','unittest','discover','-s',str(source/'tree/tests'),'-p','test_agent_demo_selection.py'],capture_output=True,timeout=30)
(out/'tests.stdout').write_bytes(tests.stdout);(out/'tests.stderr').write_bytes(tests.stderr);assert tests.returncode==0
k=['/usr/local/bin/k3s','kubectl'];client=build_opener(ProxyHandler({}))
def save(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
def get(label,*q):
 raw=subprocess.check_output(k+['get',*q,'-o','json'],timeout=30,stderr=subprocess.PIPE);(out/(label+'.json')).write_bytes(raw);return json.loads(raw)
controller=get('controller-service','service','kagent-controller','-n','iot-agents')
with client.open('http://'+controller['spec']['clusterIP']+':8083/api/substrate/status',timeout=20) as response:actors=json.load(response)
save('actors-before.json',actors);assert not any(v['atespace']=='iot-agents' and v['status']=='Running' for v in actors['data']['actors'])
pools={'iot-'+r+'-pool' for r in ['retrieval','drift','coordinator']}
pods=get('workers','pods','-n','iot-agents','-l','ate.dev/worker-pool in ('+','.join(sorted(pools))+')')['items'];pods=[v for v in pods if not v['metadata'].get('deletionTimestamp')]
assert len(pods)==6 and all(v['status']['phase']=='Running' and all(c['ready'] for c in v['status'].get('containerStatuses',[])) for v in pods)
registered={v['workerPod']:v['ip'] for v in actors['data']['workers'] if v['workerNamespace']=='iot-agents' and v['workerPool'] in pools}
assert registered=={v['metadata']['name']:v['status']['podIP'] for v in pods}
gpu=get('gpu-service','service','iot-model-gpu','-n','iot-llm')
with client.open('http://'+gpu['spec']['clusterIP']+':8080/models',timeout=20) as response:models=json.load(response)
save('models.json',models);assert {v['id'] for v in models['data'] if v['status']['value']=='loaded'}=={'iot-qwen2.5-7b','iot-qwen2.5-1.5b'}
from urllib.error import HTTPError
for role in ['retrieval','drift']:
 d=get(role+'-mcp','deployment','iot-'+role+'-mcp','-n','iot-agents')
 assert d['status']['observedGeneration']==d['metadata']['generation'] and d['status']['updatedReplicas']==d['spec']['replicas']==2
 selector=','.join(key+'='+value for key,value in d['spec']['selector']['matchLabels'].items())
 owned=get(role+'-mcp-pods','pods','-n','iot-agents','-l',selector)['items'];owned=[p for p in owned if not p['metadata'].get('deletionTimestamp')]
 assert len(owned)==2 and all(p['status']['phase']=='Running' for p in owned)
 for pod in owned:
  with client.open('http://'+pod['status']['podIP']+':8080/health/live',timeout=15) as response:assert response.status==200
feature=get('feature-before','deployment','iot-feature-api','-n','iot-features')
seed_name=next(v['configMap']['name'] for v in feature['spec']['template']['spec']['volumes'] if v['name']=='seed')
seed=json.loads(subprocess.check_output(k+['get','configmap',seed_name,'-n','iot-features','-o','json'],timeout=30));context=json.loads(seed['data']['context.json'])
save('expired-context.json',context);save('expired-seed-identity.json',{'uid':seed['metadata']['uid'],'name':seed_name})
assert (datetime.now(timezone.utc)-datetime.fromisoformat(context['prepared_wall_utc'])).total_seconds()>3600
save('preparation-order.json',{'reason':'Both MCP liveness probes pass, but readiness depends on the expired feature lease. Prepare real data before requiring two ready endpoints. The positive agent runner still requires both ready replicas/endpoints after refresh.','old_prepared_wall_utc':context['prepared_wall_utc']})
helper=Path('/tmp/iot-refresh-demo-feature-29k.py');assert sha256(helper.read_bytes()).hexdigest()=='ec2be13e02a218a5e583c7006ce418648ee8bb1829acb1c5d9b10f89e41552c0'
remaining=(datetime.fromisoformat(json.loads((root/'data/runtime/ci/session.json').read_bytes())['auto_stop_utc'])-datetime.now(timezone.utc)).total_seconds();assert remaining>2400
cmd=['systemd-run','--unit=iot-feature-demo-30a','--property=RuntimeMaxSec=1800','python3','-B',str(helper),'--runtime-root',str(root),'--runtime-source',str(root/'data/observability-source-2fceb32/tree'),'--run','demo-final-30a','--output',str(root/'outputs/feature-demo-30a')]
r=subprocess.run(cmd,capture_output=True,timeout=30);(out/'refresh-launch.txt').write_bytes(r.stdout+r.stderr);assert r.returncode==0
unit=subprocess.check_output(['systemctl','show','iot-feature-demo-30a','-p','InvocationID','-p','ActiveState','-p','RuntimeMaxUSec']);(out/'refresh-unit.txt').write_bytes(unit)
(out/'operator.py').write_bytes(Path(__file__).read_bytes());save('verification.json',{'passed':True,'checked_utc':datetime.now(timezone.utc).isoformat(),'source_inputs':14,'native_selection_tests':2,'worker_addresses_current':6,'loaded_models':2,'feature_refresh_launched':True,'refresh_completed':False,'scope':'Read-only preflight and actual fresh SDK launch; not yet a completed lease or agent answer.'});print(unit.decode())
