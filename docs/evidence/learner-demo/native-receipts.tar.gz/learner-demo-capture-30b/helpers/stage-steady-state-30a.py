from pathlib import Path
from hashlib import sha256
import tarfile,json,subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');packet=Path('/tmp/steady-state-source-30a.tar.gz');assert sha256(packet.read_bytes()).hexdigest()=='e6ae8b89e0730ed0aadaf09ca39b64c123375e1ffac532dbb964c17694469821'
source=root/'data/llm-source/steady-cd42ddc';source.mkdir(exist_ok=False)
with tarfile.open(packet) as t:
 for m in t:assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
 t.extractall(source,filter='data')
seal=json.loads((source/'manifest.json').read_bytes());assert seal['commit']=='cd42ddcc5f223c020ab9a6953c941d9d48e48f89' and len(seal['files'])==3
for n,pin in seal['files'].items():assert sha256((source/'tree'/n).read_bytes()).hexdigest()==pin
out=root/'outputs/steady-state-stage-30a';out.mkdir(exist_ok=False)
r=subprocess.run(['python3','-B','-m','unittest','discover','-s',str(source/'tree/tests'),'-p','test_llm_steady_state.py'],cwd=source/'tree',capture_output=True,timeout=30);(out/'tests.stdout').write_bytes(r.stdout);(out/'tests.stderr').write_bytes(r.stderr);assert r.returncode==0
r=subprocess.run(['systemd-run','--unit=iot-llm-steady-state-30a','--property=RuntimeMaxSec=600','python3','-B',str(source/'tree/scripts/configure-llm-steady-state.py'),'--runtime-root',str(root),'--output',str(root/'outputs/llm-steady-state-30a')],capture_output=True,timeout=30);(out/'launch.txt').write_bytes(r.stdout+r.stderr);assert r.returncode==0
(out/'unit.txt').write_bytes(subprocess.check_output(['systemctl','show','iot-llm-steady-state-30a','-p','InvocationID','-p','ActiveState','-p','RuntimeMaxUSec']));(out/'operator.py').write_bytes(Path(__file__).read_bytes());print((out/'unit.txt').read_text())
