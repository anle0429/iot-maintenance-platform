"""Seal original paired sample exports, actual stream CI and the exact continued GPU evidence-reading cohort."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from urllib.parse import quote
import base64,json,os,re,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/learner-demo-capture-30b';os.umask(0o077);out.mkdir(exist_ok=False);private=[]

def credential(raw):
 if isinstance(raw,str):raw=raw.encode()
 if len(raw)>=12:
  private.append(raw)
  if raw.startswith(b'Bearer '):private.append(raw[7:])
def walk(value,key=''):
 if isinstance(value,dict):
  if value.get('name')=='Authorization' and isinstance(value.get('value'),str):credential(value['value'])
  if {'username','password'}<=set(value):credential(base64.b64encode((value['username']+':'+value['password']).encode()))
  for name,child in value.items():walk(child,name)
 elif isinstance(value,list):
  for child in value:walk(child,key)
 elif isinstance(value,str) and re.search('password|token|apikey|secretid|roleid|keysbase64|authorization',re.sub('[^a-z]','',key.lower())):credential(value)
paths=[root/'data/runtime/secrets'/n for n in ['agent-platform.json','mcp-tools.json']]
paths.extend(root/'data/runtime/agent-vault-29a-private'/n for n in ['gateway-credentials.json','gateway-approle.json','services-approle.json'])
paths.extend([root/'data/runtime/agent-gateway-29a-private/credentials.json',root/'data/runtime/gateway-28-private/credentials.json',root/'data/runtime/ci/jenkins-private/bootstrap.json'])
paths.extend(root/'data/runtime/vault-28-private'/n for n in ['ci-approle.json','gateway-approle.json','bootstrap.json'])
for path in paths:walk(json.loads(path.read_bytes()))
jenkins=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());credential(base64.b64encode(('learner:'+jenkins['admin_password']).encode()));jenkins=None
credential((root/'data/runtime/llm-monitoring-29a/auth/token').read_bytes().strip())
k=['/usr/local/bin/k3s','kubectl'];refs={('iot-llm','iot-llm-observer-client','API_KEY'),('iot-agents','iot-local-model-client','API_KEY')}
def get(*args):return json.loads(subprocess.check_output(k+['get',*args,'-o','json'],timeout=30,stderr=subprocess.PIPE))
for deployment in get('deployments','-n','iot-agents')['items']:
 for container in deployment['spec']['template']['spec']['containers']:
  for item in container.get('env',[]):
   ref=item.get('valueFrom',{}).get('secretKeyRef')
   if ref and re.search('password|token|key|auth',ref['key'],re.I):refs.add(('iot-agents',ref['name'],ref['key']))
for remote in get('remotemcpservers','-n','iot-agents')['items']:
 for header in remote['spec'].get('headersFrom',[]):
  ref=header.get('valueFrom',{})
  if ref.get('type')=='Secret':refs.add(('iot-agents',ref['name'],ref['key']))
for namespace,name,key in sorted(refs):
 secret=get('secret',name,'-n',namespace);credential(base64.b64decode(secret['data'][key]));secret=None
for value in json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes())['keys_base64']:credential(value)
private=list({v for raw in private for v in [raw,base64.b64encode(raw),base64.b64encode(b'Bearer '+raw),quote(raw.decode(),safe='').encode()]})
def keep(name,body):
 assert len(body)<10000000 and not any(v in body for v in private),name
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
def copy(label,folder):
 assert folder.is_dir(),folder
 for parent,dirs,files in os.walk(folder):
  dirs[:]=[v for v in dirs if v!='__pycache__']
  for name in sorted(files):
   p=Path(parent)/name;assert not p.is_symlink();keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())



folders=['learner-demo-preflight-30a','learner-demo-preflight-30b','learner-demo-diagnosis-30a','feature-demo-30a','learner-demo-launch-30a','learner-demo-launch-30b','learner-demo-30a','learner-demo-30b','llm-route-diagnosis-30a','observer-health-diagnosis-30a','steady-state-stage-30a','llm-steady-state-30a']
for name in folders:copy('native/'+name,root/'outputs'/name)
for name in ['learner-demo-f845b5b','steady-cd42ddc']:copy('source/'+name,root/'data/llm-source'/name)
for name in ['model-pin.json','portable.json']:keep('models/'+name,(root/'data/ci/releases/serve-jenkins-8/bundle'/name).read_bytes())
for name in ['context.json','_READY.json','verification.json']:keep('feature-state/'+name,(root/'data/demo/demo-final-30a/state'/name).read_bytes())
keep('baseline/observer.json',(root/'outputs/llm-ab-models-deploy-30b/iot-llm-observer-before.stdout').read_bytes())
for name in ['iot-refresh-demo-feature-29k.py','prepare-learner-demo-30a.py','prepare-learner-demo-30b.py','diagnose-learner-demo-30a.py','launch-learner-demo-30a.py','launch-learner-demo-30b.py','diagnose-llm-route-30a.py','inspect-observer-health-30a.py','read-observer-events-30a.py','stage-steady-state-30a.py']:
 keep('helpers/'+name,Path('/tmp/'+name).read_bytes())
for unit in ['iot-feature-demo-30a','iot-learner-demo-30a','iot-learner-demo-30b','iot-llm-steady-state-30a','iot-learner-ui-30a']:
 keep('units/'+unit+'.journal.jsonl',subprocess.check_output(['journalctl','-u',unit,'--no-pager','-o','json']))
 keep('units/'+unit+'.show.txt',subprocess.check_output(['systemctl','show',unit,'-p','InvocationID','-p','ActiveState','-p','Result','-p','ExecMainStatus','-p','RuntimeMaxUSec']))
keep('helpers/capture.py',Path(__file__).read_bytes())
manifest={'captured_utc':datetime.now(timezone.utc).isoformat(),'current_native_credentials_scanned':True,'vault_root_and_unseal_scanned':True,'workloads_rerun_for_capture':False,'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode());archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'x:gz') as t:t.add(out,arcname=out.name)
archive.chmod(0o644);print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'payloads':len(manifest['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()}))
