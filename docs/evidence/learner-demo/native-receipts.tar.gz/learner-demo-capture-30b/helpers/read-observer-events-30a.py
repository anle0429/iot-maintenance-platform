from pathlib import Path
import json,subprocess
r=Path('/srv/iot-data/workspace/iot-maintenance-platform');o=r/'outputs/observer-health-diagnosis-30a';p=json.loads((o/'pods.json').read_bytes())['items'][0]
v=subprocess.check_output(['/usr/local/bin/k3s','kubectl','get','events','-n','iot-llm','--field-selector','involvedObject.uid='+p['metadata']['uid'],'-o','json'],timeout=30);(o/'events.json').write_bytes(v)
print(json.dumps([{'reason':v.get('reason'),'count':v.get('count'),'message':v.get('message'),'last':v.get('lastTimestamp')} for v in json.loads(v)['items']]))
print((o/'previous-logs.txt').read_text()[-1800:])
