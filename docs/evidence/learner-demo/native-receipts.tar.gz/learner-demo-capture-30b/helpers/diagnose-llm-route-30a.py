from pathlib import Path
from urllib.request import build_opener,ProxyHandler
from urllib.error import HTTPError
import json,subprocess
r=Path('/srv/iot-data/workspace/iot-maintenance-platform');o=r/'outputs/llm-route-diagnosis-30a';o.mkdir(exist_ok=False);k=['/usr/local/bin/k3s','kubectl'];client=build_opener(ProxyHandler({}));summary={}
def get(label,*q):
 raw=subprocess.check_output(k+['get',*q,'-o','json'],stderr=subprocess.PIPE,timeout=30);(o/(label+'.json')).write_bytes(raw);return json.loads(raw)
for name in ['iot-router-epp','iot-model-control','iot-llm-observer','iot-model-gpu']:
 d=get(name,'deployment',name,'-n','iot-llm');summary[name]={'uid':d['metadata']['uid'],'generation':d['metadata']['generation'],'status':d['status']}
 selector=','.join(k+'='+v for k,v in d['spec']['selector']['matchLabels'].items());p=get(name+'-pods','pods','-n','iot-llm','-l',selector)
 summary[name]['pods']=[{'name':v['metadata']['name'],'phase':v['status']['phase'],'ip':v['status'].get('podIP'),'containers':[{f:c.get(f) for f in ['name','ready','restartCount','state']} for c in v['status'].get('containerStatuses',[])]} for v in p['items']]
 if name=='iot-router-epp':
  for pod in p['items']:
   if pod['status']['phase']!='Running':continue
   for c in pod['spec']['containers']:
    v=subprocess.run(k+['logs',pod['metadata']['name'],'-n','iot-llm','-c',c['name'],'--tail=80','--timestamps'],capture_output=True,timeout=30);(o/(c['name']+'-logs.txt')).write_bytes(v.stdout+v.stderr)
 if name!='iot-router-epp':
  s=get(name+'-service','service',name,'-n','iot-llm');url='http://'+s['spec']['clusterIP']+':8080/health'
  try:
   with client.open(url,timeout=10) as response:status=response.status;raw=response.read(4096)
  except HTTPError as e:status=e.code;raw=e.read(4096)
  except OSError as e:status=None;raw=type(e).__name__.encode()
  summary[name]['health']={'status':status,'body':raw.decode()}
pool=get('pool','inferencepool.inference.networking.k8s.io','iot-router','-n','iot-llm');summary['pool']=pool['spec']
(o/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
