from pathlib import Path
from urllib.request import build_opener,ProxyHandler
from urllib.error import HTTPError
import json,subprocess
r=Path('/srv/iot-data/workspace/iot-maintenance-platform');o=r/'outputs/learner-demo-diagnosis-30a';o.mkdir(exist_ok=False);k=['/usr/local/bin/k3s','kubectl'];client=build_opener(ProxyHandler({}));rows=[]
for role in ['retrieval','drift']:
 name='iot-'+role+'-mcp';d=json.loads(subprocess.check_output(k+['get','deployment',name,'-n','iot-agents','-o','json']));(o/(role+'-deployment.json')).write_text(json.dumps(d,indent=2)+'\n')
 selector=','.join(k+'='+v for k,v in d['spec']['selector']['matchLabels'].items());p=json.loads(subprocess.check_output(k+['get','pods','-n','iot-agents','-l',selector,'-o','json']));(o/(role+'-pods.json')).write_text(json.dumps(p,indent=2)+'\n')
 for pod in p['items']:
  if pod['metadata'].get('deletionTimestamp'):continue
  for path in ['/health/live','/health/ready']:
   url='http://'+pod['status']['podIP']+':8080'+path
   try:
    with client.open(url,timeout=15) as response:status=response.status;body=response.read()
   except HTTPError as error:status=error.code;body=error.read()
   rows.append({'role':role,'pod':pod['metadata']['name'],'phase':pod['status']['phase'],'path':path,'status':status,'body':body.decode()})
(o/'health.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'deployments':{role:{'desired':json.loads((o/(role+'-deployment.json')).read_text())['spec']['replicas'],'status':json.loads((o/(role+'-deployment.json')).read_text())['status']} for role in ['retrieval','drift']},'health':rows}))
