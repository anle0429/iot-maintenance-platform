from pathlib import Path
from datetime import datetime,timezone
from urllib.request import build_opener,ProxyHandler
from hashlib import sha256
import json,subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/learner-demo-launch-30b';out.mkdir(exist_ok=False)
steady=json.loads((root/'outputs/llm-steady-state-30a/verification.json').read_bytes());assert steady['passed'] and steady['stable_samples']==13 and steady['stable_seconds']>=180
f=json.loads((root/'outputs/feature-demo-30a/verification.json').read_bytes());assert f['passed'] and (datetime.fromisoformat(f['lease_expires_utc'])-datetime.now(timezone.utc)).total_seconds()>600
k=['/usr/local/bin/k3s','kubectl'];client=build_opener(ProxyHandler({}))
def get(label,*q):
 raw=subprocess.check_output(k+['get',*q,'-o','json'],timeout=30,stderr=subprocess.PIPE);(out/(label+'.json')).write_bytes(raw);return json.loads(raw)
s=get('controller-service','service','kagent-controller','-n','iot-agents')
with client.open('http://'+s['spec']['clusterIP']+':8083/api/substrate/status',timeout=20) as response:actors=json.load(response)
(out/'actors-before.json').write_text(json.dumps(actors,indent=2)+'\n');assert not any(v['atespace']=='iot-agents' and v['status']=='Running' for v in actors['data']['actors'])
pools={'iot-'+r+'-pool' for r in ['retrieval','drift','coordinator']};pods=get('workers','pods','-n','iot-agents','-l','ate.dev/worker-pool in ('+','.join(sorted(pools))+')')['items'];pods=[p for p in pods if not p['metadata'].get('deletionTimestamp')]
assert len(pods)==6 and all(p['status']['phase']=='Running' and all(c['ready'] for c in p['status']['containerStatuses']) for p in pods)
registered={v['workerPod']:v['ip'] for v in actors['data']['workers'] if v['workerNamespace']=='iot-agents' and v['workerPool'] in pools};assert registered=={p['metadata']['name']:p['status']['podIP'] for p in pods}
source=root/'data/llm-source/learner-demo-f845b5b/tree';seal=json.loads((source.parent/'manifest.json').read_bytes())
for n,pin in seal['files'].items():assert sha256((source/n).read_bytes()).hexdigest()==pin
r=subprocess.run(['systemd-run','--unit=iot-learner-demo-30b','--property=RuntimeMaxSec=600','python3','-B',str(source/'scripts/run-agent-demo.py'),'--runtime-root',str(root),'--source',str(source),'--deployment',str(root/'outputs/agent-gateway-29a'),'--credentials',str(root/'data/runtime/agent-gateway-29a-private/credentials.json'),'--output',str(root/'outputs/learner-demo-30b')],capture_output=True,timeout=30);(out/'launch.txt').write_bytes(r.stdout+r.stderr);assert r.returncode==0
(out/'unit.txt').write_bytes(subprocess.check_output(['systemctl','show','iot-learner-demo-30b','-p','InvocationID','-p','ActiveState','-p','RuntimeMaxUSec']));(out/'operator.py').write_bytes(Path(__file__).read_bytes());print((out/'unit.txt').read_text())
