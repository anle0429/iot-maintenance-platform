"""Require completed genuine feature preparation and ready MCP replicas before one protected learner conversation."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,socket,os
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/learner-demo-launch-30a';out.mkdir(exist_ok=False)
feature=json.loads((root/'outputs/feature-demo-30a/verification.json').read_bytes());assert feature['passed'] and feature['machines']==200 and feature['source_sha256']=='ec2be13e02a218a5e583c7006ce418648ee8bb1829acb1c5d9b10f89e41552c0'
assert (datetime.fromisoformat(feature['lease_expires_utc'])-datetime.now(timezone.utc)).total_seconds()>600
(out/'feature-acceptance.json').write_text(json.dumps(feature,indent=2)+'\n')
k=['/usr/local/bin/k3s','kubectl']
for role in ['retrieval','drift']:
 result=subprocess.run(k+['rollout','status','deployment/iot-'+role+'-mcp','-n','iot-agents','--timeout=90s'],capture_output=True,timeout=100)
 (out/(role+'-ready.txt')).write_bytes(result.stdout+result.stderr);assert result.returncode==0
source=root/'data/llm-source/learner-demo-f845b5b/tree';seal=json.loads((source.parent/'manifest.json').read_bytes())
for name,pin in seal['files'].items():assert sha256((source/name).read_bytes()).hexdigest()==pin
cmd=['systemd-run','--unit=iot-learner-demo-30a','--property=RuntimeMaxSec=600','python3','-B',str(source/'scripts/run-agent-demo.py'),'--runtime-root',str(root),'--source',str(source),'--deployment',str(root/'outputs/agent-gateway-29a'),'--credentials',str(root/'data/runtime/agent-gateway-29a-private/credentials.json'),'--output',str(root/'outputs/learner-demo-30a')]
r=subprocess.run(cmd,capture_output=True,timeout=30);(out/'launch.txt').write_bytes(r.stdout+r.stderr);assert r.returncode==0
(out/'unit.txt').write_bytes(subprocess.check_output(['systemctl','show','iot-learner-demo-30a','-p','InvocationID','-p','ActiveState','-p','RuntimeMaxUSec']))
viewer=Path('/tmp/view-agent-gateway.py');assert sha256(viewer.read_bytes()).hexdigest()=='b19170abf22cd39c37197354b8dc9ba852d7c8651030af1606b35a18a2535cba'
with socket.socket() as sock:sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);sock.bind(('127.0.0.1',18090))
gateway=json.loads(subprocess.check_output(k+['get','service','iot-gateway','-n','iot-gateway','-o','json']))['spec']['clusterIP']
r=subprocess.run(['systemd-run','--unit=iot-learner-ui-30a','--property=RuntimeMaxSec=2700','--property=NoNewPrivileges=yes','--property=ProtectSystem=strict','--property=ReadWritePaths='+str(out),'python3','-B',str(viewer),'--role','agents','--gateway-ip',gateway,'--ca',str(root/'outputs/agent-gateway-29a/ca.crt'),'--credentials',str(root/'data/runtime/agent-gateway-29a-private/credentials.json'),'--audit',str(out/'ui-transport.jsonl')],capture_output=True,timeout=30)
(out/'ui-launch.txt').write_bytes(r.stdout+r.stderr);assert r.returncode==0
(out/'viewer.py').write_bytes(viewer.read_bytes());(out/'ui-unit.txt').write_bytes(subprocess.check_output(['systemctl','show','iot-learner-ui-30a','-p','InvocationID','-p','ActiveState','-p','RuntimeMaxUSec']))
(out/'operator.py').write_bytes(Path(__file__).read_bytes());print((out/'unit.txt').read_text()+(out/'ui-unit.txt').read_text())
