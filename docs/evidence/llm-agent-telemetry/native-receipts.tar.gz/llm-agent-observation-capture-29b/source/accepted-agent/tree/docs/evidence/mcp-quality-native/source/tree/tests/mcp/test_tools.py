"""Exercise real MCP/REST contracts, boundary partitions and repeatable native-backend adaptation with explicit fixtures."""
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import asyncio
import json
import tempfile
from types import SimpleNamespace
import pytest

pytest.importorskip('mcp',reason='Install infra/mcp/requirements.txt in the dedicated MCP test environment')
import httpx2
from fastapi.testclient import TestClient
from hypothesis import given, settings, strategies as st
from pydantic import ValidationError
from services.mcp_tools.app import create_app
from services.mcp_tools.auth import BoundedBearerMiddleware
from services.mcp_tools.contracts import MachineRequest, SearchRequest, DriftRequest, MachineData, PredictionData, DriftAssessment
from services.mcp_tools.runtime import ToolRuntime, ToolFailure, KnowledgeReader
from services.mcp_tools.snapshot import prepare, NAMES
from services.drift_api.detector import DriftDetector
from services.drift_api.runtime import DriftRuntime
from services.drift_api.contracts import CompareRequest

TOKEN = 'unit-test-only-credential-' + 'x'*32
HEADERS = {'Authorization':'Bearer '+TOKEN}
VALUES = {'temperature_mean_10m':30.,'vibration_max_10m':1.,'current_mean_10m':2.,'current_std_10m':.1,
          'rpm_mean_10m':1200.,'reading_count_10m':10,'machine_age_days':30.,'prior_failures_24h':0}
BUNDLE = {'format':'iot-drift-reference-v1','lineage':{'model_version':'fixture'},
          'policy':{'bins':10,'psi_threshold':.2,'drifted_feature_fraction':.25,'pseudocount':.5},'samples':[VALUES]*32}
REFERENCE = DriftDetector(BUNDLE).reference_id


def machine(identifier='P-001'):
    """Supply a transparent small simulated snapshot with independently specified timestamps and provenance."""
    return {'machine_id':identifier,'features':deepcopy(VALUES),'feature_event_ts':'2026-10-01T00:00:00+00:00',
            'feature_age_seconds':300.,'operating_context':{'status':'failed' if identifier=='P-006' else 'operating',
            'event_ts':'2026-10-01T00:00:00+00:00','received_ts':'2026-10-01T00:02:00+00:00'},
            'as_of':'2026-10-01T00:05:00+00:00','clock_mode':'simulation','prepared_wall_utc':'2026-10-29T04:00:00+00:00',
            'protocol_sha256':'a'*64,'source_manifest_sha256':'b'*64}


def prediction(identifier='P-001'):
    """Return a low synthetic score whose decision agrees with the declared threshold and source protocol."""
    return {'prediction':{'risk_score':.1,'predicted_failure':0},'feature_trace':machine(identifier),
            'model':{'production':True,'threshold':.7,'protocol_sha256':'a'*64,'version':'fixture'}}


class SmallKnowledge:
    """Isolate endpoint contracts from encoder dependencies while native SDK execution is checked on the VM."""
    def search(self, request):
        """Return one explicit source fixture without inferring relevance from generated text."""
        return {'matches':[{'chunk_id':'c'*64,'document_id':'fixture','text':'A stopped pump is not eligible for prediction.'}],
                'question':request.question}


def make_backends(tmp_path):
    """Use real drift calculations/storage behind a transport fixture and keep every outgoing payload observable."""
    detector = DriftRuntime(BUNDLE,tmp_path/'drift.db'); observed = []
    def handle(request):
        """Implement only the declared fixed native routes; reject unexpected URLs instead of making network calls."""
        observed.append((str(request.url),request.content))
        if request.url.path=='/health/ready': return httpx2.Response(200,json={'ready':True,'reference_id':REFERENCE})
        if request.url.path=='/v1/drift:compare':
            return httpx2.Response(200,json=detector.compare(CompareRequest.model_validate_json(request.content)))
        identifier = request.url.path.split('/')[3].split(':')[0]
        if identifier=='P-999':return httpx2.Response(404,json={'private_detail':'do not expose this'})
        if request.url.path.endswith(':predict'):
            return httpx2.Response(409 if identifier=='P-006' else 200,json={} if identifier=='P-006' else prediction(identifier))
        return httpx2.Response(200,json=machine(identifier))
    client = httpx2.AsyncClient(transport=httpx2.MockTransport(handle),timeout=2)
    return client,observed,detector


@pytest.fixture
def backends(tmp_path):
    """Give each endpoint test a separate durable assessment table and transport fixture."""
    return make_backends(tmp_path)


@pytest.fixture
def retrieval(backends):
    """Run actual HTTP/auth/MCP handling with a native-client fixture and an explicitly fake encoder boundary."""
    runtime = ToolRuntime('retrieval',REFERENCE,SmallKnowledge(),backends[0])
    with TestClient(create_app(runtime,'retrieval',TOKEN)) as client: yield client,backends[1]


@pytest.mark.parametrize('identifier',['P-001','P-9999'])
def test_machine_identity_boundaries(retrieval,identifier):
    """Valid three- and four-digit IDs reach the declared backend unchanged."""
    response = retrieval[0].get('/v1/machines/'+identifier+'/features',headers=HEADERS)
    assert response.status_code==200 and response.json()['machine_id']==identifier


@pytest.mark.parametrize('identifier',['P-01','P-00000','X-001','P-abc'])
def test_invalid_machine_partition_never_calls_backend(retrieval,identifier):
    """Reject malformed identifiers before a request can reach any native endpoint."""
    assert retrieval[0].get('/v1/machines/'+identifier+'/features',headers=HEADERS).status_code==422
    assert retrieval[1]==[]


def test_authorization_unknown_machine_and_stopped_prediction(retrieval):
    """Distinguish missing/wrong access, missing entities and a legitimate stopped-machine rejection."""
    client,_=retrieval
    for headers in [{},{'Authorization':'Bearer wrong'},{'Authorization':'Basic '+TOKEN}]:
        assert client.get('/v1/machines/P-001/features',headers=headers).status_code==401
    assert client.get('/health/live').status_code==200
    assert client.get('/health/ready').status_code==200
    assert client.get('/v1/machines/P-999/features',headers=HEADERS).status_code==404
    assert client.post('/v1/machines/P-006:predict',headers=HEADERS).status_code==409
    assert client.post('/v1/machines/P-001:predict',headers=HEADERS).json()['model']['version']=='fixture'
    assert client.post('/v1/machines/P-001:predict',headers=HEADERS).json()['feature_trace']==client.get('/v1/machines/P-001/features',headers=HEADERS).json()
    assert 'private_detail' not in client.get('/v1/machines/P-999/features',headers=HEADERS).text


@pytest.mark.parametrize('length,code',[(4,422),(5,200),(1000,200),(1001,422)])
def test_question_length_boundaries(retrieval,length,code):
    """Check both accepted edges and adjacent rejected lengths at the actual REST boundary."""
    assert retrieval[0].post('/v1/knowledge:search',headers=HEADERS,json={'question':'q'*length}).status_code==code


@pytest.mark.parametrize('count,valid',[(31,False),(32,True),(200,True),(201,False)])
def test_cohort_size_boundaries(count,valid):
    """Require sufficient unique machines without allowing an unbounded bulk request."""
    payload={'window_id':'boundary','machine_ids':[f'P-{i:03}' for i in range(count)]}
    if valid: assert len(DriftRequest.model_validate(payload).machine_ids)==count
    else:
        with pytest.raises(ValidationError):DriftRequest.model_validate(payload)


def test_extra_fields_duplicate_cohort_and_strict_numeric_inputs():
    """Caller-supplied labels, URL overrides, duplicate IDs and string/bool counts cannot change a tool's meaning."""
    for data in [{'question':'A valid question','url':'http://outside'},{'question':'A valid question','top_k':True},
                 {'question':'A valid question','top_k':'3'},{'question':'A valid question','top_k':0},{'question':'A valid question','top_k':4}]:
        with pytest.raises(ValidationError):SearchRequest.model_validate(data)
    with pytest.raises(ValidationError):DriftRequest(window_id='duplicate',machine_ids=['P-001']*32)
    with pytest.raises(ValidationError):MachineRequest(machine_id='P-001',failure_label=1)


def test_actual_mcp_discovery_validation_and_execution(retrieval):
    """Use JSON-RPC tools/list and tools/call rather than treating an ordinary REST call as MCP proof."""
    client,_=retrieval; headers={**HEADERS,'Accept':'application/json, text/event-stream'}
    listed=client.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':1,'method':'tools/list','params':{}})
    assert {tool['name'] for tool in listed.json()['result']['tools']}=={'get_machine_features','predict_failure','search_knowledge'}
    response=client.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':2,'method':'tools/call',
        'params':{'name':'get_machine_features','arguments':{'request':{'machine_id':'P-001'}}}})
    result=response.json()['result'];assert not result['isError']
    assert json.loads(result['content'][0]['text'])['machine_id']=='P-001'
    for name,args in [('predict_failure',{'machine_id':'P-006'}),('get_machine_features',{'machine_id':'invalid'})]:
        result=client.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':3,'method':'tools/call',
            'params':{'name':name,'arguments':{'request':args}}}).json()['result']
        assert result['isError']
    result=client.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':4,'method':'tools/call',
        'params':{'name':'search_knowledge','arguments':{'request':{'question':'Why is prediction unavailable?'}}}}).json()['result']
    assert not result['isError'] and json.loads(result['content'][0]['text'])['matches']
    text=client.get('/metrics').text
    assert 'iot_mcp_tool_calls_total' in text and 'result="failure"' in text and 'P-001' not in text and TOKEN not in text


def test_drift_role_and_real_cached_assessment(backends):
    """The drift role cannot discover retrieval tools, and replay returns the same stored actual calculation."""
    runtime=ToolRuntime('drift',REFERENCE,client=backends[0]);headers={**HEADERS,'Accept':'application/json, text/event-stream'}
    with TestClient(create_app(runtime,'drift',TOKEN)) as client:
        assert client.get('/health/ready').status_code==200
        tools=client.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':1,'method':'tools/list'}).json()['result']['tools']
        assert [tool['name'] for tool in tools]==['assess_feature_drift']
        body={'window_id':'fixture-window','machine_ids':[f'P-{i:03}' for i in range(1,33)]}
        first=client.post('/v1/drift:assess',headers=HEADERS,json=body)
        second=client.post('/v1/drift:assess',headers=HEADERS,json=dict(body,machine_ids=list(reversed(body['machine_ids']))))
        assert first.status_code==second.status_code==200 and first.json()==second.json()
        assert first.json()['unique_rows']==32 and not first.json()['drift_detected']
        assert backends[2].ready()['stored_windows']==1
        result=client.post('/mcp',headers=headers,json={'jsonrpc':'2.0','id':2,'method':'tools/call',
            'params':{'name':'assess_feature_drift','arguments':{'request':body}}}).json()['result']
        assert not result['isError'] and json.loads(result['content'][0]['text'])==first.json()


@settings(max_examples=12,deadline=None)
@given(st.permutations(tuple(f'P-{i:03}' for i in range(1,33))))
def test_cohort_replay_is_independent_of_input_order(machine_ids):
    """Permuted/repeated cohorts retain the same HTTP payload, result and single durable assessment."""
    with tempfile.TemporaryDirectory() as directory:
        client,observed,detector=make_backends(Path(directory))
        runtime=ToolRuntime('drift',REFERENCE,client=client)
        with TestClient(create_app(runtime,'drift',TOKEN)) as api:
            body={'window_id':'property-window','machine_ids':list(machine_ids)}
            first=api.post('/v1/drift:assess',headers=HEADERS,json=body)
            replay=api.post('/v1/drift:assess',headers=HEADERS,json=dict(body,machine_ids=sorted(machine_ids)))
            assert first.status_code==replay.status_code==200 and first.json()==replay.json()
            requests=[raw for url,raw in observed if url.endswith('/v1/drift:compare')]
            assert requests[0]==requests[1] and detector.ready()['stored_windows']==1


@pytest.mark.parametrize('change',[{'feature_age_seconds':299.},{'clock_mode':'wall'},{'feature_event_ts':'2026-10-02T00:00:00+00:00'},
                                 {'protocol_sha256':'not-a-hash'}])
def test_native_feature_output_is_not_trusted_blindly(change):
    """Reject internally inconsistent or untraceable upstream records even if their HTTP status was successful."""
    with pytest.raises(ValidationError):MachineData.model_validate(dict(machine(),**change))


@pytest.mark.parametrize('context',[{'status':'unknown'},{'received_ts':'2026-10-02T00:00:00+00:00'},
                                    {'received_ts':'2026-09-30T23:59:59+00:00'}, {'event_ts':'2026-09-30T23:00:00+00:00'}])
def test_native_operating_context_boundaries(context):
    """Reject unsupported state, future arrival, arrival before observation and stale operating context."""
    raw=machine();raw['operating_context'].update(context)
    with pytest.raises(ValidationError):MachineData.model_validate(raw)


@pytest.mark.parametrize('score,decision,threshold',[(float('nan'),0,.7),(-.1,0,.7),(1.1,1,.7),(.1,1,.7),(.1,False,.7),(.1,0,True)])
def test_native_prediction_boundary_failures(score,decision,threshold):
    """A native score/decision must obey the actual probability and threshold contract."""
    raw=prediction();raw['prediction']={'risk_score':score,'predicted_failure':decision};raw['model']['threshold']=threshold
    with pytest.raises(ValidationError):PredictionData.model_validate(raw)


@pytest.mark.parametrize('change',['production','protocol','stopped'])
def test_prediction_requires_the_actual_native_binding(change):
    """Even a numerically valid score is unavailable when provenance or operating eligibility disagrees."""
    raw=prediction()
    if change=='production':raw['model']['production']=False
    elif change=='protocol':raw['model']['protocol_sha256']='c'*64
    else:raw['feature_trace']['operating_context']['status']='failed'
    with pytest.raises(ValidationError):PredictionData.model_validate(raw)


@pytest.mark.parametrize('status,payload',[(302,{}),(429,{}),(200,[]),(200,{'machine_id':'P-002'}),(200,{'unexpected':'value'})])
def test_invalid_upstream_http_and_payloads_fail_closed(status,payload):
    """Do not follow redirects, forward private failure bodies or present malformed native records as data."""
    async def execute():
        """Observe the public failure category while closing the injected client normally."""
        client=httpx2.AsyncClient(transport=httpx2.MockTransport(lambda request:httpx2.Response(status,json=payload)))
        runtime=ToolRuntime('retrieval',REFERENCE,SmallKnowledge(),client)
        try:
            with pytest.raises(ToolFailure) as error:await runtime.features(MachineRequest(machine_id='P-001'))
            assert error.value.status==503
        finally:await runtime.close()
    asyncio.run(execute())


def test_missing_or_failed_knowledge_and_wrong_reference_are_not_ready():
    """Differentiate absent knowledge, a crashed reader and a changed deployed drift baseline."""
    class BrokenKnowledge:
        """Represent an unavailable native encoder/store boundary."""
        def search(self,request):
            """Fail with private diagnostics that must be replaced by a safe tool error."""
            raise RuntimeError('private local path')
    async def execute():
        """Exercise readiness and safe failure translation without changing native services."""
        client=httpx2.AsyncClient(transport=httpx2.MockTransport(lambda request:httpx2.Response(200,json={'ready':True,'reference_id':'wrong'})))
        runtime=ToolRuntime('retrieval',REFERENCE,client=client)
        try:
            with pytest.raises(ToolFailure):await runtime.search(SearchRequest(question='valid question'))
            with pytest.raises(ToolFailure):await runtime.ready()
            runtime.knowledge=BrokenKnowledge()
            with pytest.raises(ToolFailure) as error:await runtime.search(SearchRequest(question='valid question'))
            assert str(error.value)=='Knowledge store is unavailable or invalid'
            runtime.role='drift'
            with pytest.raises(ToolFailure):await runtime.ready()
        finally:await runtime.close()
    asyncio.run(execute())


@pytest.mark.parametrize('change',['feature','policy','score','fraction'])
def test_drift_output_consistency(change,tmp_path):
    """Require a complete fixed-policy assessment instead of trusting a successful HTTP status."""
    state=DriftRuntime(BUNDLE,tmp_path/'result.db')
    rows=[{'id':str(i),'event_timestamp':'2026-10-01T00:00:00Z','available_at':'2026-10-01T00:00:00Z','features':VALUES} for i in range(32)]
    raw=state.compare(CompareRequest(reference_id=REFERENCE,window_id='known',start='2026-10-01T00:00:00Z',end='2026-10-01T00:01:00Z',observations=rows))
    if change=='feature':raw['features'].pop('rpm_mean_10m')
    elif change=='policy':raw['policy']=dict(raw['policy'],psi_threshold=.9)
    elif change=='score':raw['features']['rpm_mean_10m']['drifted']=True
    else:raw['drifted_feature_fraction']=.5
    with pytest.raises(ValidationError):DriftAssessment.model_validate(raw)


def test_configuration_rejects_unknown_role_and_missing_secret():
    """No endpoint is created under a permissive default credential or unknown role."""
    with pytest.raises(ValueError):create_app(role='shell',token=TOKEN)
    with pytest.raises(ValueError):create_app(role='retrieval',token='short')
    with pytest.raises(ValueError):ToolRuntime('shell','')
    with pytest.raises(ValueError):BoundedBearerMiddleware(None,'short')


def test_body_framing_and_transport_host_controls(retrieval):
    """Reject excessive/mismatched framing and a foreign MCP Host before executing any tool."""
    client,_=retrieval
    for length,content,code in [('65537',b'{}',413),('not-a-number',b'{}',411),('1',b'{}',400)]:
        response=client.post('/v1/knowledge:search',headers={**HEADERS,'Content-Length':length,'Content-Type':'application/json'},content=content)
        assert response.status_code==code
    response=client.post('/mcp',headers={**HEADERS,'Accept':'application/json, text/event-stream','Host':'foreign.example'},
                         json={'jsonrpc':'2.0','id':1,'method':'tools/list'})
    assert response.status_code==421


def test_body_guard_counts_stream_bytes_and_preserves_disconnect():
    """A false small length cannot bypass the cap, and a checked replay cannot hide client disconnect."""
    async def scenario(oversized):
        """Drive the ASGI component with explicit body/disconnect events, independent of HTTP-client framing."""
        events=[{'type':'http.request','body':b'x'*65537 if oversized else b'{}','more_body':False},{'type':'http.disconnect'}]
        sent=[];received=[]
        async def receive():
            """Return the original transport's next body or disconnect event."""
            return events.pop(0)
        async def send(event):
            """Retain public HTTP response messages for the boundary assertion."""
            sent.append(event)
        async def app(scope,incoming,outgoing):
            """Read both checked content and the subsequent native disconnect."""
            received.append(await incoming());received.append(await incoming())
        guard=BoundedBearerMiddleware(app,TOKEN)
        await guard({'type':'http','path':'/mcp','method':'POST','headers':[(b'authorization',('Bearer '+TOKEN).encode()),(b'content-length',b'2')]},receive,send)
        if oversized:assert sent[0]['status']==413 and not received
        else:assert received==[{'type':'http.request','body':b'{}','more_body':False},{'type':'http.disconnect'}]
    asyncio.run(scenario(True));asyncio.run(scenario(False))


def test_snapshot_copy_checks_inventory_hash_and_existing_state(tmp_path):
    """Copy a sealed inventory once, then reject overwrite and a changed source byte."""
    source=tmp_path/'source';target=tmp_path/'target';source.mkdir();target.mkdir();seal=tmp_path/'seal.json'
    for name in NAMES:(source/name).write_bytes(name.encode())
    payload={'files':{name:sha256((source/name).read_bytes()).hexdigest() for name in NAMES}}
    seal.write_text(json.dumps(payload));prepare(source,target,seal)
    assert {p.name:p.read_bytes() for p in target.iterdir()}=={p.name:p.read_bytes() for p in source.iterdir()}
    with pytest.raises(ValueError):prepare(source,target,seal)
    other=tmp_path/'other';other.mkdir();(source/'chunks.json').write_text('changed')
    with pytest.raises(ValueError):prepare(source,other,seal)


def test_knowledge_reader_checks_exact_chunk_provenance(tmp_path,monkeypatch):
    """Exercise the real reader against fixture SDK boundaries, including inconsistent native source relationships."""
    row={'chunk_id':'c'*64,'document_id':'fixture','revision':1,'source_sha256':'d'*64,'source_file':'fixture.md','section':'Section','text':'Reference sentence.'}
    (tmp_path/'chunks.json').write_text(json.dumps([row]));(tmp_path/'infra/rag').mkdir(parents=True);(tmp_path/'knowledge').mkdir()
    (tmp_path/'infra/rag/embedding.lock.json').write_text(json.dumps({'revision':'encoder-revision'}))
    (tmp_path/'knowledge/catalog.json').write_text(json.dumps({'documents':[{'document_id':'fixture','sha256':'d'*64}]}))
    monkeypatch.setattr('rag.embeddings.TextEncoder',lambda config:SimpleNamespace(encode=lambda texts:[[1.]]))
    monkeypatch.setattr('rag.store.create_store',lambda *args:(None,None,None))
    values={key:[value] for key,value in row.items()};values['distance']=[1.]
    monkeypatch.setattr('rag.retrieval.retrieve_consistent',lambda *args:(values,{}))
    reader=KnowledgeReader(tmp_path,tmp_path);request=SearchRequest(question='A valid question',top_k=1)
    assert reader.search(request)['matches'][0]['chunk_id']==row['chunk_id']
    values['source_sha256']=['e'*64]
    with pytest.raises(ToolFailure):reader.search(request)
