"""Record one actual authenticated coordinator conversation and independent per-Pod/model/trace readbacks without changing agent business code."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from urllib.request import build_opener,ProxyHandler
from urllib.error import HTTPError
import json,subprocess,time
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/llm-agent-observation-29a';chat=root/'outputs/agent-observer-chat-29a'
assert not out.exists() and not chat.exists()
rollout=json.loads((root/'outputs/llm-observer-rollout-29b/verification.json').read_bytes());assert rollout['passed']
feature=json.loads((root/'outputs/agent-feature-29m/verification.json').read_bytes());assert feature['passed'] and datetime.fromisoformat(feature['lease_expires_utc'])>datetime.now(timezone.utc)
assert json.loads((root/'outputs/agent-feature-29m/physical-ttl-before.json').read_bytes())['keys']==0
runner=Path('/tmp/iot-probe-agent-gateway-conversation-29b.py');assert sha256(runner.read_bytes()).hexdigest()=='f40c543d99c29dcd99e6c365b301c2f1bcd3b9e37ef15b4c4e238e3d5756d41b'
out.mkdir(exist_ok=False);k=['/usr/local/bin/k3s','kubectl'];opener=build_opener(ProxyHandler({}))
def save(name,value):
 """Keep original resource/readback facts in the fresh measurement directory."""
 (out/name).write_text(json.dumps(value,indent=2)+'\n')
def get(*query):
 """Read approved public resource metadata without retrieving Secrets."""
 return json.loads(subprocess.check_output(k+['get',*query,'-o','json'],stderr=subprocess.PIPE,timeout=30))
def fetch(name,url):
 """Retain exact HTTP response bytes, including an unsupported query response rather than dropping its error."""
 try:response=opener.open(url,timeout=15)
 except HTTPError as error:response=error
 with response:
  raw=response.read(8*1024**2+1);assert len(raw)<=8*1024**2
 (out/(name+'.bin')).write_bytes(raw);save(name+'-http.json',{'status':response.status,'response_bytes':len(raw)});return response.status,raw
def snapshot(label):
 """Read all four MCP Pods separately, the live observer ledger and each generated actor template."""
 save(label+'-utc.json',{'utc':datetime.now(timezone.utc).isoformat()})
 observer=get('pods','-n','iot-llm','-l','app.kubernetes.io/instance=iot-llm-observer');save(label+'-observer-pods.json',observer)
 assert len(observer['items'])==1 and observer['items'][0]['metadata']['uid']==rollout['observer_pod_uid']
 pod=observer['items'][0];code='from llm_observability.ledger import TelemetryLedger; import json; s=TelemetryLedger("/var/lib/iot-llm-observer/telemetry.sqlite"); print(json.dumps(s.rows())); s.close()'
 raw=subprocess.check_output(k+['exec','-n','iot-llm',pod['metadata']['name'],'-c','observer','--','python','-B','-c',code],stderr=subprocess.PIPE,timeout=30)
 (out/(label+'-ledger.json')).write_bytes(raw)
 svc=get('service','iot-llm-observer','-n','iot-llm');fetch(label+'-observer-metrics','http://'+svc['spec']['clusterIP']+':8081/metrics')
 mcps=get('pods','-n','iot-agents','-l','app.kubernetes.io/instance in (iot-retrieval-mcp,iot-drift-mcp)');save(label+'-mcp-pods.json',mcps)
 ready=[p for p in mcps['items'] if not p['metadata'].get('deletionTimestamp') and p['status']['phase']=='Running' and all(c['ready'] for c in p['status']['containerStatuses'])]
 assert len(ready)==4
 for pod in ready:fetch(label+'-mcp-'+pod['metadata']['name'],'http://'+pod['status']['podIP']+':8080/metrics')
 for kind,name,ns in [('sandboxagents','agents','iot-agents'),('actortemplates','templates','iot-agents'),('workerpools','workerpools','iot-agents')]:save(label+'-'+name+'.json',get(kind,'-n',ns))
 return json.loads(raw)
save('feature-lease.json',{key:feature[key] for key in ['run','prepared_wall_utc','lease_expires_utc','seed_uid','sdk_image_id','machines']})
save('rollout.json',rollout);before=snapshot('before')
arguments=['/usr/bin/python3','-B',str(runner),'--runtime-root',str(root),'--source',str(root/'data/ci/source/daee5d3ff335917ffb7f1705e17bf1e723aa20ad/tree'),
 '--deployment',str(root/'outputs/agent-gateway-29a'),'--credentials',str(root/'data/runtime/agent-gateway-29a-private/credentials.json'),'--output',str(chat)]
save('conversation-command.json',arguments)
with (out/'conversation.stdout').open('wb') as stream,(out/'conversation.stderr').open('wb') as errors:
 result=subprocess.run(arguments,stdout=stream,stderr=errors,timeout=360)
(out/'conversation.exit').write_text(str(result.returncode)+'\n')
time.sleep(5);after=snapshot('after')
logs=subprocess.check_output(k+['logs','deployment/iot-llm-observer','-n','iot-llm','-c','observer','--timestamps'],stderr=subprocess.PIPE,timeout=30)
(out/'observer-logs.txt').write_bytes(logs)
old={(r['kind'],r['event_id']) for r in before};fresh=[r for r in after if (r['kind'],r['event_id']) not in old];save('new-ledger-rows.json',fresh)
jaeger=get('service','iot-jaeger','-n','iot-observability');save('jaeger-service.json',jaeger)
fetch('jaeger-services','http://'+jaeger['spec']['clusterIP']+':16686/api/v3/services')
traceids=sorted({r['facts']['trace_id'] for r in fresh if r['kind']=='span'})
for identity in traceids:fetch('jaeger-trace-'+identity,'http://'+jaeger['spec']['clusterIP']+':16686/api/v3/traces/'+identity)
roots=[r for r in fresh if r['kind']=='span' and r['facts']['operation']=='agent']
report={'conversation_exit':result.returncode,'checked_utc':datetime.now(timezone.utc).isoformat(),'before_rows':len(before),'after_rows':len(after),
 'new_model_requests':sum(r['kind']=='request' for r in fresh),'new_spans':sum(r['kind']=='span' for r in fresh),
 'observed_agent_roots':[r['facts'] for r in roots],'trace_ids':traceids,
 'scope':'One actual HTTPS coordinator conversation and original independent telemetry readbacks. Reconciliation and UI/dashboard acceptance remain separate.'}
save('observation.json',report);print(json.dumps(report,indent=2));assert result.returncode==0
