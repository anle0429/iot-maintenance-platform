"""Launch a bounded private observer promotion after native planning tests, quality and real canary acceptance."""
from pathlib import Path
import json,subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');stage=root/'outputs/llm-observer-rollout-stage-29a/verification.json'
accepted=json.loads(stage.read_bytes());assert accepted['native_planning_tests_passed'] and accepted['runtime_matches_F']
source=Path(accepted['source']);out=root/'outputs/llm-observer-rollout-29a';assert not out.exists()
unit='iot-llm-observer-rollout-29a'
subprocess.run(['systemd-run','--unit='+unit,'--property=RuntimeMaxSec=1200','--property=MemoryMax=2G','--property=CPUQuota=200%',
 '/home/work_anle05_gmail_com/.venvs/iot-control/bin/python','-B',str(source/'scripts/promote-llm-observer.py'),
 '--runtime-root',str(root),'--output',str(out),'--canary',str(root/'outputs/llm-observer-canary-29c'),
 '--probe',str(root/'outputs/llm-observer-probe-29a')],check=True)
identity=subprocess.check_output(['systemctl','show',unit,'-p','InvocationID','-p','ActiveState','-p','Result'],text=True)
(root/'outputs/llm-observer-rollout-launch-29a.txt').write_text(identity);print(identity)
