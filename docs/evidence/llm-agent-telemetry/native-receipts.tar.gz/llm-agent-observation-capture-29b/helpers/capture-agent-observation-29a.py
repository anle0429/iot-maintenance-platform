"""Retain accepted active routing, original rollback, genuine Feast refresh and one complete native agent/telemetry cohort without rerunning it."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import base64,json,os,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/llm-agent-observation-capture-29a';out.mkdir(exist_ok=False)
private=[]
paths=[root/'data/runtime/secrets'/n for n in ['agent-platform.json','mcp-tools.json']]+[root/'data/runtime/agent-vault-29a-private'/n for n in ['gateway-credentials.json','gateway-approle.json','services-approle.json']]
paths.append(root/'data/runtime/agent-gateway-29a-private/credentials.json')
for p in paths:private.extend(v.encode() for v in json.loads(p.read_bytes()).values() if isinstance(v,str) and len(v)>=16)
private.append(json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes())['root_token'].encode())
private=list({v for value in private for v in [value,base64.b64encode(value)]})
def keep(name,body):
 """Refuse actual credentials and oversized payloads before copying original bytes into the native capsule."""
 assert len(body)<20_000_000 and not any(v in body for v in private),name
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
def copy(label,folder):
 """Copy only explicit retained non-private directories without following symlinks."""
 assert folder.is_dir(),folder
 for parent,dirs,files in os.walk(folder):
  dirs[:]=[v for v in dirs if v!='__pycache__']
  for n in sorted(files):
   p=Path(parent)/n;assert not p.is_symlink(),p
   keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())
for name in ['llm-observer-rollout-29a','llm-observer-rollout-29b','llm-observer-rollout-stage-29a','llm-observer-rollout-stage-29b',
 'llm-observer-rollout-inspect-29a','llm-agent-observation-29a','agent-observer-chat-29a','agent-feature-29m','llm-observer-idle-inspect-29a']:
 copy('native/'+name,root/'outputs'/name)
for prefix in ['3c8f3c35','1bc089e6']:copy('source/rollout-'+prefix,root/'data/llm-source'/('llm-observer-rollout-'+prefix))
copy('source/accepted-agent',root/'data/ci/source/daee5d3ff335917ffb7f1705e17bf1e723aa20ad')
for n in ['context.json','verification.json','_READY.json','registry/registry.db']:
 keep('feature-state/'+n,(root/'data/demo/demo-agent-29m/state'/n).read_bytes())
for name in ['iot-llm-observer-rollout-29a','iot-llm-observer-rollout-29b','iot-agent-observation-29a','iot-agent-feature-29m']:
 for label,cmd in [('unit',['systemctl','show',name]),('journal',['journalctl','-u',name,'--no-pager','-o','json'])]:
  p=subprocess.run(cmd,capture_output=True,timeout=30);assert p.returncode==0;keep('units/'+name+'/'+label+'.stdout',p.stdout)
for n in ['llm-observer-rollout-launch-29a.txt','llm-observer-rollout-launch-29b.txt','agent-feature-launch-29m.txt','agent-observation-launch-29a.txt']:
 keep('launch/'+n,(root/'outputs'/n).read_bytes())
for n in ['run-agent-observation-29a.py','iot-probe-agent-gateway-conversation-29b.py','iot-refresh-demo-feature-29k.py']:
 keep('helpers/'+n,(Path('/tmp')/n).read_bytes())
keep('capture-helper.py',Path(__file__).read_bytes())
inventory={'captured_utc':datetime.now(timezone.utc).isoformat(),'actual_native_credentials_scanned':True,'workloads_rerun_for_capture':False,
 'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(inventory,indent=2)+'\n').encode());archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as packet:packet.add(out,arcname=out.name)
archive.chmod(0o644)
report={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'payloads':len(inventory['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()}
(root/'outputs/llm-agent-observation-capture-receipt-29a.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
