"""Preserve the completed GPU stream pilot and sealed original source without re-running inference."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import base64,json,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/llm-observation-capture-29c';out.mkdir(exist_ok=False)
run=root/'outputs/llm-observation-pilot-29a';source=root/'data/llm-source/llm-observation-fedab2ce'
report=json.loads((run/'verification.json').read_bytes());assert report['passed'] and report['native_requests']==3
private=[]
for n in ['agent-platform.json','mcp-tools.json']:
 private.extend(v.encode() for v in json.loads((root/'data/runtime/secrets'/n).read_bytes()).values() if len(v)>=16)
for n in ['gateway-credentials.json','gateway-approle.json','services-approle.json']:
 value=json.loads((root/'data/runtime/agent-vault-29a-private'/n).read_bytes())
 private.extend(v.encode() for v in value.values() if isinstance(v,str) and len(v)>=16)
private.append(json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes())['root_token'].encode())
private += [base64.b64encode(v) for v in private]
def keep(name,body):
 """Refuse actual active secrets before retaining original native bytes."""
 assert not any(v in body for v in private),name
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
for label,folder in [('pilot',run),('source',source)]:
 for p in sorted(folder.rglob('*')):
  if p.is_file():
   assert not p.is_symlink() and p.stat().st_size<10485760
   keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())
unit='iot-llm-observation-pilot-29a'
for label,args in [('unit',['systemctl','show',unit]),('journal',['journalctl','-u',unit,'--no-pager','-o','json'])]:
 p=subprocess.run(args,capture_output=True,timeout=20);assert p.returncode==0;keep(label+'.stdout',p.stdout);keep(label+'.stderr',p.stderr)
 if label=='unit':
  fields=dict(l.split('=',1) for l in p.stdout.decode().splitlines() if '=' in l)
  assert fields.get('LoadState')=='not-found' or (fields.get('InvocationID')=='e7e87f00ff6b4fc5a8f9a54ac490f387' and fields.get('ExecMainStatus')=='0' and fields.get('Result')=='success' and fields.get('ActiveState')=='inactive')
 else:
  entries=[json.loads(line) for line in p.stdout.splitlines()]
  assert any(e.get('INVOCATION_ID')=='e7e87f00ff6b4fc5a8f9a54ac490f387' for e in entries)
  assert any('Deactivated successfully.' in e.get('MESSAGE','') for e in entries)
  assert not any('Failed with result' in e.get('MESSAGE','') for e in entries)
keep('capture-helper.py',Path(__file__).read_bytes())
inventory={'captured_utc':datetime.now(timezone.utc).isoformat(),'actual_native_credentials_scanned':True,'files':{}}
for p in sorted(out.rglob('*')):
 if p.is_file():inventory['files'][p.relative_to(out).as_posix()]={'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()}
keep('manifest.json',(json.dumps(inventory,indent=2)+'\n').encode());archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as packet:packet.add(out,arcname=out.name)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),
 'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest(),'payloads':len(inventory['files']),'reran_inference':False}))
