"""Start a bounded metadata-only view of the existing Vault UI without changing the Vault service or policies."""
from pathlib import Path
from hashlib import sha256
from urllib.request import build_opener,HTTPSHandler,ProxyHandler
import json,ssl,subprocess,socket,os
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/vault-ui-30b';out.mkdir(exist_ok=False)
seal=json.loads(Path('/tmp/vault-ui-manifest-30a.json').read_bytes());raw=Path('/tmp/view-vault-metadata-30a.py').read_bytes()
assert sha256(raw).hexdigest()==seal['files']['scripts/view-vault-metadata.py']
(out/'source.json').write_bytes(Path('/tmp/vault-ui-manifest-30a.json').read_bytes());(out/'viewer.py').write_bytes(raw)
ca=root/'outputs/vault-28/resume-active/ca.crt';(out/'ca.crt').write_bytes(ca.read_bytes())
context=ssl.create_default_context(cafile=str(ca));client=build_opener(ProxyHandler({}),HTTPSHandler(context=context))
with client.open('https://10.52.0.1:18200/v1/sys/health',timeout=20) as response:
 health=json.load(response)
assert health['initialized'] and not health['sealed'] and health['cluster_id']=='63e1d9cc-7eb1-c7a7-a48d-b11a3ac107f9'
(out/'health.json').write_text(json.dumps(health,indent=2)+'\n')
with socket.socket() as sock:sock.bind(('127.0.0.1',21950))
os.chown(out,65534,65534);out.chmod(0o755)
for p in out.iterdir():p.chmod(0o644)
cmd=['systemd-run','--unit=iot-vault-metadata-view-30a','--uid=nobody','--gid=nogroup','--property=NoNewPrivileges=yes','--property=ProtectSystem=strict','--property=ReadWritePaths='+str(out),'--property=ProtectHome=yes','--property=PrivateTmp=yes','--property=RuntimeMaxSec=3600','python3','-B',str(out/'viewer.py'),'--ca',str(out/'ca.crt'),'--audit',str(out/'transport.jsonl')]
r=subprocess.run(cmd,capture_output=True,timeout=30);(out/'launch.txt').write_bytes(r.stdout+r.stderr);assert r.returncode==0
(out/'operator.py').write_bytes(Path(__file__).read_bytes());(out/'unit.txt').write_bytes(subprocess.check_output(['systemctl','show','iot-vault-metadata-view-30a','-p','InvocationID','-p','ActiveState','-p','User','-p','Group','-p','RuntimeMaxUSec','-p','NoNewPrivileges','-p','ProtectSystem']))
print((out/'unit.txt').read_text())
