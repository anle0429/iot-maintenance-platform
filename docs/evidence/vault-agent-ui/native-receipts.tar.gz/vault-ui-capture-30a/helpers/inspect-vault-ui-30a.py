from pathlib import Path
import ssl,http.client,json
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');context=ssl.create_default_context(cafile=str(root/'outputs/vault-ui-30b/ca.crt'))
for encoding in ['identity','gzip']:
 c=http.client.HTTPSConnection('10.52.0.1',18200,context=context,timeout=20);c.request('GET','/ui/',headers={'Accept-Encoding':encoding});r=c.getresponse()
 info={'encoding':encoding,'status':r.status,'headers':dict(r.getheaders()),'length_before':r.length};p=r.read1(16384);info['first_read1_bytes']=len(p);info['length_after']=r.length;print(json.dumps(info));c.close()
