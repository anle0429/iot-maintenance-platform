"""Seal original paired sample exports, actual stream CI and the exact continued GPU evidence-reading cohort."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from urllib.parse import quote
import base64,json,os,re,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/vault-ui-capture-30a';os.umask(0o077);out.mkdir(exist_ok=False);private=[]

def credential(raw):
 if isinstance(raw,str):raw=raw.encode()
 if len(raw)>=12:
  private.append(raw)
  if raw.startswith(b'Bearer '):private.append(raw[7:])
def walk(value,key=''):
 if isinstance(value,dict):
  if value.get('name')=='Authorization' and isinstance(value.get('value'),str):credential(value['value'])
  if {'username','password'}<=set(value):credential(base64.b64encode((value['username']+':'+value['password']).encode()))
  for name,child in value.items():walk(child,name)
 elif isinstance(value,list):
  for child in value:walk(child,key)
 elif isinstance(value,str) and re.search('password|token|apikey|secretid|roleid|keysbase64|authorization',re.sub('[^a-z]','',key.lower())):credential(value)
paths=[root/'data/runtime/secrets'/n for n in ['agent-platform.json','mcp-tools.json']]
paths.extend(root/'data/runtime/agent-vault-29a-private'/n for n in ['gateway-credentials.json','gateway-approle.json','services-approle.json'])
paths.extend([root/'data/runtime/agent-gateway-29a-private/credentials.json',root/'data/runtime/gateway-28-private/credentials.json',root/'data/runtime/ci/jenkins-private/bootstrap.json'])
paths.extend(root/'data/runtime/vault-28-private'/n for n in ['ci-approle.json','gateway-approle.json','bootstrap.json'])
for path in paths:walk(json.loads(path.read_bytes()))
jenkins=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());credential(base64.b64encode(('learner:'+jenkins['admin_password']).encode()));jenkins=None
credential((root/'data/runtime/llm-monitoring-29a/auth/token').read_bytes().strip())
k=['/usr/local/bin/k3s','kubectl'];refs={('iot-llm','iot-llm-observer-client','API_KEY'),('iot-agents','iot-local-model-client','API_KEY')}
def get(*args):return json.loads(subprocess.check_output(k+['get',*args,'-o','json'],timeout=30,stderr=subprocess.PIPE))
for deployment in get('deployments','-n','iot-agents')['items']:
 for container in deployment['spec']['template']['spec']['containers']:
  for item in container.get('env',[]):
   ref=item.get('valueFrom',{}).get('secretKeyRef')
   if ref and re.search('password|token|key|auth',ref['key'],re.I):refs.add(('iot-agents',ref['name'],ref['key']))
for remote in get('remotemcpservers','-n','iot-agents')['items']:
 for header in remote['spec'].get('headersFrom',[]):
  ref=header.get('valueFrom',{})
  if ref.get('type')=='Secret':refs.add(('iot-agents',ref['name'],ref['key']))
for namespace,name,key in sorted(refs):
 secret=get('secret',name,'-n',namespace);credential(base64.b64decode(secret['data'][key]));secret=None
for value in json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes())['keys_base64']:credential(value)
private=list({v for raw in private for v in [raw,base64.b64encode(raw),base64.b64encode(b'Bearer '+raw),quote(raw.decode(),safe='').encode()]})
def keep(name,body):
 assert len(body)<10000000 and not any(v in body for v in private),name
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
def copy(label,folder):
 assert folder.is_dir(),folder
 for parent,dirs,files in os.walk(folder):
  dirs[:]=[v for v in dirs if v!='__pycache__']
  for name in sorted(files):
   p=Path(parent)/name;assert not p.is_symlink();keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())


from urllib.request import Request,ProxyHandler,HTTPSHandler,build_opener
from urllib.error import HTTPError
import ssl
current=root/'outputs/vault-ui-30h';seal=json.loads((current/'source.json').read_bytes());assert sha256((current/'viewer.py').read_bytes()).hexdigest()==seal['files']['scripts/view-vault-metadata.py']
keep('source/manifest.json',(current/'source.json').read_bytes())
keep('source/tree/scripts/view-vault-metadata.py',(current/'viewer.py').read_bytes())
test=Path('/tmp/test_vault_metadata_view-30e.py').read_bytes();assert sha256(test).hexdigest()==seal['files']['tests/test_vault_metadata_view.py'];keep('source/tree/tests/test_vault_metadata_view.py',test)
result=subprocess.run(['python3','-B','-m','unittest','discover','-s',str(out/'source/tree/tests'),'-p','test_vault_metadata_view.py'],cwd=out/'source/tree',capture_output=True,timeout=30)
keep('native-tests.stdout',result.stdout);keep('native-tests.stderr',result.stderr);assert result.returncode==0
root_token=json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes())['root_token']
client=build_opener(ProxyHandler({}));context=ssl.create_default_context(cafile=str(current/'ca.crt'));direct=build_opener(ProxyHandler({}),HTTPSHandler(context=context))
def vault(path):
 request=Request('https://10.52.0.1:18200/v1/'+path,headers={'X-Vault-Token':root_token})
 with direct.open(request,timeout=20) as response:return response.read()
unit_before=subprocess.check_output(['systemctl','show','iot-vault-28','-p','InvocationID','-p','MainPID','-p','ActiveState'])
keep('vault-service-before.txt',unit_before)
rows=[]
for name,path,method,body,code in [('gateway-metadata','/v1/iot/metadata/agents/gateway','GET',None,200),('services-metadata','/v1/iot/metadata/agents/services','GET',None,200),('agent-list','/v1/iot/metadata/agents/?list=true','GET',None,200),('gateway-values-denied','/v1/iot/data/agents/gateway','GET',None,403),('services-values-denied','/v1/iot/data/agents/services','GET',None,403),('encoded-values-denied','/v1/iot/data/agents%2Fgateway','GET',None,403),('invalid-capability-body-denied','/v1/sys/capabilities-self','POST',b'{}',403)]:
 request=Request('http://127.0.0.1:21950'+path,data=body,headers={'X-Vault-Token':root_token,'Content-Type':'application/json'},method=method)
 try:
  with client.open(request,timeout=20) as response:status=response.status;raw=response.read()
 except HTTPError as error:status=error.code;raw=error.read()
 assert status==code,(name,status);keep('readback/'+name+'.json',raw)
 value=json.loads(raw)
 if name.endswith('-metadata'):assert value['data']['current_version']==1 and value['data']['versions']['1']['destroyed']==False
 rows.append({'case':name,'path':path,'method':method,'status':status,'body_sha256':sha256(raw).hexdigest(),'time_scope':'Subsequent operator readback after native UI capture, not browser interception'})
keep('readbacks.json',(json.dumps(rows,indent=2)+'\n').encode())
for role in ['gateway','services']:
 for category,path in [('policy','sys/policies/acl/iot-agent-'+role),('role','auth/approle/role/iot-agent-'+role)]:keep('current/'+role+'-'+category+'.json',vault(path))
keep('current/health.json',vault('sys/health'))
keep('vault-service-after.txt',subprocess.check_output(['systemctl','show','iot-vault-28','-p','InvocationID','-p','MainPID','-p','ActiveState']))
assert (out/'vault-service-after.txt').read_bytes()==unit_before
for letter in 'abcdefgh':
 folder=root/('outputs/vault-ui-30'+letter)
 if folder.exists():copy('execution/'+folder.name,folder)
for letter in 'abcde':
 unit='iot-vault-metadata-view-30'+letter
 keep('units/'+unit+'.txt',subprocess.check_output(['journalctl','-u',unit,'--no-pager','-o','short-iso']))
keep('current-view-unit.txt',subprocess.check_output(['systemctl','show','iot-vault-metadata-view-30e','-p','InvocationID','-p','ActiveState','-p','User','-p','Group','-p','RuntimeMaxUSec','-p','NoNewPrivileges','-p','ProtectSystem']))
for name in ['start-vault-ui-30a.py','start-vault-ui-30b.py','start-vault-ui-30c.py','start-vault-ui-30d.py','start-vault-ui-30e.py','start-vault-ui-30f.py','start-vault-ui-30g.py','start-vault-ui-30h.py','inspect-vault-ui-30a.py']:
 keep('helpers/'+name,Path('/tmp/'+name).read_bytes())
keep('helpers/capture.py',Path(__file__).read_bytes())
keep('verification.json',(json.dumps({'passed':True,'native_unit_tests':5,'metadata_readbacks':2,'guarded_negative_cases':4,'vault_service_unchanged':True,'root_credential_used_only_in_memory':True,'secret_values_read':False,'vault_policies_or_roles_written':False,'scope':'Actual native Vault UI and later safe operator readbacks. Operator root login is separate from earlier narrowly scoped AppRole consumer tests. Metadata only; no secret values in capture.'},indent=2)+'\n').encode())
manifest={'captured_utc':datetime.now(timezone.utc).isoformat(),'current_native_credentials_scanned':True,'vault_root_and_unseal_scanned':True,'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode());archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'x:gz') as t:t.add(out,arcname=out.name)
archive.chmod(0o644);print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'payloads':len(manifest['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()}))
