"""Verify serving contracts using native Spark goldens, faulted model bundles and boundary partitions."""

from copy import deepcopy
from hashlib import sha256
import json,math,shutil
from pathlib import Path

from fastapi.testclient import TestClient
from hypothesis import given,settings,strategies as st
import pytest

from services.predictor.app import create_app
from services.predictor.contracts import FeatureVector
from services.predictor.runtime import PumpPredictor

ROOT=Path(__file__).resolve().parents[2]
BUNDLE=ROOT/'models/pump-failure-v1'
ROUTE='/v1/models/iot-pump-failure-v1:predict'
BASE={'temperature_mean_10m':62.0,'vibration_max_10m':5.0,'current_mean_10m':16.0,
      'current_std_10m':1.6,'rpm_mean_10m':2800.0,'reading_count_10m':9,
      'machine_age_days':900.0,'prior_failures_24h':1}


@pytest.fixture
def client():
    """Exercise real routing/lifespan while keeping every metric registry isolated."""
    with TestClient(create_app(BUNDLE)) as c:yield c


@pytest.fixture
def bundle(tmp_path):
    """Copy the small immutable model to inject corruption without touching source artifacts."""
    target=tmp_path/'model';shutil.copytree(BUNDLE,target)
    return target


def replace_model(bundle,change):
    """Seal deliberately altered test model metadata to reach validation beyond checksum checks."""
    file=bundle/'portable.json';v=json.loads(file.read_text());change(v);file.write_text(json.dumps(v))
    lineage=bundle/'lineage.json';m=json.loads(lineage.read_text());m['portable_sha256']=sha256(file.read_bytes()).hexdigest();lineage.write_text(json.dumps(m))


def test_health_metadata_and_shutdown(client):
    """Liveness/readiness/provenance agree with the registry-bound runtime."""
    assert client.get('/health/live').json()=={'live':True}
    assert client.get('/health/ready').json()=={'ready':True,'version':'1'}
    value=client.get('/v1/models/iot-pump-failure-v1').json()
    assert value['version']=='1' and value['run_id']=='c629f87591294157a6b30040c8c12715'
    assert value['threshold']==0.7 and value['features']==list(BASE)
    assert value['score_kind']=='uncalibrated_class_weighted_logistic' and value['production'] is False


def test_not_ready_and_wrong_model(client):
    """An alive but uninitialized process fails closed, and a different model is404."""
    assert client.get('/v1/models/unknown').status_code==404
    assert client.post('/v1/models/unknown:predict',json={'instances':[BASE]}).status_code==404
    client.app.state.predictor=None
    assert client.get('/health/live').status_code==200
    assert client.get('/health/ready').status_code==503
    assert client.post(ROUTE,json={'instances':[BASE]}).status_code==503


def test_lifespan_releases_model():
    """Shutdown removes readiness instead of retaining a stale runtime reference."""
    app=create_app(BUNDLE)
    with TestClient(app):assert app.state.predictor is not None
    assert app.state.predictor is None


def test_environment_bundle(monkeypatch,bundle):
    """Deployment configuration really selects the supplied bundle instead of silently using a default."""
    replace_model(bundle,lambda m:m.update(coefficients=[0.0]*8,intercept=0.0))
    monkeypatch.setenv('IOT_MODEL_BUNDLE',str(bundle))
    with TestClient(create_app()) as c:
        assert c.get('/health/ready').status_code==200
        assert c.post(ROUTE,json={'instances':[BASE]}).json()['predictions']==[
            {'risk_score':0.5,'predicted_failure':0}]


def test_default_bundle_from_repository(monkeypatch):
    """The documented default invocation loads its included model without any environment variable."""
    monkeypatch.delenv('IOT_MODEL_BUNDLE',raising=False);monkeypatch.chdir(ROOT)
    with TestClient(create_app()) as c:
        assert c.get('/health/ready').json()=={'ready':True,'version':'1'}
        assert c.get('/v1/models/iot-pump-failure-v1').json()['run_id']=='c629f87591294157a6b30040c8c12715'


def test_complete_prediction_provenance(client):
    """Clients must receive every lineage field needed to audit the scored model/data/protocol."""
    lineage=json.loads((BUNDLE/'lineage.json').read_text())
    expected={'name':'iot-pump-failure-v1','version':'1','run_id':lineage['run_id'],
        'protocol_sha256':lineage['protocol_sha256'],'portable_sha256':lineage['portable_sha256'],
        'training_code_commit':lineage['training_code_commit'],'data_version':lineage['data_version'],
        'features':list(BASE),'threshold':0.7,'score_kind':'uncalibrated_class_weighted_logistic',
        'data_scope':'synthetic-medium-60d','production':False}
    assert client.get('/v1/models/iot-pump-failure-v1').json()==expected
    assert client.post(ROUTE,json={'instances':[BASE]}).json()['model']==expected


@pytest.mark.parametrize('key,value', [('model_name','a-different-pump'),('protocol_sha256','0'*64)])
def test_same_model_bytes_wrong_lineage(bundle,key,value):
    """Matching coefficient bytes cannot authorize a mismatched model identity or protocol."""
    file=bundle/'lineage.json';lineage=json.loads(file.read_text());lineage[key]=value;file.write_text(json.dumps(lineage))
    with pytest.raises(ValueError):PumpPredictor(bundle)


def test_native_spark_golden_predictions(client):
    """Stored native Spark outputs, not this implementation, establish expected serving values."""
    source=json.loads((ROOT/'tests/fixtures/predictor-native-spark.json').read_text())
    assert source['passed'] and source['registry_portable_bytes_equal'] and len(source['samples'])==32
    response=client.post(ROUTE,json={'instances':[r['features'] for r in source['samples']]})
    assert response.status_code==200
    for actual,expected in zip(response.json()['predictions'],source['samples'],strict=True):
        assert abs(actual['risk_score']-expected['expected_risk_score'])<=1e-12
        assert actual['predicted_failure']==expected['expected_predicted_failure']
    assert response.json()['model']['portable_sha256']==source['portable_sha256']


@pytest.mark.parametrize('count,status',[(0,422),(1,200),(128,200),(129,422)])
def test_batch_boundaries(client,count,status):
    """Equivalent valid/invalid batch partitions and exact min/max neighbours."""
    r=client.post(ROUTE,json={'instances':[BASE]*count});assert r.status_code==status
    if status==200:assert len(r.json()['predictions'])==count


@pytest.mark.parametrize('field,value',[
    ('temperature_mean_10m',-273.151),('temperature_mean_10m',1_000_001.0),
    ('vibration_max_10m',-0.001),('current_mean_10m',-1.0),('current_std_10m',-0.001),
    ('rpm_mean_10m',-1.0),('rpm_mean_10m',1_000_000_001.0),('reading_count_10m',0),
    ('reading_count_10m',1_000_001),('reading_count_10m',1.1),('prior_failures_24h',-1),
    ('prior_failures_24h',1_000_001),('machine_age_days',-0.001),('machine_age_days',1_000_001.0),
    ('current_mean_10m','16'),('rpm_mean_10m',True),('reading_count_10m',True),
    ('prior_failures_24h',False),('vibration_max_10m',None)])
def test_invalid_feature_partitions(client,field,value):
    """Reject invalid domain/type partitions instead of coercing or imputing them."""
    features={**BASE,field:value};r=client.post(ROUTE,json={'instances':[features]})
    assert r.status_code==422 and 'input' not in r.json()['detail'][0]


@pytest.mark.parametrize('field,value',[
    ('temperature_mean_10m',-273.15),('temperature_mean_10m',1e6),('vibration_max_10m',0.0),
    ('current_mean_10m',0.0),('current_std_10m',0.0),('rpm_mean_10m',0.0),('rpm_mean_10m',1e9),
    ('reading_count_10m',1),('reading_count_10m',1_000_000),('machine_age_days',0.0),
    ('machine_age_days',1e6),('prior_failures_24h',0),('prior_failures_24h',1_000_000)])
def test_valid_feature_boundaries(client,field,value):
    """Accept declared closed bounds and return finite saturated or intermediate scores."""
    r=client.post(ROUTE,json={'instances':[{**BASE,field:value}]});assert r.status_code==200
    score=r.json()['predictions'][0]['risk_score'];assert math.isfinite(score) and 0<=score<=1


@pytest.mark.parametrize('payload',[{}, {'instances':[]}, {'instances':[BASE],'failure_in_next_1h':1},
    {'instances':[{**BASE,'failure_in_next_1h':1}]},{'instances':[{**BASE,'temperature_mean_10m':None}]},
    {'instances':[{k:v for k,v in BASE.items() if k!='rpm_mean_10m'}]}, {'instances':[list(BASE.values())]}])
def test_missing_extra_and_label_inputs(client,payload):
    """Missing, extra, array and target-bearing inputs must not produce a prediction."""
    assert client.post(ROUTE,json=payload).status_code==422


@pytest.mark.parametrize('token',['NaN','Infinity','-Infinity'])
def test_nonfinite_json_is_rejected_as_json(client,token):
    """Even permissively decoded JSON nonfinite tokens return422 rather than a serialization500."""
    data=json.dumps({'instances':[BASE]}).replace('62.0',token)
    r=client.post(ROUTE,content=data,headers={'content-type':'application/json'})
    assert r.status_code==422 and r.json()['detail'][0]['type']=='finite_number'


def test_malformed_json_and_telemetry(client):
    """Invalid payloads remain visible in request/error metrics with no entity/path cardinality."""
    assert client.post(ROUTE,content='{',headers={'content-type':'application/json'}).status_code==422
    assert client.post(ROUTE,json={'instances':[BASE]}).status_code==200
    text=client.get('/metrics').text
    assert 'iot_predictor_requests_total{outcome="success"} 1.0' in text
    assert 'iot_predictor_requests_total{outcome="error"} 1.0' in text
    assert 'iot_predictor_request_seconds_count 2.0' in text


@pytest.mark.parametrize('change,message',[
    (lambda m:m.update(kind='unsupported'),'format'),
    (lambda m:m.update(protocol_sha256='0'*64),'protocol'),
    (lambda m:m.update(features=list(reversed(m['features']))),'schema'),
    (lambda m:m.update(mean=m['mean'][:7]),'scaler'),
    (lambda m:m['std'].__setitem__(0,-1),'numeric'),
    (lambda m:m['coefficients'].__setitem__(0,float('nan')),'scaler'),
    (lambda m:m['coefficients'].__setitem__(0,True),'scaler'),
    (lambda m:m['mean'].__setitem__(0,'62.0'),'scaler'),
    (lambda m:m.update(threshold=0),'numeric'),
    (lambda m:m.update(threshold=1),'numeric'),
    (lambda m:m.update(intercept=float('inf')),'numeric')])
def test_invalid_model_startup(bundle,change,message):
    """A hash-valid but semantically invalid model cannot become ready."""
    replace_model(bundle,change)
    with pytest.raises(ValueError,match=message):
        with TestClient(create_app(bundle)):pass


def test_checksum_and_lineage_rejected(bundle):
    """Corruption and unintended version routing are rejected before serving."""
    file=bundle/'portable.json';original=file.read_bytes();file.write_bytes(original+b' ')
    with pytest.raises(ValueError,match='artifact'):PumpPredictor(bundle)
    file.write_bytes(original)
    path=bundle/'lineage.json';lineage=json.loads(path.read_text());lineage['version']='2';path.write_text(json.dumps(lineage))
    with pytest.raises(ValueError,match='version1'):PumpPredictor(bundle)


def test_zero_std_matches_spark_convention(bundle):
    """A constant feature standardized by Spark contributes zero rather than causing division by zero."""
    replace_model(bundle,lambda m:m['std'].__setitem__(0,0))
    predictor=PumpPredictor(bundle)
    values=predictor.predict([FeatureVector(**BASE),FeatureVector(**{**BASE,'temperature_mean_10m':100.0})])
    assert values[0]==values[1]


def test_decision_includes_exact_threshold(bundle):
    """The >= boundary is checked with a known exactly representable probability0.5."""
    replace_model(bundle,lambda m:m.update(coefficients=[0.0]*8,intercept=0.0,threshold=0.5))
    assert PumpPredictor(bundle).predict([FeatureVector(**BASE)])==[{'risk_score':0.5,'predicted_failure':1}]


@settings(max_examples=100,deadline=None)
@given(temperature=st.floats(-100,200,allow_nan=False,allow_infinity=False),
       vibration=st.floats(0,100,allow_nan=False,allow_infinity=False),
       count=st.integers(1,1000),failures=st.integers(0,1000))
def test_property_prediction_replay_and_key_order(temperature,vibration,count,failures):
    """Repeated requests and object key ordering preserve predictions across generated valid partitions."""
    features={**BASE,'temperature_mean_10m':temperature,'vibration_max_10m':vibration,
              'reading_count_10m':count,'prior_failures_24h':failures}
    with TestClient(create_app(BUNDLE)) as c:
        first=c.post(ROUTE,json={'instances':[features]}).json()
        replay=c.post(ROUTE,json={'instances':[dict(reversed(list(features.items())))]}).json()
        assert first==replay
        prediction=first['predictions'][0]
        assert math.isfinite(prediction['risk_score']) and 0<=prediction['risk_score']<=1
        assert prediction['predicted_failure']==int(prediction['risk_score']>=0.7)
