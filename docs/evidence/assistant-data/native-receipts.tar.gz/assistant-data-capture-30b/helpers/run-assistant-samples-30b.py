"""Stage canonical small-study source, check actual budgets, and run the retained bounded Spark image once."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import argparse,json,os,shutil,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform')
p=argparse.ArgumentParser();p.add_argument('packet');p.add_argument('sha256');p.add_argument('commit');a=p.parse_args()
packet=Path(a.packet);assert sha256(packet.read_bytes()).hexdigest()==a.sha256
session=json.loads((root/'data/runtime/ci/session.json').read_bytes());remaining=(datetime.fromisoformat(session['auto_stop_utc'])-datetime.now(timezone.utc)).total_seconds()
ram=int(next(v.split()[1] for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')))*1024
assert remaining>1800 and ram>8*1024**3 and shutil.disk_usage(root).free>5*1024**3
stage=root/'data/llm-source'/('assistant-samples-'+a.commit[:8]+'-b');stage.mkdir()
with tarfile.open(packet) as t:
 for m in t:assert m.isfile() and '..' not in Path(m.name).parts and not Path(m.name).is_absolute()
 t.extractall(stage,filter='data')
seal=json.loads((stage/'manifest.json').read_bytes());assert seal['commit']==a.commit and seal['format']=='iot-assistant-sample-study-v1'
for n,h in seal['files'].items():assert sha256((stage/'tree'/n).read_bytes()).hexdigest()==h
out=root/'outputs/assistant-samples-30b';out.mkdir();state=root/'data/assistant-validation/samples-30b';state.mkdir(parents=True);state.chmod(0o1777)
settings=json.loads((stage/'tree/infra/llm/data-validation.json').read_bytes());settings['source_commit']=a.commit
(state/'settings.json').write_text(json.dumps(settings,indent=2)+'\n')
(out/'admission.json').write_text(json.dumps({'passed':True,'remaining_session_seconds':remaining,'available_memory_bytes':ram,'data_disk_free_bytes':shutil.disk_usage(root).free,'source_commit':a.commit,'source_packet_sha256':a.sha256,'source_files':len(seal['files'])},indent=2)+'\n')
image=json.loads(subprocess.check_output(['docker','image','inspect','iot-coursework-spark:3.5.9']))[0]
assert image['Id']=='sha256:0346da0caecfa6d615f2a50a52129c3b6367387077d5be2acec3bbf13973f417'
command=['docker','run','--name','iot-assistant-samples-30b','--init','--read-only','--network','none','--memory','4g','--memory-swap','4g','--cpus','2','--pids-limit','512','--cap-drop','ALL','--security-opt','no-new-privileges','--tmpfs','/tmp:rw,nosuid,exec,size=1g',
 '--env','SPARK_LOCAL_IP=127.0.0.1','--env','PYTHONDONTWRITEBYTECODE=1','--mount','type=bind,src='+str(stage/'tree')+',dst=/workspace,readonly','--mount','type=bind,src='+str(state)+',dst=/result',
 '--entrypoint','/opt/spark/bin/spark-submit',image['Id'],'--master','local[2]','--driver-memory','1g','--conf','spark.sql.shuffle.partitions=4','--conf','spark.sql.session.timeZone=UTC','/workspace/scripts/audit-assistant-samples.py','--output','/result/run','--settings','/result/settings.json']
with (out/'console.txt').open('x') as f:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
actual=json.loads(subprocess.check_output(['docker','inspect','iot-assistant-samples-30b']))[0]
(out/'container.json').write_text(json.dumps({'id':actual['Id'],'image':actual['Image'],'state':actual['State'],'memory_bytes':actual['HostConfig']['Memory'],'nano_cpus':actual['HostConfig']['NanoCpus'],'mounts':actual['Mounts'],'network_mode':actual['HostConfig']['NetworkMode'],'user':actual['Config']['User']},indent=2)+'\n')
assert result.returncode==0 and not actual['State']['OOMKilled']
proof=json.loads((state/'run/verification.json').read_bytes());assert proof['passed']
(out/'verification.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
