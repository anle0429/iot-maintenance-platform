"""Stage and run one exact source-bound three-question cohort on the already recovered private GPU route."""
from pathlib import Path
from hashlib import sha256
import argparse,json,subprocess,tarfile
p=argparse.ArgumentParser();p.add_argument('packet');p.add_argument('sha256');p.add_argument('commit');a=p.parse_args()
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');packet=Path(a.packet)
assert sha256(packet.read_bytes()).hexdigest()==a.sha256
stage=root/'data/llm-source'/('assistant-data-eval-'+a.commit[:8]+'-b');stage.mkdir()
with tarfile.open(packet) as t:
 for m in t:assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
 t.extractall(stage,filter='data')
seal=json.loads((stage/'manifest.json').read_bytes());assert seal['commit']==a.commit and seal['format']=='iot-assistant-data-evaluation-v1' and len(seal['files'])==11
for n,h in seal['files'].items():assert sha256((stage/'tree'/n).read_bytes()).hexdigest()==h
from datetime import datetime,timezone
from urllib.request import build_opener,ProxyHandler
import time
k=['/usr/local/bin/k3s','kubectl'];client=build_opener(ProxyHandler({}));deadline=time.monotonic()+480;stable=0
while stable<2:
 pods=json.loads(subprocess.check_output(k+['get','pods','-n','iot-llm','-l','app.kubernetes.io/instance=iot-llm-observer','-o','json']))['items']
 okay=len(pods)==1
 if okay:
  statuses=pods[0]['status'].get('containerStatuses',[])
  okay=len(statuses)==2 and all(v['ready'] and 'running' in v['state'] and (datetime.now(timezone.utc)-datetime.fromisoformat(v['state']['running']['startedAt'].replace('Z','+00:00'))).total_seconds()>=90 for v in statuses)
 service=json.loads(subprocess.check_output(k+['get','service','iot-llm-observer','-n','iot-llm','-o','json']))
 try:
  with client.open('http://'+service['spec']['clusterIP']+':8081/health/ready',timeout=8) as r:okay=okay and r.status==200
 except OSError:okay=False
 stable=stable+1 if okay else 0
 assert time.monotonic()<deadline,'Observe the same recovery, do not silently launch a generation through an unstable route'
 if stable<2:time.sleep(5)
subprocess.run(['/usr/bin/python3','-B','-m','unittest','tests.test_training_samples','tests.test_llm_data_validation','-q'],cwd=stage/'tree',check=True)
subprocess.run(['/usr/bin/python3','-B',str(stage/'tree/scripts/run-assistant-data-validation.py'),'--runtime-root',str(root),'--output',str(root/'outputs/assistant-data-eval-30b')],check=True)
