"""Record the actual approved GPU restart and explicitly load the retained two aliases without changing deployments or prompts."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
from urllib.request import Request,ProxyHandler,build_opener
import json,subprocess,time
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');raw=Path('/tmp/gpu-data-descriptor-30a.json').read_bytes();descriptor=json.loads(raw)
assert descriptor['name']=='iot-cw-gpu' and descriptor['status']=='RUNNING'
assert descriptor['scheduling']['maxRunDuration']['seconds']=='28800' and descriptor['scheduling']['instanceTerminationAction']=='STOP'
assert descriptor['networkInterfaces']==[{'networkIP':'10.42.0.7'}]
new={'last_start_utc':descriptor['lastStartTimestamp'],'max_duration_seconds':28800,'termination_action':'STOP','status':'RUNNING','private_ip':'10.42.0.7'}
out=root/'outputs/gpu-data-session-30a';out.mkdir();(out/'actual-descriptor.json').write_bytes(raw)
path=root/'data/runtime/ci/gpu-session.json';old=path.read_bytes();previous=json.loads(old)
assert datetime.fromisoformat(new['last_start_utc'])>datetime.fromisoformat(previous['last_start_utc'])
(out/'previous-session.json').write_bytes(old);pending=path.with_suffix('.data-pending');pending.write_text(json.dumps(new,indent=2)+'\n');pending.chmod(0o644);pending.replace(path)
k=['/usr/local/bin/k3s','kubectl'];client=build_opener(ProxyHandler({}));deadline=time.monotonic()+420
def get(*args):return json.loads(subprocess.check_output(k+['get',*args,'-o','json'],timeout=25,stderr=subprocess.PIPE))
while True:
 node=get('node','iot-cw-gpu');ready=any(c['type']=='Ready' and c['status']=='True' for c in node['status']['conditions'])
 service=get('service','iot-model-gpu','-n','iot-llm');base='http://'+service['spec']['clusterIP']+':8080'
 try:
  with client.open(base+'/models',timeout=8) as r:models=json.load(r)
  if ready:break
 except OSError:pass
 assert time.monotonic()<deadline,'Observe the same actual GPU recovery; do not recreate the VM or deployment'
 time.sleep(5)
(out/'model-state-before.json').write_text(json.dumps(models,indent=2)+'\n')
for alias in ['iot-qwen2.5-7b','iot-qwen2.5-1.5b']:
 status=next(v['status']['value'] for v in models['data'] if v['id']==alias)
 if status=='unloaded':
  with client.open(Request(base+'/models/load',data=json.dumps({'model':alias}).encode(),headers={'Content-Type':'application/json'}),timeout=90) as r:
   (out/('load-'+alias+'.json')).write_bytes(r.read())
 else:assert status in ['loading','loaded']
while True:
 with client.open(base+'/models',timeout=15) as r:models=json.load(r)
 states={v['id']:v['status']['value'] for v in models['data']}
 if set(states)=={'iot-qwen2.5-7b','iot-qwen2.5-1.5b'} and all(v=='loaded' for v in states.values()):break
 assert time.monotonic()<deadline
 time.sleep(3)
(out/'model-state-after.json').write_text(json.dumps(models,indent=2)+'\n')
pods=get('pods','-n','iot-llm','-l','app.kubernetes.io/instance=iot-model-gpu');(out/'pods.json').write_text(json.dumps(pods,indent=2)+'\n')
proof={'passed':True,'actual_start_utc':new['last_start_utc'],'auto_stop_utc':(datetime.fromisoformat(new['last_start_utc'])+timedelta(hours=8)).isoformat(),'models':states,'same_vm_and_resources':True,'deployments_or_prompts_changed':False}
(out/'verification.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
