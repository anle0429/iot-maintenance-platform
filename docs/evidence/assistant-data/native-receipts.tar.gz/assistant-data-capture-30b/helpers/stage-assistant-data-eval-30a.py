"""Stage and run one exact source-bound three-question cohort on the already recovered private GPU route."""
from pathlib import Path
from hashlib import sha256
import argparse,json,subprocess,tarfile
p=argparse.ArgumentParser();p.add_argument('packet');p.add_argument('sha256');p.add_argument('commit');a=p.parse_args()
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');packet=Path(a.packet)
assert sha256(packet.read_bytes()).hexdigest()==a.sha256
stage=root/'data/llm-source'/('assistant-data-eval-'+a.commit[:8]);stage.mkdir()
with tarfile.open(packet) as t:
 for m in t:assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
 t.extractall(stage,filter='data')
seal=json.loads((stage/'manifest.json').read_bytes());assert seal['commit']==a.commit and seal['format']=='iot-assistant-data-evaluation-v1' and len(seal['files'])==11
for n,h in seal['files'].items():assert sha256((stage/'tree'/n).read_bytes()).hexdigest()==h
subprocess.run(['/usr/bin/python3','-B','-m','unittest','tests.test_training_samples','tests.test_llm_data_validation','-q'],cwd=stage/'tree',check=True)
subprocess.run(['/usr/bin/python3','-B',str(stage/'tree/scripts/run-assistant-data-validation.py'),'--runtime-root',str(root),'--output',str(root/'outputs/assistant-data-eval-30a')],check=True)
