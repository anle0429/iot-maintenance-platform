"""Launch and observe the retained owned stream jobs without editing their configuration or reusing previous output states."""
from pathlib import Path
from hashlib import sha256
from urllib.request import ProxyHandler,Request,HTTPCookieProcessor,build_opener
from urllib.parse import urlencode
from http.cookiejar import CookieJar
from datetime import datetime,timezone
import argparse,base64,json,xml.etree.ElementTree as ET
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');commit='49115d5a7dcb8c331e8169e8a37df462743d921f'
p=argparse.ArgumentParser();p.add_argument('mode',choices=['launch','observe']);p.add_argument('destination',choices=['offline','online']);a=p.parse_args()
number=4 if a.destination=='offline' else 3;job='iot-stream-'+a.destination
out=root/'outputs/llm-stream-ci-30a';out.mkdir(exist_ok=True);source=root/'data/ci/source'/commit;seal=json.loads((source/'manifest.json').read_bytes())
assert seal['commit']==commit and len(seal['files'])==124
for n,h in seal['files'].items():assert sha256((source/'tree'/n).read_bytes()).hexdigest()==h
secret=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());authorization='Basic '+base64.b64encode(('learner:'+secret['admin_password']).encode()).decode()
client=build_opener(ProxyHandler({}),HTTPCookieProcessor(CookieJar()))
def request(path,data=None,headers=None):return client.open(Request('http://127.0.0.1:18787'+path,data=data,headers={'Authorization':authorization,**(headers or {})}),timeout=35)
def read(path):
 with request(path) as r:return r.read()
base='/job/'+job
if a.mode=='launch':
 state=json.loads(read(base+'/api/json?tree=inQueue,nextBuildNumber,lastBuild[building,number,result]'))
 assert not state['inQueue'] and not state['lastBuild']['building'] and state['nextBuildNumber']==number
 raw=read(base+'/config.xml');assert ET.fromstring(raw).find('definition/script').text==(source/'tree/infra/ci/StreamPush.Jenkinsfile').read_text()
 if a.destination=='online':
  prior=json.loads(read('/job/iot-stream-offline/4/api/json'));assert not prior['building'] and prior['result']=='SUCCESS'
  assert json.loads((root/'data/ci/releases/stream-offline-jenkins-4/outputs/verification.json').read_bytes())['passed']
 assert not (root/'data/ci/releases'/('stream-'+a.destination+'-jenkins-'+str(number))).exists()
 crumb=json.loads(read('/crumbIssuer/api/json'));parameters={'SOURCE_COMMIT':commit,'OFFLINE_RELEASE':'stream-offline-jenkins-4' if a.destination=='online' else ''}
 with request(base+'/buildWithParameters',urlencode(parameters).encode(),{crumb['crumbRequestField']:crumb['crumb'],'Content-Type':'application/x-www-form-urlencoded'}) as r:receipt={'status':r.status,'queue':r.headers['Location']}
 (out/(a.destination+'-job-before.xml')).write_bytes(raw)
 proof={'job':job,'build':number,'parameters':parameters,'source_files':len(seal['files']),'submitted_utc':datetime.now(timezone.utc).isoformat(),**receipt}
 with (out/(a.destination+'-launch.json')).open('x') as f:json.dump(proof,f,indent=2)
 print(json.dumps(proof))
else:
 raw=read(base+'/'+str(number)+'/api/json');value=json.loads(raw);report={k:value.get(k) for k in ['number','building','result','duration']}
 (out/(a.destination+'-build.json')).write_bytes(raw)
 for name,path in [('stages.json','/wfapi/describe'),('console.txt','/consoleText')]:
  body=read(base+'/'+str(number)+path);(out/(a.destination+'-'+name)).write_bytes(body)
  if name=='stages.json':report['stages']=[{'name':s['name'],'status':s['status']} for s in json.loads(body)['stages']]
  elif not value['building']:report['console_tail']='\n'.join(body.decode().splitlines()[-14:])
 actual=read(base+'/config.xml');(out/(a.destination+'-job-after.xml')).write_bytes(actual)
 assert actual==(out/(a.destination+'-job-before.xml')).read_bytes()
 print(json.dumps(report))
