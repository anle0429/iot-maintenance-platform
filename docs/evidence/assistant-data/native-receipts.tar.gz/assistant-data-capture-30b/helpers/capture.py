"""Seal original paired sample exports, actual stream CI and the exact continued GPU evidence-reading cohort."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from urllib.parse import quote
import base64,json,os,re,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/assistant-data-capture-30b';os.umask(0o077);out.mkdir(exist_ok=False);private=[]

def credential(raw):
 if isinstance(raw,str):raw=raw.encode()
 if len(raw)>=12:
  private.append(raw)
  if raw.startswith(b'Bearer '):private.append(raw[7:])
def walk(value,key=''):
 if isinstance(value,dict):
  if value.get('name')=='Authorization' and isinstance(value.get('value'),str):credential(value['value'])
  if {'username','password'}<=set(value):credential(base64.b64encode((value['username']+':'+value['password']).encode()))
  for name,child in value.items():walk(child,name)
 elif isinstance(value,list):
  for child in value:walk(child,key)
 elif isinstance(value,str) and re.search('password|token|apikey|secretid|roleid|keysbase64|authorization',re.sub('[^a-z]','',key.lower())):credential(value)
paths=[root/'data/runtime/secrets'/n for n in ['agent-platform.json','mcp-tools.json']]
paths.extend(root/'data/runtime/agent-vault-29a-private'/n for n in ['gateway-credentials.json','gateway-approle.json','services-approle.json'])
paths.extend([root/'data/runtime/agent-gateway-29a-private/credentials.json',root/'data/runtime/gateway-28-private/credentials.json',root/'data/runtime/ci/jenkins-private/bootstrap.json'])
paths.extend(root/'data/runtime/vault-28-private'/n for n in ['ci-approle.json','gateway-approle.json','bootstrap.json'])
for path in paths:walk(json.loads(path.read_bytes()))
jenkins=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());credential(base64.b64encode(('learner:'+jenkins['admin_password']).encode()));jenkins=None
credential((root/'data/runtime/llm-monitoring-29a/auth/token').read_bytes().strip())
k=['/usr/local/bin/k3s','kubectl'];refs={('iot-llm','iot-llm-observer-client','API_KEY'),('iot-agents','iot-local-model-client','API_KEY')}
def get(*args):return json.loads(subprocess.check_output(k+['get',*args,'-o','json'],timeout=30,stderr=subprocess.PIPE))
for deployment in get('deployments','-n','iot-agents')['items']:
 for container in deployment['spec']['template']['spec']['containers']:
  for item in container.get('env',[]):
   ref=item.get('valueFrom',{}).get('secretKeyRef')
   if ref and re.search('password|token|key|auth',ref['key'],re.I):refs.add(('iot-agents',ref['name'],ref['key']))
for remote in get('remotemcpservers','-n','iot-agents')['items']:
 for header in remote['spec'].get('headersFrom',[]):
  ref=header.get('valueFrom',{})
  if ref.get('type')=='Secret':refs.add(('iot-agents',ref['name'],ref['key']))
for namespace,name,key in sorted(refs):
 secret=get('secret',name,'-n',namespace);credential(base64.b64decode(secret['data'][key]));secret=None
for value in json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes())['keys_base64']:credential(value)
private=list({v for raw in private for v in [raw,base64.b64encode(raw),base64.b64encode(b'Bearer '+raw),quote(raw.decode(),safe='').encode()]})
def keep(name,body):
 assert len(body)<10000000 and not any(v in body for v in private),name
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
def copy(label,folder):
 assert folder.is_dir(),folder
 for parent,dirs,files in os.walk(folder):
  dirs[:]=[v for v in dirs if v!='__pycache__']
  for name in sorted(files):
   p=Path(parent)/name;assert not p.is_symlink();keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())


from urllib.request import ProxyHandler,Request,build_opener
authorization='Basic '+base64.b64encode(('learner:'+json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes())['admin_password']).encode()).decode()
client=build_opener(ProxyHandler({}))
def read(path):
 with client.open(Request('http://127.0.0.1:18787'+path,headers={'Authorization':authorization}),timeout=35) as r:return r.read()
for destination,number in [('offline',4),('online',3)]:
 base='/job/iot-stream-'+destination+'/'+str(number);raw=read(base+'/api/json');value=json.loads(raw)
 assert not value['building'] and value['result']=='SUCCESS'
 keep('jenkins/'+destination+'/build.json',raw);keep('jenkins/'+destination+'/stages.json',read(base+'/wfapi/describe'));keep('jenkins/'+destination+'/console.txt',read(base+'/consoleText'))
 release=root/'data/ci/releases'/('stream-'+destination+'-jenkins-'+str(number))
 keep('stream/'+destination+'/release.json',(release/'release.json').read_bytes())
 for folder in ['outputs','runs','tests']:copy('stream/'+destination+'/'+folder,release/folder)
copy('operator/stream',root/'outputs/llm-stream-ci-30a')
for label in ['assistant-samples-30a','assistant-samples-30b','gpu-data-session-30b','assistant-data-eval-30a','assistant-data-eval-30b','assistant-data-eval-30c','assistant-data-route-30a','assistant-observer-loopback-30a']:
 copy('execution/'+label,root/'outputs'/label)
copy('samples',root/'data/assistant-validation/samples-30b')
copy('execution/assistant-data-input-guard-30a',root/'outputs/assistant-data-input-guard-30a')
for folder in ['assistant-samples-5e5872a6','assistant-samples-5e5872a6-b','assistant-data-eval-6896cb13','assistant-data-eval-6896cb13-b','assistant-data-eval-3985fd22']:
 copy('source/'+folder,root/'data/llm-source'/folder)
source=root/'data/ci/source/49115d5a7dcb8c331e8169e8a37df462743d921f';copy('source/stream-ci',source)
for unit in ['iot-assistant-samples-30a','iot-assistant-samples-30b','iot-gpu-data-resume-30a','iot-gpu-data-resume-30b','iot-assistant-data-eval-30a','iot-assistant-data-eval-30b','iot-assistant-data-eval-30c']:
 keep('units/'+unit+'.txt',subprocess.check_output(['journalctl','-u',unit,'--no-pager','-o','short-iso']))
for helper in ['run-assistant-samples-30a.py','run-assistant-samples-30b.py','resume-gpu-data-30a.py','resume-gpu-data-30b.py','stream-llm-ci-30a.py','stage-assistant-data-eval-30a.py','stage-assistant-data-eval-30b.py','stage-assistant-data-eval-30c.py']:
 keep('helpers/'+helper,Path('/tmp/'+helper).read_bytes())
keep('helpers/capture.py',Path(__file__).read_bytes())
keep('gpu-descriptor-a.json',Path('/tmp/gpu-data-descriptor-30a.json').read_bytes());keep('gpu-descriptor-b.json',Path('/tmp/gpu-data-descriptor-30b.json').read_bytes())
assert json.loads((root/'outputs/assistant-data-eval-30c/verification.json').read_bytes())['passed']
manifest={'captured_utc':datetime.now(timezone.utc).isoformat(),'current_native_credentials_scanned':True,'vault_root_and_unseal_scanned':True,
 'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode());archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'x:gz') as t:t.add(out,arcname=out.name)
archive.chmod(0o644)
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'payloads':len(manifest['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()}
target=root/'outputs/assistant-data-capture-receipt-30b.json';target.write_text(json.dumps(receipt,indent=2)+'\n');target.chmod(0o644);print(json.dumps(receipt))
