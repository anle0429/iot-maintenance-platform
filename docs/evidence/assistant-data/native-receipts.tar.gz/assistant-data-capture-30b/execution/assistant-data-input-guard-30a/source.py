"""Execute the unchanged deployed input contracts on real monitoring values to check the LLM's incorrect completeness claim."""
from pathlib import Path
from hashlib import sha256
import json,subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/assistant-data-input-guard-30a';out.mkdir()
raw=(root/'data/ci/releases/stream-online-jenkins-3/outputs/verification.json').read_bytes();source=json.loads(raw)
row=next(v for v in source['reports']['replay']['online_rows'] if v['machine_id']=='P-001')
candidate={'temperature_mean_10m':row['temperature_mean'],'vibration_max_10m':row['vibration_max'],'reading_count_10m':int(row['reading_count'])}
payload={'candidate':candidate,'machine_id':row['machine_id']}
code='''import json,sys,hashlib
from pathlib import Path
from pydantic import ValidationError
import services.predictor.contracts as prediction
import services.mcp_tools.contracts as tools
value=json.load(sys.stdin);result={'schemas':{m.__name__:hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest() for m in [prediction,tools]}}
for name,model,data in [('predictor',prediction.FeatureVector,value['candidate']),('machine_tool',tools.MachineRequest,{'machine_id':value['machine_id'],'features':value['candidate']})]:
 try:model.model_validate(data);result[name]={'accepted':True}
 except ValidationError as error:result[name]={'accepted':False,'errors':[{'location':list(v['loc']),'type':v['type']} for v in error.errors(include_input=False,include_url=False)]}
print(json.dumps(result))'''
k=['/usr/local/bin/k3s','kubectl'];pods=json.loads(subprocess.check_output(k+['get','pods','-n','iot-agents','-l','app.kubernetes.io/instance=iot-retrieval-mcp','-o','json']))['items']
selected=[p for p in pods if p['status']['phase']=='Running' and not p['metadata'].get('deletionTimestamp')];assert len(selected)==2
results=[]
for index,pod in enumerate(selected):
 p=subprocess.run(k+['exec','-i','-n','iot-agents',pod['metadata']['name'],'--','python','-B','-c',code],input=json.dumps(payload).encode(),capture_output=True,timeout=45,check=True)
 (out/(str(index)+'-original.json')).write_bytes(p.stdout);value=json.loads(p.stdout)
 assert not value['predictor']['accepted'] and {e['location'][0] for e in value['predictor']['errors']}=={'current_mean_10m','current_std_10m','rpm_mean_10m','machine_age_days','prior_failures_24h'}
 assert not value['machine_tool']['accepted'] and value['machine_tool']['errors']==[{'location':['features'],'type':'extra_forbidden'}]
 results.append({'pod':pod['metadata']['name'],'uid':pod['metadata']['uid'],'images':[v['imageID'] for v in pod['status']['containerStatuses']],'result':value})
(out/'verification.json').write_text(json.dumps({'passed':True,'source_verification_sha256':sha256(raw).hexdigest(),'candidate':candidate,'results':results,
 'scope':'Actual unchanged Pydantic contracts executed in both deployed MCP replicas. Not a fresh HTTP/API request or prediction; no feature refresh or model inference. Monitoring fields deliberately renamed to their closest predictor counterparts still lack five required inputs.'},indent=2)+'\n')
(out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'passed':True,'replicas':2,'missing_predictor_fields':5,'tool_feature_override_rejected':True}))
