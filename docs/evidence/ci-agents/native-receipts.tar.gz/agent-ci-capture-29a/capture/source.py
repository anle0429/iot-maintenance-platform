"""Preserve every original agent CI build, selected source, native test/deployment facts and independent tool/delegation acceptance."""
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
from urllib.request import ProxyHandler,Request,build_opener
import argparse,base64,json,tarfile,subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform')
parser=argparse.ArgumentParser();parser.add_argument('--commit',required=True);parser.add_argument('--feature-run',required=True);args=parser.parse_args()
out=root/'outputs/agent-ci-capture-29a';assert not out.exists()
secret=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes())
client=build_opener(ProxyHandler({}));headers={'Authorization':'Basic '+base64.b64encode(('learner:'+secret['admin_password']).encode()).decode()}
def read(path):
 with client.open(Request('http://127.0.0.1:18787'+path,headers=headers),timeout=40) as response:return response.read()
jobs={}
for role in ['retrieval','drift','coordinator']:
 job=json.loads(read('/job/iot-llm-'+role+'/api/json?tree=lastBuild[number,building,result],inQueue'))
 assert not job['inQueue'] and not job['lastBuild']['building'] and job['lastBuild']['result']=='SUCCESS',role
 jobs[role]=job['lastBuild']['number']
out.mkdir()
def keep(name,raw):
 path=out/name;path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb') as stream:stream.write(raw)
def copy(name,path):keep(name,path.read_bytes())
commits=set()
for role,accepted in jobs.items():
 job='/job/iot-llm-'+role
 keep('jenkins/'+role+'/config.xml',read(job+'/config.xml'))
 for number in range(1,accepted+1):
  base=job+'/'+str(number);prefix='jenkins/'+role+'/'+str(number)+'/'
  raw=read(base+'/api/json');build=json.loads(raw);assert not build['building'];keep(prefix+'build.json',raw)
  keep(prefix+'console.txt',read(base+'/consoleText'));keep(prefix+'stages.json',read(base+'/wfapi/describe'))
  commit=next(p['value'] for a in build['actions'] for p in a.get('parameters',[]) if p['name']=='SOURCE_COMMIT');commits.add(commit)
  if number==accepted:assert commit==args.commit
  source=root/'data/ci/releases'/('llm-'+role+'-jenkins-'+str(number))/'outputs'
  for path in sorted(source.rglob('*')):
   if path.is_file():copy('release/'+role+'/'+str(number)+'/'+path.relative_to(source).as_posix(),path)
  exported=source.parent/'mcp-image.tar'
  if exported.is_file():
   small={}
   with tarfile.open(exported,mode='r|') as image:
    for member in image:
     if member.isfile() and member.size<1_000_000:small[member.name]=image.extractfile(member).read()
   image_manifest=json.loads(small['manifest.json']);assert len(image_manifest)==1
   config=image_manifest[0]['Config'];assert config in small and '..' not in Path(config).parts and not Path(config).is_absolute()
   prefix='image-export/'+role+'/'+str(number)+'/'
   keep(prefix+'manifest.json',small['manifest.json']);keep(prefix+config,small[config])
for commit in sorted(commits):
 source=root/'data/ci/source'/commit;copy('source/'+commit+'/manifest.json',source/'manifest.json')
 seal=json.loads((source/'manifest.json').read_bytes())
 for name,digest in seal['files'].items():
  raw=(source/'tree'/name).read_bytes();assert sha256(raw).hexdigest()==digest;keep('source/'+commit+'/tree/'+name,raw)
for run in [args.feature_run,'agent-feature-29j']:
 source=root/'outputs'/run
 for path in source.iterdir():
  if path.is_file():copy('features/'+run+'/'+path.name,path)
copy('session.json',root/'data/runtime/ci/session.json');copy('gpu-session.json',root/'data/runtime/ci/gpu-session.json')
for kind,name in [('sandboxagents',None),('workerpools',None),('modelconfig','default-model-config'),('scaledobjects',None)]:
 command=['/usr/local/bin/k3s','kubectl','get',kind]+([name] if name else [])+['-n','iot-agents','-o','json']
 keep('final-cluster/'+kind+'.json',subprocess.check_output(command,stderr=subprocess.PIPE,timeout=30))
copy('capture/source.py',Path(__file__))
private=[]
for name in ['agent-platform.json','mcp-tools.json']:
 private.extend(item.encode() for item in json.loads((root/'data/runtime/secrets'/name).read_bytes()).values())
private.extend(value.encode() for key,value in secret.items() if 'password' in key.lower())
variants=private+[base64.b64encode(value) for value in private]+[base64.b64encode(b'learner:'+value) for value in private]
for path in out.rglob('*'):
 if path.is_file():assert not any(value in path.read_bytes() for value in variants),'Credential-bearing capture refused'
result={'passed':True,'accepted_builds':jobs,'source_commit':args.commit,'source_revisions':sorted(commits),
 'actual_secret_values_scanned':len(private),'credential_values_archived':False,'captured_utc':datetime.now(timezone.utc).isoformat(),
 'coursework_complete':False,'scope':'Separate native Jenkins pipelines, source/image/chart identities, fresh API quality, exact cached mutation bindings and actual role answers/child sessions.'}
keep('capture.json',(json.dumps(result,indent=2)+'\n').encode())
inventory={'files':{p.relative_to(out).as_posix():{'sha256':sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
                    for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(inventory,indent=2)+'\n').encode())
archive=root/'outputs/agent-ci-capture-29a.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as packet:packet.add(out,arcname=out.name)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),
 'native_payloads':len(inventory['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()},indent=2))
