"""Start a bounded existing-lab viewer and exercise its actual loopback origin/path boundary before browser capture."""
from pathlib import Path
from hashlib import sha256
import argparse,http.client,json,socket,subprocess,time,tarfile
a=argparse.ArgumentParser();a.add_argument('packet');a.add_argument('sha256');a.add_argument('commit');args=a.parse_args()
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');packet=Path(args.packet);assert sha256(packet.read_bytes()).hexdigest()==args.sha256
stage=root/'data/llm-source'/('mcp-gateway-'+args.commit[:8]);stage.mkdir()
with tarfile.open(packet) as t:
 for m in t:assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
 t.extractall(stage,filter='data')
source=stage/'tree' 
seal=json.loads((stage/'manifest.json').read_bytes())
for n,h in seal['files'].items():assert sha256((source/n).read_bytes()).hexdigest()==h
proof=json.loads((root/'outputs/mcp-gateway-correction-30a/verification.json').read_bytes());assert proof['passed']
out=root/'outputs/mcp-gateway-view-30b';out.mkdir();(out/'operator.py').write_bytes(Path(__file__).read_bytes())
r=subprocess.run(['python3','-B','-m','unittest','discover','-s','tests','-p','test_mcp_gateway_view.py','-v'],cwd=source,capture_output=True,timeout=30)
(out/'tests.txt').write_bytes(r.stdout+r.stderr);assert r.returncode==0
with socket.socket() as sock:sock.bind(('127.0.0.1',21947))
cmd=['systemd-run','--unit=iot-mcp-gateway-view-30b','--property=RuntimeMaxSec=3600','--property=UMask=0077',
 'python3','-B',str(source/'scripts/view-mcp-gateway.py'),'--gateway-ip',proof['gateway_ip'],'--mcp-tokens',str(root/'data/runtime/secrets/mcp-tools.json'),
 '--port','21947','--ca',str(root/'outputs/mcp-gateway-deploy-30b/ca.crt'),'--audit',str(out/'access.jsonl')]
r=subprocess.run(cmd,capture_output=True,timeout=30);(out/'launch.txt').write_bytes(r.stdout+r.stderr);assert r.returncode==0
rows=[]
for case,host,origin,path,expected in [('native-docs','127.0.0.1:21947',None,'/docs',200),('foreign-origin','127.0.0.1:21947','https://foreign.invalid','/docs',403),
 ('foreign-host','foreign.invalid',None,'/docs',403),('general-proxy','127.0.0.1:21947',None,'/admin',403)]:
 deadline=time.monotonic()+20
 while True:
  try:
   conn=http.client.HTTPConnection('127.0.0.1',21947,timeout=20);conn.request('GET',path,headers={'Host':host,**({'Origin':origin} if origin else {})});resp=conn.getresponse();body=resp.read();break
  except ConnectionRefusedError:
   if time.monotonic()>=deadline:raise
   time.sleep(.2)
 conn.close();rows.append({'case':case,'status':resp.status,'body_sha256':sha256(body).hexdigest(),'response_bytes':len(body)});assert resp.status==expected
(out/'http-boundary.json').write_text(json.dumps(rows,indent=2)+'\n')
unit=subprocess.check_output(['systemctl','show','iot-mcp-gateway-view-30b','-p','InvocationID','-p','ActiveState','-p','Result','-p','RuntimeMaxUSec']);(out/'unit.txt').write_bytes(unit)
print(json.dumps({'passed':True,'local_boundary_cases':4,'port':21947,'native_tests':3}));print(unit.decode())
