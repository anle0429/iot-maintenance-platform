"""Retain the actual retrieval readiness failure before changing any deployment or lease."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/mcp-gateway-diagnosis-30a';out.mkdir()
k=['/usr/local/bin/k3s','kubectl'];report={'checked_utc':datetime.now(timezone.utc).isoformat()}
for name,values in [('retrieval', ['get','deployment','iot-retrieval-mcp','-n','iot-agents']),('pods',['get','pods','-n','iot-agents']),
 ('events',['get','events','-n','iot-agents']),('nodes',['get','nodes']),('gateway-policy',['get','networkpolicies','-n','iot-gateway']),
 ('cpu-session',[])]:
 if name=='cpu-session':raw=(root/'data/runtime/ci/session.json').read_bytes()
 else:raw=subprocess.check_output(k+values+['-o','json'])
 (out/(name+'.json')).write_bytes(raw);value=json.loads(raw)
 if name=='retrieval':report['retrieval']=value.get('status',{})
 if name=='pods':
  report['mcp_pods']=[{'name':v['metadata']['name'],'phase':v['status']['phase'],'conditions':v['status'].get('conditions'),
   'states':[{'name':s['name'],'ready':s['ready'],'restartCount':s['restartCount'],'state':s['state'],'lastState':s.get('lastState')} for s in v['status'].get('containerStatuses',[])]}
   for v in value['items'] if 'mcp' in v['metadata']['name']]
 if name=='nodes':report['nodes']=[{'name':v['metadata']['name'],'conditions':v['status']['conditions']} for v in value['items']]
(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n');(out/'source.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(report,indent=2))
