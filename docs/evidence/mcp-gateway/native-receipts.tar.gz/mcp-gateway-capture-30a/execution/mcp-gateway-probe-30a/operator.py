"""Use the retained MCP client image to test the private gateway with credentials passed through stdin only."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone,timedelta
from urllib.request import build_opener,ProxyHandler
import base64,json,os,subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');stage=root/'data/llm-source/mcp-gateway-d749040d';source=stage/'tree'
seal=json.loads((stage/'manifest.json').read_bytes())
for n,h in seal['files'].items():assert sha256((source/n).read_bytes()).hexdigest()==h
refresh=json.loads((root/'outputs/feature-refresh-mcp-30a/verification.json').read_bytes())
assert refresh['passed'] and datetime.fromisoformat(refresh['lease_expires_utc'])-datetime.now(timezone.utc)>timedelta(minutes=20)
deploy=json.loads((root/'outputs/mcp-gateway-correction-30a/verification.json').read_bytes());assert deploy['passed']
k=['/usr/local/bin/k3s','kubectl']
out=root/'outputs/mcp-gateway-probe-30a';out.mkdir();os.chown(out,10001,10001)
(out/'operator.py').write_bytes(Path(__file__).read_bytes());(out/'source.json').write_text(json.dumps(seal,indent=2)+'\n')
(out/'ca.crt').write_bytes((root/'outputs/mcp-gateway-deploy-30b/ca.crt').read_bytes());(out/'ca.crt').chmod(0o644)
def get(*values):return json.loads(subprocess.check_output(k+list(values)+['-o','json'],stderr=subprocess.PIPE))
for role in ['retrieval','drift']:
 v=get('get','deployment','iot-'+role+'-mcp','-n','iot-agents');assert v.get('status',{}).get('availableReplicas',0)==2
 (out/(role+'-before.json')).write_text(json.dumps(v,indent=2)+'\n')
pods=get('get','pods','-n','iot-agents');(out/'pods-before.json').write_text(json.dumps(pods,indent=2)+'\n')
tokens=json.loads((root/'data/runtime/secrets/mcp-tools.json').read_bytes())
assert base64.b64decode(get('get','secret','iot-retrieval-mcp-auth','-n','iot-agents')['data']['token']).decode()==tokens['retrieval']
service=get('get','service','iot-feature-api','-n','iot-features');opener=build_opener(ProxyHandler({}));selected=None
for i in range(1,21):
 machine=f'P-{i:03}'
 with opener.open('http://'+service['spec']['clusterIP']+'/v1/machines/'+machine+'/features',timeout=10) as response:body=response.read()
 if json.loads(body)['operating_context']['status']=='operating':selected=machine;break
assert selected
(out/'selected-feature-original.json').write_bytes(body)
image=json.loads(subprocess.check_output(['docker','image','inspect','iot-ci-mcp:llm-retrieval-jenkins-3']))[0]
(out/'client-image.json').write_text(json.dumps({'id':image['Id'],'user':image['Config']['User'],'repo_digests':image.get('RepoDigests',[])},indent=2)+'\n')
command=['docker','run','-i','--name','iot-mcp-gateway-probe-30a','--init','--read-only','--network','host','--add-host','retrieval.iot.test:'+deploy['gateway_ip'],
 '--user','10001:10001','--memory','512m','--memory-swap','512m','--cpus','1','--pids-limit','128','--cap-drop','ALL','--security-opt','no-new-privileges','--tmpfs','/tmp:rw,nosuid,size=64m',
 '--env','PYTHONDONTWRITEBYTECODE=1','--mount','type=bind,src='+str(source/'scripts/probe-mcp-gateway.py')+',dst=/probe.py,readonly',
 '--mount','type=bind,src='+str(out)+',dst=/proof','--entrypoint','python',image['Id'],'-B','/probe.py','--gateway-ip',deploy['gateway_ip'],'--ca','/proof/ca.crt','--output','/proof/run']
with (out/'console.txt').open('x') as log:
 result=subprocess.run(command,input=json.dumps({'mcp':tokens['retrieval'],'other_role_token':tokens['drift'],'machine_id':selected}).encode(),stdout=log,stderr=subprocess.STDOUT,timeout=480)
actual=json.loads(subprocess.check_output(['docker','inspect','iot-mcp-gateway-probe-30a']))[0]
(out/'container.json').write_text(json.dumps({'id':actual['Id'],'image':actual['Image'],'state':actual['State'],'memory':actual['HostConfig']['Memory'],'network':actual['HostConfig']['NetworkMode'],'nano_cpus':actual['HostConfig']['NanoCpus'],'user':actual['Config']['User']},indent=2)+'\n')
assert result.returncode==0 and not actual['State']['OOMKilled']
report=json.loads((out/'run/verification.json').read_bytes());assert report['passed']
for role in ['retrieval','drift']:
 v=get('get','deployment','iot-'+role+'-mcp','-n','iot-agents');old=json.loads((out/(role+'-before.json')).read_bytes())
 assert v['metadata']['uid']==old['metadata']['uid'] and v['spec']==old['spec']
 (out/(role+'-after.json')).write_text(json.dumps(v,indent=2)+'\n')
(out/'pods-after.json').write_text(json.dumps(get('get','pods','-n','iot-agents'),indent=2)+'\n')
for p in out.rglob('*'):
 if p.is_file():assert not any(s.encode() in p.read_bytes() for s in [tokens['retrieval'],tokens['drift']])
print(json.dumps(report,indent=2))
