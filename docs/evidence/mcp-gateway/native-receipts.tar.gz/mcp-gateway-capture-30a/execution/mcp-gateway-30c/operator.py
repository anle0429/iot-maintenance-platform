"""Stage canonical corrected source and patch only the same rejected ingress, preserving its original identity and certificate."""
from pathlib import Path
from hashlib import sha256
import argparse,json,subprocess,tarfile
p=argparse.ArgumentParser();p.add_argument('packet');p.add_argument('sha256');p.add_argument('commit');a=p.parse_args()
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');packet=Path(a.packet)
assert sha256(packet.read_bytes()).hexdigest()==a.sha256
stage=root/'data/llm-source'/('mcp-gateway-'+a.commit[:8]);stage.mkdir()
with tarfile.open(packet) as t:
 for m in t:assert m.isfile() and '..' not in Path(m.name).parts and not Path(m.name).is_absolute()
 t.extractall(stage,filter='data')
seal=json.loads((stage/'manifest.json').read_bytes());assert seal['commit']==a.commit and len(seal['files'])==7
for n,h in seal['files'].items():assert sha256((stage/'tree'/n).read_bytes()).hexdigest()==h
out=root/'outputs/mcp-gateway-30c';out.mkdir();(out/'source.json').write_text(json.dumps(seal,indent=2)+'\n')
(out/'operator.py').write_bytes(Path(__file__).read_bytes())
command=['python3','-B',str(stage/'tree/scripts/update-mcp-gateway-route.py'),'--deployment',str(root/'outputs/mcp-gateway-deploy-30b'),
 '--output',str(root/'outputs/mcp-gateway-correction-30a')]
with (out/'console.txt').open('x') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=240)
(out/'exit.json').write_text(json.dumps({'exit':r.returncode})+'\n');assert r.returncode==0
print((root/'outputs/mcp-gateway-correction-30a/verification.json').read_text())
