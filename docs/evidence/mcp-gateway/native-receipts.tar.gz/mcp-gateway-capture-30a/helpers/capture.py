"""Seal original paired sample exports, actual stream CI and the exact continued GPU evidence-reading cohort."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from urllib.parse import quote
import base64,json,os,re,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/mcp-gateway-capture-30a';os.umask(0o077);out.mkdir(exist_ok=False);private=[]

def credential(raw):
 if isinstance(raw,str):raw=raw.encode()
 if len(raw)>=12:
  private.append(raw)
  if raw.startswith(b'Bearer '):private.append(raw[7:])
def walk(value,key=''):
 if isinstance(value,dict):
  if value.get('name')=='Authorization' and isinstance(value.get('value'),str):credential(value['value'])
  if {'username','password'}<=set(value):credential(base64.b64encode((value['username']+':'+value['password']).encode()))
  for name,child in value.items():walk(child,name)
 elif isinstance(value,list):
  for child in value:walk(child,key)
 elif isinstance(value,str) and re.search('password|token|apikey|secretid|roleid|keysbase64|authorization',re.sub('[^a-z]','',key.lower())):credential(value)
paths=[root/'data/runtime/secrets'/n for n in ['agent-platform.json','mcp-tools.json']]
paths.extend(root/'data/runtime/agent-vault-29a-private'/n for n in ['gateway-credentials.json','gateway-approle.json','services-approle.json'])
paths.extend([root/'data/runtime/agent-gateway-29a-private/credentials.json',root/'data/runtime/gateway-28-private/credentials.json',root/'data/runtime/ci/jenkins-private/bootstrap.json'])
paths.extend(root/'data/runtime/vault-28-private'/n for n in ['ci-approle.json','gateway-approle.json','bootstrap.json'])
for path in paths:walk(json.loads(path.read_bytes()))
jenkins=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());credential(base64.b64encode(('learner:'+jenkins['admin_password']).encode()));jenkins=None
credential((root/'data/runtime/llm-monitoring-29a/auth/token').read_bytes().strip())
k=['/usr/local/bin/k3s','kubectl'];refs={('iot-llm','iot-llm-observer-client','API_KEY'),('iot-agents','iot-local-model-client','API_KEY')}
def get(*args):return json.loads(subprocess.check_output(k+['get',*args,'-o','json'],timeout=30,stderr=subprocess.PIPE))
for deployment in get('deployments','-n','iot-agents')['items']:
 for container in deployment['spec']['template']['spec']['containers']:
  for item in container.get('env',[]):
   ref=item.get('valueFrom',{}).get('secretKeyRef')
   if ref and re.search('password|token|key|auth',ref['key'],re.I):refs.add(('iot-agents',ref['name'],ref['key']))
for remote in get('remotemcpservers','-n','iot-agents')['items']:
 for header in remote['spec'].get('headersFrom',[]):
  ref=header.get('valueFrom',{})
  if ref.get('type')=='Secret':refs.add(('iot-agents',ref['name'],ref['key']))
for namespace,name,key in sorted(refs):
 secret=get('secret',name,'-n',namespace);credential(base64.b64decode(secret['data'][key]));secret=None
for value in json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes())['keys_base64']:credential(value)
private=list({v for raw in private for v in [raw,base64.b64encode(raw),base64.b64encode(b'Bearer '+raw),quote(raw.decode(),safe='').encode()]})
def keep(name,body):
 assert len(body)<10000000 and not any(v in body for v in private),name
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
def copy(label,folder):
 assert folder.is_dir(),folder
 for parent,dirs,files in os.walk(folder):
  dirs[:]=[v for v in dirs if v!='__pycache__']
  for name in sorted(files):
   p=Path(parent)/name;assert not p.is_symlink();keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())


for folder in ['mcp-gateway-30a','mcp-gateway-deploy-30a','mcp-gateway-diagnosis-30a','mcp-gateway-30b','mcp-gateway-deploy-30b','mcp-gateway-30c','mcp-gateway-correction-30a','mcp-gateway-probe-30a','mcp-gateway-view-30a','mcp-gateway-view-30b','feature-refresh-mcp-30a']:
 copy('execution/'+folder,root/'outputs'/folder)
for folder in ['mcp-gateway-3a889305','mcp-gateway-537fbde4','mcp-gateway-d749040d','mcp-gateway-7c08ce4c']:
 copy('source/'+folder,root/'data/llm-source'/folder)
copy('feature-state',root/'data/demo/demo-mcp-30a/state')
for kind in ['deployments','services','networkpolicies','ingresses','roles','rolebindings','sandboxagents','workerpools','modelconfigs','pods','events']:
 keep('current/'+kind+'.json',subprocess.check_output(k+['get',kind,'-n','iot-agents','-o','json'],stderr=subprocess.PIPE,timeout=30))
for name in ['agent-gateway-auth','agent-gateway-tls','iot-retrieval-mcp-auth','iot-drift-mcp-auth','mcp-gateway-tls']:
 value=get('secret',name,'-n','iot-agents')
 keep('current/'+name+'-identity.json',(json.dumps({'uid':value['metadata']['uid'],'type':value['type'],
  'data_sha256':{n:sha256(base64.b64decode(b)).hexdigest() for n,b in value['data'].items()}},indent=2)+'\n').encode())
for unit in ['iot-mcp-gateway-30a','iot-feature-mcp-30a','iot-mcp-gateway-30b','iot-mcp-gateway-30c','iot-mcp-gateway-probe-30a','iot-mcp-gateway-view-30a','iot-mcp-gateway-view-30b']:
 keep('units/'+unit+'.txt',subprocess.check_output(['journalctl','-u',unit,'--no-pager','-o','short-iso']))
for helper in ['run-mcp-gateway-30a.py','run-mcp-gateway-30b.py','run-mcp-gateway-30c.py','diagnose-mcp-gateway-30a.py','refresh-feature-mcp-30a.py','iot-refresh-demo-feature-29k.py','run-mcp-gateway-probe-30a.py','start-mcp-view-30a.py','start-mcp-view-30b.py']:
 keep('helpers/'+helper,Path('/tmp/'+helper).read_bytes())
keep('helpers/capture.py',Path(__file__).read_bytes())
assert json.loads((root/'outputs/mcp-gateway-probe-30a/run/verification.json').read_bytes())['passed']
manifest={'captured_utc':datetime.now(timezone.utc).isoformat(),'current_native_credentials_scanned':True,'vault_root_and_unseal_scanned':True,
 'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode());archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'x:gz') as t:t.add(out,arcname=out.name)
archive.chmod(0o644)
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'payloads':len(manifest['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()}
target=root/'outputs/mcp-gateway-capture-receipt-30a.json';target.write_text(json.dumps(receipt,indent=2)+'\n');target.chmod(0o644);print(json.dumps(receipt))
