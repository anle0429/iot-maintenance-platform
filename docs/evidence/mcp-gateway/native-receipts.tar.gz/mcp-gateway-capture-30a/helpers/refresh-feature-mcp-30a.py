"""Start one genuine fresh SDK preparation after natural expiry, using the exact retained guarded helper."""
from pathlib import Path
from hashlib import sha256
import subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');helper=Path('/tmp/iot-refresh-demo-feature-29k.py')
assert sha256(helper.read_bytes()).hexdigest()=='ec2be13e02a218a5e583c7006ce418648ee8bb1829acb1c5d9b10f89e41552c0'
subprocess.run(['python3','-B',str(helper),'--runtime-root',str(root),'--runtime-source',str(root/'data/observability-source-2fceb32/tree'),
 '--run','demo-mcp-30a','--output',str(root/'outputs/feature-refresh-mcp-30a')],check=True,timeout=900)
