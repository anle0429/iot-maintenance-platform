"""Seal original host, discovery, viewer and load receipts without repeating business workloads."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import base64,json,os,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/llm-monitoring-capture-29a';os.umask(0o077);out.mkdir(exist_ok=False)
private=[]
paths=[root/'data/runtime/secrets'/n for n in ['agent-platform.json','mcp-tools.json']]+[root/'data/runtime/agent-vault-29a-private'/n for n in ['gateway-credentials.json','gateway-approle.json','services-approle.json']]
paths.extend([root/'data/runtime/agent-gateway-29a-private/credentials.json',root/'data/runtime/gateway-28-private/credentials.json'])
for p in paths:private.extend(v.encode() for v in json.loads(p.read_bytes()).values() if isinstance(v,str) and len(v)>=16)
private.extend([json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes())['root_token'].encode(),(root/'data/runtime/llm-monitoring-29a/auth/token').read_bytes().strip()])
private=list({v for value in private for v in [value,base64.b64encode(value)]})
def keep(name,body):
 assert len(body)<10000000 and not any(v in body for v in private),name
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
def copy(label,folder):
 assert folder.is_dir(),folder
 for parent,dirs,files in os.walk(folder):
  dirs[:]=[v for v in dirs if v!='__pycache__']
  for name in sorted(files):
   p=Path(parent)/name;assert not p.is_symlink();keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())
for name in ['gpu-ssh-public-29a','gpu-host-exporter-deploy-29a','gpu-host-exporter-pilot-29a','llm-metrics-configure-29a','llm-monitoring-stage-29a',
 'llm-dashboards-stage-29a','llm-dashboards-configure-29a','llm-dashboard-probe-29a','llm-dashboard-probe-29b','llm-dashboard-labels-29a',
 'llm-load-stage-29a','llm-load-stage-29b','llm-observer-load-29a','llm-observer-load-29b','llm-monitoring-view-29a']:
 copy('native/'+name,root/'outputs'/name)
omitted=[];build=root/'outputs/gpu-host-exporter-build-29a'
for p in sorted(build.iterdir()):
 if p.is_file() and p.name!='image.tar' and p.stat().st_size<2000000:keep('native/gpu-host-exporter-build-29a/'+p.name,p.read_bytes())
 else:omitted.append({'path':str(p.relative_to(root)),'reason':'Image archive or build context; original hashes and native packaging readbacks are retained.'})
for name in ['gpu-host-telemetry-cc6465bc','llm-monitoring-5db51fa7','llm-dashboards-41e38b3f','llm-load-faba88cb','llm-load-f802aae6']:
 copy('source/'+name,root/'data/llm-source'/name)
units=['iot-gpu-host-exporter-build-29a','iot-gpu-host-exporter-deploy-29a','iot-llm-metrics-configure-29a','iot-llm-dashboards-configure-29a','iot-llm-observer-load-29a','iot-llm-observer-load-29b',
 'iot-llm-view-metrics-29a','iot-llm-view-logs-29a','iot-llm-view-traces-29a']
for unit in units:
 for label,argv in [('unit',['systemctl','show',unit]),('journal',['journalctl','-u',unit,'--no-pager','-o','json'])]:
  result=subprocess.run(argv,capture_output=True,timeout=30);assert result.returncode==0;keep('units/'+unit+'/'+label+'.stdout',result.stdout)
for name in ['llm-metrics-configure-launch-29a.txt','llm-dashboards-configure-launch-29a.txt','llm-observer-load-launch-29a.txt','llm-observer-load-launch-29b.txt']:
 keep('launch/'+name,(root/'outputs'/name).read_bytes())
for name in ['probe-llm-dashboards-29a.py','view-llm-monitoring-29a.py','update-llm-dashboard-labels-29a.py']:
 keep('helpers/'+name,(Path('/tmp')/name).read_bytes())
gpu=json.loads(Path('/tmp/gpu-host-capture-receipt-29a.json').read_bytes());raw=Path('/tmp/gpu-host-capture-29a.tar.gz').read_bytes()
assert len(raw)==gpu['bytes'] and sha256(raw).hexdigest()==gpu['sha256'];keep('gpu/original-native.tar.gz',raw);keep('gpu/native-archive.json',(json.dumps(gpu,indent=2)+'\n').encode())
keep('source/gpu-host-readable.json',Path('/tmp/llm-gpu-host-readable.json').read_bytes())
keep('capture-notes.json',(json.dumps({'omitted_large_build_assets':omitted,'load_attempt_a':'Failed before making model requests: load UID could not traverse the discovery identity private directory. Its zero-request Locust output and original journal are retained. Attempt B uses a separate 0700/0600 temporary directory and leaves discovery permissions unchanged.',
 'trace_ui_limit':'The original SDK trace is displayed with missing-service-name and Incomplete warnings. No missing parent/span or success status was fabricated.',
 'business_workload_repeated_for_capture':False},indent=2)+'\n').encode())
keep('capture-helper.py',Path(__file__).read_bytes())
manifest={'captured_utc':datetime.now(timezone.utc).isoformat(),'native_credentials_scanned':True,'workloads_rerun_for_capture':False,
 'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode());archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'x:gz') as packet:packet.add(out,arcname=out.name)
archive.chmod(0o644);receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'payloads':len(manifest['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()}
destination=root/'outputs/llm-monitoring-capture-receipt-29a.json';destination.write_text(json.dumps(receipt,indent=2)+'\n');destination.chmod(0o644);print(json.dumps(receipt))
