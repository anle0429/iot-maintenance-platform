"""Guard a cosmetic legend change with exact prior bytes and unchanged query expressions."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from urllib.request import urlopen
import json,os,time
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');target=root/'data/runtime/monitoring-28/dashboards/llm-gpu-host.json';out=root/'outputs/llm-dashboard-labels-29a';out.mkdir(exist_ok=False)
old=target.read_bytes();new=Path('/tmp/llm-gpu-host-readable.json').read_bytes()
assert sha256(old).hexdigest()=='103f83843eed4b6a62aa5a975fa7c28d665754ae78535d093fa71b5c1364139b' and sha256(new).hexdigest()=='652aa648156be2c4f915dd9ce05d0df8e631cd4e8e2554be77697adb7e8f0b7c'
a=json.loads(old);b=json.loads(new)
for x,y in zip(a['panels'],b['panels'],strict=True):
 for t,u in zip(x.get('targets',[]),y.get('targets',[]),strict=True):
  assert t['expr']==u['expr'];t['legendFormat']='GPU worker'
assert a==b
(out/'before.json').write_bytes(old);(out/'after.json').write_bytes(new)
temp=target.with_suffix('.pending');temp.write_bytes(new);temp.chmod(0o644);os.replace(temp,target)
for i in range(15):
 with urlopen('http://127.0.0.1:13001/api/dashboards/uid/iot-llm-gpu-host',timeout=10) as r:raw=r.read()
 (out/('readback-'+str(i)+'.json')).write_bytes(raw)
 if json.loads(raw)['dashboard']['panels']==b['panels']:break
 time.sleep(2)
else:raise AssertionError('Cosmetic dashboard update not visible')
report={'passed':True,'utc':datetime.now(timezone.utc).isoformat(),'source_commit':'dda46b6','before_sha256':sha256(old).hexdigest(),'after_sha256':sha256(new).hexdigest(),'query_expressions_unchanged':True}
(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
