"""Seal original policy requests, source packets, dashboard readbacks and journals without another model request."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from urllib.parse import quote
import base64,json,os,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/llm-policy-window-capture-30a';os.umask(0o077);out.mkdir(exist_ok=False);private=[]
paths=[root/'data/runtime/secrets'/n for n in ['agent-platform.json','mcp-tools.json']]
paths.extend(root/'data/runtime/agent-vault-29a-private'/n for n in ['gateway-credentials.json','gateway-approle.json','services-approle.json'])
paths.extend([root/'data/runtime/agent-gateway-29a-private/credentials.json',root/'data/runtime/gateway-28-private/credentials.json'])
paths.extend(root/'data/runtime/vault-28-private'/n for n in ['ci-approle.json','gateway-approle.json'])
for path in paths:
 value=json.loads(path.read_bytes());private.extend(v.encode() for v in value.values() if isinstance(v,str) and len(v)>=16)
 if {'username','password'}<=set(value):private.append(base64.b64encode((value['username']+':'+value['password']).encode()))
bootstrap=json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes());private.append(bootstrap['root_token'].encode());private.extend(v.encode() for v in bootstrap['keys_base64']);bootstrap=None
private.append((root/'data/runtime/llm-monitoring-29a/auth/token').read_bytes().strip());k=['/usr/local/bin/k3s','kubectl']
for name,namespace in [('iot-llm-observer-client','iot-llm'),('iot-local-model-client','iot-agents')]:
 secret=json.loads(subprocess.check_output(k+['get','secret',name,'-n',namespace,'-o','json']));private.extend(base64.b64decode(v) for v in secret['data'].values());secret=None
private=list({v for raw in private for v in [raw,base64.b64encode(raw),base64.b64encode(b'Bearer '+raw),quote(raw.decode(),safe='').encode()]})
def keep(name,body):
 assert len(body)<10000000 and not any(v in body for v in private),name
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
def copy(label,folder):
 assert folder.is_dir(),folder
 for parent,dirs,files in os.walk(folder):
  dirs[:]=[v for v in dirs if v!='__pycache__']
  for name in sorted(files):
   p=Path(parent)/name;assert not p.is_symlink();keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())
for name in ['policy-window-stage-30a','policy-window-30a','policy-window-view-30a','policy-window-view-30b']:
 copy('native/'+name,root/'outputs'/name)
for name in ['policy-window-24efae5c','policy-window-view-752bae3d','policy-window-view-4de60f36']:
 copy('source/'+name,root/'data/llm-source'/name)
for unit in ['iot-policy-window-30a','iot-policy-window-view-30a','iot-policy-window-view-30b']:
 for label,argv in [('unit',['systemctl','show',unit]),('journal',['journalctl','-u',unit,'--no-pager','-o','json'])]:
  result=subprocess.run(argv,capture_output=True,timeout=30);assert result.returncode==0;keep('units/'+unit+'/'+label+'.stdout',result.stdout)
for name in ['policy-window-launch-30a.txt','policy-window-view-launch-30a.txt','policy-window-view-launch-30b.txt']:
 keep('launch/'+name,(root/'outputs'/name).read_bytes())
keep('capture-notes.json',(json.dumps({'workloads_rerun_for_capture':False,'new_model_requests_for_capture':0,
 'admissions':'Twelve deliberately synthetic prompts, three short allowed generations and nine pre-inference rejections. One prompt has all four categories; twelve category hits do not mean twelve blocked prompts.',
 'view_a':'The first numeric API comparison used the current query clock while the dashboard selected the earlier experiment end. Browser inspection found No data for later-published batch gauges. Original A receipts and PC browser evidence are retained; A is not accepted as visual completion.',
 'view_b':'The scoped repair preserves panel expressions, existing jobs and dashboards. Its display ends after batch ingestion; all eight targets are rechecked at the actual display end or displayed range. The original measured window and inference evidence are unchanged.',
 'frequency':'Exact ledger count divided by measured elapsed time is separate from the original observer one-minute extrapolated Prometheus rate. This selected synthetic cohort is not a production-prevalence estimate.',
 'omissions':'No real prompt corpus, runtime Secret objects, private credential files, model weights, bulk data or cloud bootstrap metadata.'},indent=2)+'\n').encode())
keep('capture-helper.py',Path(__file__).read_bytes())
manifest={'captured_utc':datetime.now(timezone.utc).isoformat(),'current_native_credentials_scanned':True,'workloads_rerun_for_capture':False,
 'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode());archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'x:gz') as packet:packet.add(out,arcname=out.name)
archive.chmod(0o644);receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'payloads':len(manifest['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()}
destination=root/'outputs/llm-policy-window-capture-receipt-30a.json';destination.write_text(json.dumps(receipt,indent=2)+'\n');destination.chmod(0o644);print(json.dumps(receipt))
