"""Run the three already-authorized production agent jobs sequentially after the verified negative gate; never resubmit a live build."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
from urllib.request import build_opener,ProxyHandler,Request
from urllib.error import HTTPError
import base64,json,subprocess,time
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/agent-policy-production-30a';out.mkdir(exist_ok=False)
assert json.loads((root/'outputs/agent-policy-ci-finish-negative-30a/verification.json').read_bytes())['passed']
private=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());auth='Basic '+base64.b64encode(('learner:'+private['admin_password']).encode()).decode();opener=build_opener(ProxyHandler({}));completed=[]
for role in ['coordinator','retrieval','drift']:
 gpu=json.loads((root/'data/runtime/ci/gpu-session.json').read_bytes());stop=datetime.fromisoformat(gpu['last_start_utc'])+timedelta(seconds=gpu['max_duration_seconds'])
 assert (stop-datetime.now(timezone.utc)).total_seconds()>1200,'Checkpoint before launching another job with a short GPU session'
 tag='production-'+role+'-30a'
 raw=subprocess.check_output(['/usr/bin/python3','-B','/tmp/trigger-agent-policy-ci-30a.py','--role',role,'--scenario','production','--tag',tag],timeout=150,stderr=subprocess.PIPE)
 (out/(role+'-launch.stdout')).write_bytes(raw);launch=json.loads(raw);number=launch['expected_build'];print(json.dumps({'role':role,'build':number,'launched':True}),flush=True)
 deadline=time.monotonic()+1200
 while time.monotonic()<deadline:
  try:
   with opener.open(Request('http://127.0.0.1:18787/job/iot-llm-'+role+'/'+str(number)+'/api/json?tree=building,result',headers={'Authorization':auth}),timeout=25) as response:state=json.load(response)
  except HTTPError as error:
   if error.code!=404:raise
   with opener.open(Request(launch['queue_url']+'api/json',headers={'Authorization':auth}),timeout=25) as response:queued=json.load(response)
   assert not queued.get('cancelled'),'The original queue item was cancelled; do not resubmit'
   time.sleep(5);continue
  if not state['building']:break
  time.sleep(5)
 else:raise TimeoutError('Keep the original Jenkins build; observation ended without declaring it terminal')
 raw=subprocess.check_output(['/usr/bin/python3','-B','/tmp/finish-agent-policy-ci-30a.py','--tag',tag],timeout=150,stderr=subprocess.PIPE)
 (out/(role+'-finish.stdout')).write_bytes(raw);result=json.loads(raw);assert result['passed'] and result['jenkins_result']=='SUCCESS';completed.append(result)
 print(json.dumps({'role':role,'build':number,'verified':True,'gpu_output_tokens':result['native_generated_token_delta']}),flush=True)
(out/'verification.json').write_text(json.dumps({'passed':True,'checked_utc':datetime.now(timezone.utc).isoformat(),'jobs':completed,
 'source_commit':'beb7f5c7dbec14e8429a0877c87eb17e6c901b7b','scope':'Three distinct sequential source-bound production jobs, each with actual OPA admission/recheck and native tool-grounded answer validation.'},indent=2)+'\n')
