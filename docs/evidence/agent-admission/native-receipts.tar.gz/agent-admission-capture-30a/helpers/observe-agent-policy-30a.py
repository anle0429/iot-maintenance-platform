"""Capture current non-secret agent resources and the exact retained OPA binary before writing the new admission policy."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,os,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/agent-policy-observed-30a';os.umask(0o077);out.mkdir(exist_ok=False)
k=['/usr/local/bin/k3s','kubectl'];helm=[str(root/'data/runtime/kubernetes-assets-27/helm/helm'),'--kubeconfig','/etc/rancher/k3s/k3s.yaml']
for kind in ['sandboxagents','modelconfigs','remotemcpservers','workerpools','networkpolicies','scaledobjects']:
 raw=subprocess.check_output(k+['get',kind,'-n','iot-agents','-o','json'],timeout=30,stderr=subprocess.PIPE)
 # These approved object kinds contain Secret references, never Secret data.
 value=json.loads(raw);assert value['kind'].endswith('List');(out/(kind+'.json')).write_bytes(raw)
for label,argv in [('rendered-manifest',helm+['get','manifest','iot-agents','-n','iot-agents']),('values',helm+['get','values','iot-agents','-n','iot-agents','--all','-o','json'])]:
 raw=subprocess.check_output(argv,timeout=30,stderr=subprocess.PIPE);(out/(label+'.txt')).write_bytes(raw)
pin=json.loads((root/'infra/policy/opa-assets.json').read_bytes());binary=root/'data/runtime/policy-assets-28/opa';assert binary.stat().st_size==pin['bytes'] and sha256(binary.read_bytes()).hexdigest()==pin['sha256']
version=subprocess.check_output([str(binary),'version','--format=json'],timeout=10);(out/'opa-version.json').write_bytes(version)
report={'checked_utc':datetime.now(timezone.utc).isoformat(),'opa_binary':str(binary),'opa_sha256':pin['sha256'],'deployment_changes':0,'model_requests':0}
(out/'observation.json').write_text(json.dumps(report,indent=2)+'\n');archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'x:gz') as t:t.add(out,arcname=out.name)
archive.chmod(0o644);print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest()}))
