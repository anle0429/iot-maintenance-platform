"""Submit exactly one idle source-bound agent job and retain a pre-build resource/counter snapshot for the controlled OPA test."""
from pathlib import Path
from datetime import datetime,timezone
from urllib.request import build_opener,ProxyHandler,Request,HTTPCookieProcessor
from urllib.parse import urlencode
from http.cookiejar import CookieJar
import argparse,base64,json,os,re,subprocess,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--role',choices=['retrieval','drift','coordinator'],required=True);p.add_argument('--scenario',choices=['production','unsafe-tool'],required=True);p.add_argument('--tag',required=True);a=p.parse_args();assert re.fullmatch('[a-z0-9-]{1,40}',a.tag)
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');commit='beb7f5c7dbec14e8429a0877c87eb17e6c901b7b';source=root/'data/ci/source'/commit/'tree';os.umask(0o077)
assert json.loads((root/'outputs/agent-policy-ci-stage-30b/verification.json').read_bytes())['passed']
assert json.loads((root/'outputs/feature-policy-30a/verification.json').read_bytes())['passed']
private=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());auth='Basic '+base64.b64encode(('learner:'+private['admin_password']).encode()).decode();client=build_opener(ProxyHandler({}),HTTPCookieProcessor(CookieJar()))
def call(path,body=None,extra=None):
 return client.open(Request('http://127.0.0.1:18787'+path,data=body,headers={'Authorization':auth,**(extra or {})}),timeout=35)
for role in ['retrieval','drift','coordinator']:
 with call('/job/iot-llm-'+role+'/api/json?tree=inQueue,lastBuild[building]') as response:state=json.load(response)
 assert not state['inQueue'] and not state['lastBuild']['building'],'Observe the same live job before submitting another shared deployment'
job='/job/iot-llm-'+a.role
with call(job+'/config.xml') as response:config=ET.fromstring(response.read())
assert config.find('definition/script').text==(source/'infra/ci/AgentsPolicy.Jenkinsfile').read_text()
with call(job+'/api/json?tree=nextBuildNumber') as response:next_build=json.load(response)['nextBuildNumber']
out=root/'outputs'/('agent-policy-ci-trigger-'+a.tag);out.mkdir(exist_ok=False);k=['/usr/local/bin/k3s','kubectl']
def get(*args):return json.loads(subprocess.check_output(k+['get',*args,'-o','json'],timeout=30,stderr=subprocess.PIPE))
inventory={name:get(name,'-n','iot-agents') for name in ['sandboxagents','modelconfigs','remotemcpservers','workerpools','deployments']}
(out/'resources-before.json').write_text(json.dumps(inventory,indent=2)+'\n')
helm=[str(root/'data/runtime/kubernetes-assets-27/helm/helm'),'--kubeconfig','/etc/rancher/k3s/k3s.yaml'];revisions={}
for release in ['iot-agents','iot-retrieval-mcp','iot-drift-mcp']:revisions[release]=json.loads(subprocess.check_output(helm+['history',release,'-n','iot-agents','--max','1','-o','json'],timeout=30))
(out/'helm-before.json').write_text(json.dumps(revisions,indent=2)+'\n')
gpu=get('service','iot-model-gpu','-n','iot-llm')['spec']['clusterIP']
with build_opener(ProxyHandler({})).open('http://'+gpu+':8080/metrics?model=iot-qwen2.5-7b',timeout=20) as response:(out/'model-before.prom').write_bytes(response.read())
with call('/crumbIssuer/api/json') as response:crumb=json.load(response)
with call(job+'/buildWithParameters',urlencode({'SOURCE_COMMIT':commit,'ADMISSION_SCENARIO':a.scenario}).encode(),{crumb['crumbRequestField']:crumb['crumb'],'Content-Type':'application/x-www-form-urlencoded'}) as response:
 report={'source_commit':commit,'role':a.role,'scenario':a.scenario,'expected_build':next_build,'queue_url':response.headers['Location'],'http':response.status,'submitted_utc':datetime.now(timezone.utc).isoformat()}
(out/'launch.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
