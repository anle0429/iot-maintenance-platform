"""Verify a specific terminal Jenkins build against its actual OPA decision, native deployment state and original launch identity."""
from pathlib import Path
from datetime import datetime,timezone
from urllib.request import build_opener,ProxyHandler,Request
import argparse,base64,json,re,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--tag',required=True);a=p.parse_args();assert re.fullmatch('[a-z0-9-]{1,40}',a.tag)
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');trigger=root/'outputs'/('agent-policy-ci-trigger-'+a.tag);launch=json.loads((trigger/'launch.json').read_bytes())
role=launch['role'];build=launch['expected_build'];private=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());token=private['admin_password'].encode();auth='Basic '+base64.b64encode(b'learner:'+token).decode();client=build_opener(ProxyHandler({}))
def call(path):
 with client.open(Request('http://127.0.0.1:18787'+path,headers={'Authorization':auth}),timeout=35) as response:
  raw=response.read(3000000);assert len(raw)<3000000 and token not in raw and auth.encode() not in raw;return raw
job='/job/iot-llm-'+role+'/'+str(build);raw=call(job+'/api/json');value=json.loads(raw)
if value['building']:print(json.dumps({'live_build':True,'role':role,'build':build,'result':None}));sys.exit(0)
params={v['name']:v['value'] for action in value['actions'] for v in action.get('parameters',[])}
assert params['SOURCE_COMMIT']==launch['source_commit'] and params['ADMISSION_SCENARIO']==launch['scenario']
out=root/'outputs'/('agent-policy-ci-finish-'+a.tag);out.mkdir(exist_ok=False);(out/'build.json').write_bytes(raw)
console=call(job+'/consoleText');(out/'console.txt').write_bytes(console);stages=json.loads(call(job+'/wfapi/describe'));(out/'stages.json').write_text(json.dumps(stages,indent=2)+'\n')
release=root/'data/ci/releases'/('llm-'+role+'-jenkins-'+str(build))/'outputs'
decision=json.loads((release/'policy-decision/verification.json').read_bytes());assert decision['gate_exit']==(0 if decision['allowed'] else 1)
k=['/usr/local/bin/k3s','kubectl'];helm=[str(root/'data/runtime/kubernetes-assets-27/helm/helm'),'--kubeconfig','/etc/rancher/k3s/k3s.yaml']
def get(*args):return json.loads(subprocess.check_output(k+['get',*args,'-o','json'],timeout=30,stderr=subprocess.PIPE))
after={name:get(name,'-n','iot-agents') for name in ['sandboxagents','modelconfigs','remotemcpservers','workerpools','deployments']}
(out/'resources-after.json').write_text(json.dumps(after,indent=2)+'\n');revisions={}
for name in ['iot-agents','iot-retrieval-mcp','iot-drift-mcp']:revisions[name]=json.loads(subprocess.check_output(helm+['history',name,'-n','iot-agents','--max','1','-o','json'],timeout=30))
(out/'helm-after.json').write_text(json.dumps(revisions,indent=2)+'\n')
gpu=get('service','iot-model-gpu','-n','iot-llm')['spec']['clusterIP']
with build_opener(ProxyHandler({})).open('http://'+gpu+':8080/metrics?model=iot-qwen2.5-7b',timeout=20) as response:metrics=response.read()
(out/'model-after.prom').write_bytes(metrics)
def generated(raw):
 lines=[v for v in raw.decode().splitlines() if v.startswith('llamacpp:tokens_predicted_total ')];assert len(lines)==1;return float(lines[0].split()[-1])
generated_delta=generated(metrics)-generated((trigger/'model-before.prom').read_bytes())
if launch['scenario']=='unsafe-tool':
 assert value['result']=='FAILURE' and decision['allowed'] is False and decision['violations']==['unapproved capability or missing required field: SandboxAgent/iot-retrieval']
 assert any(v['name']=='Admit model tools and sandbox with OPA' and v['status']=='FAILED' for v in stages['stages'])
 for name in ['policy.json','deployment-plan.json','deploy.json','verify.json','admitted-deploy-host.attempt']:assert not (release/name).exists(),name
 before=json.loads((trigger/'resources-before.json').read_bytes())
 def identities(rows):return {v['metadata']['name']:{'uid':v['metadata']['uid'],'spec':v['spec']} for v in rows['items']}
 assert all(identities(before[name])==identities(after[name]) for name in before)
 assert json.loads((trigger/'helm-before.json').read_bytes())==revisions and generated_delta==0
 scope='Intentional unsafe-tool candidate denied by actual OPA exit1; no deployment stage, unchanged Helm revisions/resource UIDs/specs and zero new GPU output tokens.'
else:
 assert value['result']=='SUCCESS' and decision['allowed'] is True
 for name in ['test.json','build.json','policy.json','deploy.json','verify.json','retained-experiments.json']:assert json.loads((release/name).read_bytes())['passed'],name
 recheck=json.loads((release/'policy-recheck-decision/verification.json').read_bytes());assert recheck['allowed'] and recheck['input_sha256']==decision['input_sha256']
 assert generated_delta>0;scope='Actual production agent release passed OPA, exact-input recheck, deployment and real tool-grounded answer verification; retained A/B resource identities/specs unchanged.'
report={'passed':True,'checked_utc':datetime.now(timezone.utc).isoformat(),'role':role,'build':build,'scenario':launch['scenario'],'source_commit':launch['source_commit'],
 'jenkins_result':value['result'],'policy_allowed':decision['allowed'],'policy_gate_exit':decision['gate_exit'],'native_generated_token_delta':generated_delta,'scope':scope}
(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
