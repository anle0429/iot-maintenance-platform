"""Stage the corrected truth-constraint query as a distinct source/run; preserve failed native suite A."""
from pathlib import Path,PurePosixPath
from hashlib import sha256
from io import BytesIO
import argparse,json,subprocess,tarfile
p=argparse.ArgumentParser();p.add_argument('--packet',type=Path,required=True);p.add_argument('--sha256',required=True);a=p.parse_args()
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');raw=a.packet.read_bytes();assert len(raw)<1000000 and sha256(raw).hexdigest()==a.sha256;members={}
with tarfile.open(fileobj=BytesIO(raw)) as t:
 for m in t:
  n=PurePosixPath(m.name);assert m.isfile() and not n.is_absolute() and '..' not in n.parts and m.name not in members;members[m.name]=t.extractfile(m).read()
seal=json.loads(members['manifest.json']);assert seal['format']=='iot-agent-admission-source-v1' and len(seal['files'])==9
assert set(members)=={'manifest.json'}|{'tree/'+n for n in seal['files']}
for n,pin in seal['files'].items():assert sha256(members['tree/'+n]).hexdigest()==pin
dest=root/'data/llm-source'/('agent-admission-'+seal['commit'][:8]);dest.mkdir(exist_ok=False)
for n,v in members.items():target=dest/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(v)
out=root/'outputs/agent-admission-stage-30b';out.mkdir(exist_ok=False)
r=subprocess.run(['/usr/bin/python3','-B','-m','unittest','discover','-s','tests','-p','test_agent_admission.py','-v'],cwd=dest/'tree',capture_output=True,timeout=30)
(out/'tests.stdout').write_bytes(r.stdout);(out/'tests.stderr').write_bytes(r.stderr);(out/'tests.exit').write_text(str(r.returncode)+'\n');assert r.returncode==0
unit='iot-agent-admission-contracts-30b';target=root/'outputs/agent-admission-contracts-30b';assert not target.exists()
subprocess.run(['systemd-run','--unit='+unit,'--property=RuntimeMaxSec=600','--property=MemoryMax=512M','--property=CPUQuota=100%',
 '/usr/bin/python3','-B',str(dest/'tree/scripts/check-agent-admission.py'),'--opa',str(root/'data/runtime/policy-assets-28/opa'),'--output',str(target),'--source-manifest',str(dest/'manifest.json')],check=True)
identity=subprocess.check_output(['systemctl','show',unit,'-p','InvocationID','-p','ActiveState','-p','Result'],text=True)
with (root/'outputs/agent-admission-contracts-launch-30b.txt').open('x') as stream:stream.write(identity)
print(identity)
