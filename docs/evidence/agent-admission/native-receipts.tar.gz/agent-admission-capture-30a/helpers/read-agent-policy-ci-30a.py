"""Observe one existing Jenkins build without restarting or resubmitting it; retain original bounded metadata and console snapshots."""
from pathlib import Path
from datetime import datetime,timezone
from urllib.request import build_opener,ProxyHandler,Request
import argparse,base64,json,re
p=argparse.ArgumentParser();p.add_argument('--role',choices=['retrieval','drift','coordinator'],required=True);p.add_argument('--build',type=int,required=True);p.add_argument('--tag',required=True);a=p.parse_args();assert re.fullmatch('[a-z0-9-]{1,40}',a.tag) and a.build>0
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');private=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());token=private['admin_password'].encode();auth='Basic '+base64.b64encode(b'learner:'+token).decode();client=build_opener(ProxyHandler({}));out=root/'outputs'/('agent-policy-ci-read-'+a.tag);out.mkdir(exist_ok=False)
def read(path):
 with client.open(Request('http://127.0.0.1:18787'+path,headers={'Authorization':auth}),timeout=35) as response:
  raw=response.read(3000000);assert len(raw)<3000000 and token not in raw and auth.encode() not in raw;return raw
job='/job/iot-llm-'+a.role+'/'+str(a.build);metadata=read(job+'/api/json');(out/'build.json').write_bytes(metadata);value=json.loads(metadata)
console=read(job+'/consoleText');(out/'console.txt').write_bytes(console)
stages=read(job+'/wfapi/describe');(out/'stages.json').write_bytes(stages)
report={'checked_utc':datetime.now(timezone.utc).isoformat(),'role':a.role,'build':a.build,'building':value['building'],'result':value['result'],
 'last_console_lines':console.decode().splitlines()[-9:]}
(out/'observation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
