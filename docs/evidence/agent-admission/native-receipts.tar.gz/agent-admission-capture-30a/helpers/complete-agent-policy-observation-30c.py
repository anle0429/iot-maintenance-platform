"""Preserve the original read-only observation bytes and record the supported OPA version command without repeating Kubernetes reads."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,os,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');prior=root/'outputs/agent-policy-observed-30b';out=root/'outputs/agent-policy-observed-30c';os.umask(0o077);out.mkdir(exist_ok=False)
files=['sandboxagents.json','modelconfigs.json','remotemcpservers.json','workerpools.json','networkpolicies.json','scaledobjects.json','rendered-manifest.txt','values.txt','opa-assets.json']
inventory={}
for name in files:
 path=prior/name;raw=path.read_bytes();(out/name).write_bytes(raw);inventory[name]={'sha256':sha256(raw).hexdigest(),'original_observed_file_mtime_utc':datetime.fromtimestamp(path.stat().st_mtime,timezone.utc).isoformat()}
pin=json.loads((out/'opa-assets.json').read_bytes());binary=root/'data/runtime/policy-assets-28/opa';assert binary.stat().st_size==pin['bytes'] and sha256(binary.read_bytes()).hexdigest()==pin['sha256']
version=subprocess.check_output([str(binary),'version'],timeout=10);assert ('Version: '+pin['version']).encode() in version;(out/'opa-version.txt').write_bytes(version)
(out/'observation.json').write_text(json.dumps({'checked_utc':datetime.now(timezone.utc).isoformat(),'original_read_directory':str(prior),'original_files':inventory,
 'opa_binary':str(binary),'opa_sha256':pin['sha256'],'deployment_changes':0,'model_requests':0,
 'predecessors':'A read resources then lacked the public lock in the old runtime checkout. B authenticated the explicit lock/binary but its unsupported version --format flag failed. C keeps B original resource bytes and uses actual supported opa version.'},indent=2)+'\n')
archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'x:gz') as t:t.add(out,arcname=out.name)
archive.chmod(0o644);print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest()}))
