"""Read actual Jenkins parameter shapes before any job mutation; preserve private original configurations without printing values."""
from pathlib import Path
from urllib.request import build_opener,ProxyHandler,Request
import base64,json,os,xml.etree.ElementTree as ET
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');os.umask(0o077);out=root/'outputs/agent-policy-job-inspection-30a';out.mkdir(exist_ok=False)
private=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());auth='Basic '+base64.b64encode(('learner:'+private['admin_password']).encode()).decode();opener=build_opener(ProxyHandler({}));rows=[]
for role in ['retrieval','drift','coordinator']:
 with opener.open(Request('http://127.0.0.1:18787/job/iot-llm-'+role+'/config.xml',headers={'Authorization':auth}),timeout=30) as response:raw=response.read()
 (out/(role+'.xml')).write_bytes(raw);config=ET.fromstring(raw)
 rows.append({'role':role,'properties':[v.tag for v in config.findall('properties/*')],
  'parameter_nodes':[{'tag':v.tag,'name':v.findtext('name'),'children':[c.tag for c in v]} for v in config.findall('.//parameterDefinitions/*')]})
(out/'projection.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
