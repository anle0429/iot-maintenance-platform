"""Stage the complete source and update only three idle owned Jenkins job definitions to the OPA-gated procedure; do not start a build."""
from pathlib import Path,PurePosixPath
from hashlib import sha256
from io import BytesIO
from copy import deepcopy
from urllib.request import ProxyHandler,Request,HTTPCookieProcessor,build_opener
from urllib.parse import urlencode
from http.cookiejar import CookieJar
from datetime import datetime,timezone
import argparse,base64,json,subprocess,tarfile,xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('--packet',type=Path,required=True);p.add_argument('--sha256',required=True);a=p.parse_args()
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');raw=a.packet.read_bytes();assert len(raw)==636748 and sha256(raw).hexdigest()==a.sha256=='aa92dba9a89dcc1cbead786c6bd920ab51c71a09166bf88aa8b2e0ef2b6207fa'
members={}
with tarfile.open(fileobj=BytesIO(raw)) as t:
 for m in t:
  n=PurePosixPath(m.name);assert m.isfile() and not n.is_absolute() and '..' not in n.parts and m.name not in members;members[m.name]=(t.extractfile(m).read(),m.mode)
seal=json.loads(members['manifest.json'][0]);assert seal['format']=='iot-sealed-llm-ci-v1' and len(seal['files'])==375 and seal['commit']=='388632450333af8c8f7cc925486c88f9c101c233'
assert set(members)=={'manifest.json'}|{'tree/'+n for n in seal['files']}
for n,pin in seal['files'].items():assert sha256(members['tree/'+n][0]).hexdigest()==pin
dest=root/'data/llm-source'/('ci-policy-'+seal['commit']);link=root/'data/ci/source'/seal['commit'];assert not dest.exists() and not link.exists();dest.mkdir()
for n,(body,mode) in members.items():target=dest/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body);target.chmod(mode)
link.symlink_to(dest,target_is_directory=True);out=root/'outputs/agent-policy-ci-stage-30a';out.mkdir(exist_ok=False)
result=subprocess.run(['/usr/bin/python3','-B','-m','unittest','tests.test_agent_admission','tests.test_agent_admission_ci','-v'],cwd=dest/'tree',capture_output=True,timeout=30)
(out/'tests.stdout').write_bytes(result.stdout);(out/'tests.stderr').write_bytes(result.stderr);assert result.returncode==0
secret=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());token=secret['admin_password'].encode()
authorization='Basic '+base64.b64encode(b'learner:'+token).decode();client=build_opener(ProxyHandler({}),HTTPCookieProcessor(CookieJar()))
def call(path,body=None,extra=None):
 with client.open(Request('http://127.0.0.1:18787'+path,data=body,headers={'Authorization':authorization,**(extra or {})}),timeout=40) as response:return response.read()
old_script=(dest/'tree/infra/ci/Agents.Jenkinsfile').read_text();new_script=(dest/'tree/infra/ci/AgentsPolicy.Jenkinsfile').read_text();original={}
for role in ['retrieval','drift','coordinator']:
 job='/job/iot-llm-'+role;state=json.loads(call(job+'/api/json?tree=inQueue,lastBuild[number,building,result]'))
 assert not state['inQueue'] and not state['lastBuild']['building'];body=call(job+'/config.xml');config=ET.fromstring(body)
 assert config.find('definition/script').text==old_script and config.findtext('definition/sandbox')=='true'
 params=config.findall('properties/hudson.model.ParametersDefinitionProperty/parameterDefinitions/*')
 assert len(params)==1 and params[0].findtext('name')=='SOURCE_COMMIT';original[role]=body;(out/(role+'-before.xml')).write_bytes(body)
crumb=json.loads(call('/crumbIssuer/api/json'));headers={crumb['crumbRequestField']:crumb['crumb'],'Content-Type':'application/x-www-form-urlencoded'}
payload={'names':['iot-llm-'+r for r in ['retrieval','drift','coordinator']],'commit':seal['commit'],'old_script':old_script,'script':new_script}
encoded=base64.b64encode(json.dumps(payload).encode()).decode()
script='''import jenkins.model.Jenkins
import hudson.model.ParametersDefinitionProperty
import hudson.model.StringParameterDefinition
import hudson.model.ChoiceParameterDefinition
import org.jenkinsci.plugins.workflow.cps.CpsFlowDefinition
import groovy.json.JsonSlurper
def input=new JsonSlurper().parseText(new String('ENCODED'.decodeBase64(),'UTF-8'))
def instance=Jenkins.get()
if(instance.numExecutors!=1) throw new IllegalStateException('Preserve one executor')
input.names.each { name ->
 def job=instance.getItem(name)
 if(job==null || job.isBuilding() || job.isInQueue() || job.definition.script!=input.old_script) throw new IllegalStateException('Preserve changed or active owned job')
}
input.names.each { name ->
 def job=instance.getItem(name)
 job.setDefinition(new CpsFlowDefinition(input.script,true))
 job.removeProperty(ParametersDefinitionProperty)
 job.addProperty(new ParametersDefinitionProperty(new StringParameterDefinition('SOURCE_COMMIT',input.commit,'Exact trusted source prepared on this lab VM'),new ChoiceParameterDefinition('ADMISSION_SCENARIO',['production','unsafe-tool'] as String[],'Synthetic denial must stop before deployment')))
 job.save()
}
println('UPDATED_ONLY_THREE_IDLE_AGENT_JOBS_WITH_OPA')
'''.replace('ENCODED',encoded)
ack=call('/scriptText',urlencode({'script':script}).encode(),headers);(out/'job-update.stdout').write_bytes(ack);assert b'UPDATED_ONLY_THREE_IDLE_AGENT_JOBS_WITH_OPA' in ack
def normalize(element):
 for node in element.iter():
  if node.text is not None and not node.text.strip():node.text=None
  node.tail=None
 return ET.tostring(element)
for role,body in original.items():
 actual_raw=call('/job/iot-llm-'+role+'/config.xml');(out/(role+'-after.xml')).write_bytes(actual_raw);actual=ET.fromstring(actual_raw);before=ET.fromstring(body)
 assert actual.find('definition/script').text==new_script and actual.findtext('definition/sandbox')=='true'
 params=actual.findall('properties/hudson.model.ParametersDefinitionProperty/parameterDefinitions/*');assert {v.findtext('name') for v in params}=={'SOURCE_COMMIT','ADMISSION_SCENARIO'}
 actual.find('definition/script').text=before.find('definition/script').text
 prop=actual.find('properties');prop.remove(prop.find('hudson.model.ParametersDefinitionProperty'));prop.append(deepcopy(before.find('properties/hudson.model.ParametersDefinitionProperty')))
 # Property order can move only for the parameter property changed above; preserve all others structurally.
 prior=before.find('properties');old_params=prior.find('hudson.model.ParametersDefinitionProperty');prior.remove(old_params);prior.append(old_params)
 assert normalize(actual)==normalize(before),'An unrelated job field changed'
for path in out.rglob('*'):
 if path.is_file():assert token not in path.read_bytes() and authorization.encode() not in path.read_bytes()
report={'passed':True,'checked_utc':datetime.now(timezone.utc).isoformat(),'source_commit':seal['commit'],'source_files':375,'jobs_updated':3,
 'only_pipeline_and_declared_parameters_changed':True,'builds_started':0,'original_script_preserved_in_source':True}
(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
