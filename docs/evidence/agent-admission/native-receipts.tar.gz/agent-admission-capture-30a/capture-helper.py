"""Seal original OPA suites, three production pipelines and the actual controlled denial without another model or deployment run."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from urllib.parse import quote
import base64,json,os,re,subprocess,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/agent-admission-capture-30a';os.umask(0o077);out.mkdir(exist_ok=False);private=[]
assert json.loads((root/'outputs/agent-policy-production-30a/verification.json').read_bytes())['passed']
def credential(raw):
 if isinstance(raw,str):raw=raw.encode()
 if len(raw)>=12:
  private.append(raw)
  if raw.startswith(b'Bearer '):private.append(raw[7:])
def walk(value,key=''):
 if isinstance(value,dict):
  if value.get('name')=='Authorization' and isinstance(value.get('value'),str):credential(value['value'])
  if {'username','password'}<=set(value):credential(base64.b64encode((value['username']+':'+value['password']).encode()))
  for name,child in value.items():walk(child,name)
 elif isinstance(value,list):
  for child in value:walk(child,key)
 elif isinstance(value,str) and re.search('password|token|apikey|secretid|roleid|keysbase64|authorization',re.sub('[^a-z]','',key.lower())):credential(value)
paths=[root/'data/runtime/secrets'/n for n in ['agent-platform.json','mcp-tools.json']]
paths.extend(root/'data/runtime/agent-vault-29a-private'/n for n in ['gateway-credentials.json','gateway-approle.json','services-approle.json'])
paths.extend([root/'data/runtime/agent-gateway-29a-private/credentials.json',root/'data/runtime/gateway-28-private/credentials.json',root/'data/runtime/ci/jenkins-private/bootstrap.json'])
paths.extend(root/'data/runtime/vault-28-private'/n for n in ['ci-approle.json','gateway-approle.json','bootstrap.json'])
for path in paths:walk(json.loads(path.read_bytes()))
jenkins=json.loads((root/'data/runtime/ci/jenkins-private/bootstrap.json').read_bytes());credential(base64.b64encode(('learner:'+jenkins['admin_password']).encode()));jenkins=None
credential((root/'data/runtime/llm-monitoring-29a/auth/token').read_bytes().strip())
k=['/usr/local/bin/k3s','kubectl'];refs={('iot-llm','iot-llm-observer-client','API_KEY'),('iot-agents','iot-local-model-client','API_KEY')}
def get(*args):return json.loads(subprocess.check_output(k+['get',*args,'-o','json'],timeout=30,stderr=subprocess.PIPE))
for deployment in get('deployments','-n','iot-agents')['items']:
 for container in deployment['spec']['template']['spec']['containers']:
  for item in container.get('env',[]):
   ref=item.get('valueFrom',{}).get('secretKeyRef')
   if ref and re.search('password|token|key|auth',ref['key'],re.I):refs.add(('iot-agents',ref['name'],ref['key']))
for remote in get('remotemcpservers','-n','iot-agents')['items']:
 for header in remote['spec'].get('headersFrom',[]):
  ref=header.get('valueFrom',{})
  if ref.get('type')=='Secret':refs.add(('iot-agents',ref['name'],ref['key']))
for namespace,name,key in sorted(refs):
 secret=get('secret',name,'-n',namespace);credential(base64.b64decode(secret['data'][key]));secret=None
private=list({v for raw in private for v in [raw,base64.b64encode(raw),base64.b64encode(b'Bearer '+raw),quote(raw.decode(),safe='').encode()]})
def keep(name,body):
 assert len(body)<10000000 and not any(v in body for v in private),name
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
def copy(label,folder):
 assert folder.is_dir(),folder
 for parent,dirs,files in os.walk(folder):
  dirs[:]=[v for v in dirs if v!='__pycache__']
  for name in sorted(files):
   p=Path(parent)/name;assert not p.is_symlink();keep(label+'/'+p.relative_to(folder).as_posix(),p.read_bytes())
folders=['agent-policy-observed-30a','agent-policy-observed-30b','agent-policy-observed-30c','agent-policy-job-inspection-30a',
 'agent-admission-stage-30a','agent-admission-stage-30b','agent-admission-contracts-30a','agent-admission-contracts-30b',
 'agent-policy-ci-stage-30a','agent-policy-ci-stage-30b','feature-policy-30a','agent-policy-production-30a',
 'agent-policy-ci-trigger-negative-30a','agent-policy-ci-finish-negative-30a','agent-policy-ci-read-negative-30a']
for role in ['coordinator','retrieval','drift']:folders.extend(['agent-policy-ci-trigger-production-'+role+'-30a','agent-policy-ci-finish-production-'+role+'-30a'])
for name in folders:copy('native/'+name,root/'outputs'/name)
for name in ['agent-admission-b8251dec','agent-admission-727cb6db','ci-policy-388632450333af8c8f7cc925486c88f9c101c233','ci-policy-beb7f5c7dbec14e8429a0877c87eb17e6c901b7b']:
 copy('source/'+name,root/'data/llm-source'/name)
for role,build in [('coordinator',4),('coordinator',5),('retrieval',5),('drift',5)]:
 release='llm-'+role+'-jenkins-'+str(build);copy('ci/'+release,root/'data/ci/releases'/release/'outputs')
for unit in ['iot-agent-admission-contracts-30a','iot-agent-admission-contracts-30b','iot-feature-policy-30a','iot-agent-policy-production-30a']:
 for label,argv in [('unit',['systemctl','show',unit]),('journal',['journalctl','-u',unit,'--no-pager','-o','json'])]:
  result=subprocess.run(argv,capture_output=True,timeout=30);assert result.returncode==0;keep('units/'+unit+'/'+label+'.stdout',result.stdout)
for name in ['agent-admission-contracts-launch-30a.txt','agent-admission-contracts-launch-30b.txt']:keep('launch/'+name,(root/'outputs'/name).read_bytes())
for name in ['stage-agent-admission-30a.py','stage-agent-admission-30b.py','observe-agent-policy-30a.py','observe-agent-policy-30b.py','complete-agent-policy-observation-30c.py',
 'stage-agent-policy-ci-30a.py','stage-agent-policy-ci-30b.py','inspect-agent-policy-jobs-30a.py','trigger-agent-policy-ci-30a.py','read-agent-policy-ci-30a.py','finish-agent-policy-ci-30a.py','run-agent-policy-production-30a.py','iot-refresh-demo-feature-29k.py']:
 keep('helpers/'+name,(Path('/tmp')/name).read_bytes())
for name in ['model-pin.json','portable.json']:keep('models/'+name,(root/'data/ci/releases/serve-jenkins-8/bundle'/name).read_bytes())
keep('gpu-session.json',(root/'data/runtime/ci/gpu-session.json').read_bytes())
keep('capture-notes.json',(json.dumps({'workloads_rerun_for_capture':False,'new_model_requests_for_capture':0,'current_native_credentials_scanned':True,
 'suite_a':'Explicit allowedfalse disagreed with exit0 from a defined comparison result; wrapper stopped before deployment. Originals retained. B uses unification and all70cases pass with actual exit0/1.',
 'stage_a':'Source375 was authenticated and4tests passed. Preflight failed on actual Jenkins parameterDefinitions/a XML wrapper before changing any job. B verified only owned pipeline/parameters changed and5tests passed.',
 'negative_ci':'Coordinator4 intentionally FAILS at OPA. Downstream stage boxes may inherit a red status; console says skipped, no deployment attempt/plan/success receipt exists, all resource identities/specs/Helm histories unchanged and zero generated tokens.',
 'production_ci':'Coordinator5,retrieval5,drift5 are distinct actual SUCCESS builds with admitted complete agent inputs, immediate rechecks, deployment and real answers. Original A/B experiment resources remain unchanged.',
 'omissions':'No runtime Secret data, credential files, weights, bulk data, image-export archives or cloud bootstrap metadata. Native execution evidence is unchanged.'},indent=2)+'\n').encode())
keep('capture-helper.py',Path(__file__).read_bytes());manifest={'captured_utc':datetime.now(timezone.utc).isoformat(),'current_native_credentials_scanned':True,
 'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()}}
keep('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode());archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'x:gz') as t:t.add(out,arcname=out.name)
archive.chmod(0o644);receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'payloads':len(manifest['files']),'inventory_sha256':sha256((out/'manifest.json').read_bytes()).hexdigest()}
target=root/'outputs/agent-admission-capture-receipt-30a.json';target.write_text(json.dumps(receipt,indent=2)+'\n');target.chmod(0o644);print(json.dumps(receipt))
