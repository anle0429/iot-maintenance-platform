"""Supplement the original credential scan with explicit current Vault root/unseal encodings; keep all native execution bytes unchanged."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from urllib.parse import quote
import base64,json,os,tarfile
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');base=root/'outputs/agent-admission-capture-30a';archive=base.with_suffix('.tar.gz')
assert sha256(archive.read_bytes()).hexdigest()=='b3ccb40c0eada0b100a1cc2a6dca53f3aed5708d1c5c09475b81a8f1ba842a0b'
raw=(base/'manifest.json').read_bytes();assert sha256(raw).hexdigest()=='e316d716e2bea127c327f05b965a1150fa2f0ab6b3b430e53e5485751d98e917';inventory=json.loads(raw)
private=json.loads((root/'data/runtime/vault-28-private/bootstrap.json').read_bytes());values=[private['root_token'],*private['keys_base64']]
patterns={v for value in values for v in [value.encode(),base64.b64encode(value.encode()),base64.b64encode(('Bearer '+value).encode()),quote(value,safe='').encode()]}
assert len(inventory['files'])==1833
for name,pin in inventory['files'].items():
 body=(base/name).read_bytes();assert len(body)==pin['bytes'] and sha256(body).hexdigest()==pin['sha256'] and not any(v in body for v in patterns),name
os.umask(0o077);out=root/'outputs/agent-admission-vault-scan-30a';out.mkdir(exist_ok=False)
report={'passed':True,'checked_utc':datetime.now(timezone.utc).isoformat(),'original_archive_sha256':sha256(archive.read_bytes()).hexdigest(),
 'original_inventory_sha256':sha256(raw).hexdigest(),'native_payloads_scanned':1833,'current_vault_root_and_unseal_values_scanned':len(values),
 'native_execution_files_changed':False,'scope':'Supplemental explicit Vault root/unseal scan. The original capture scan normalized field names by dropping digits, so its keysbase64 matcher did not include unseal values. This separate actual scan covers those encodings without rewriting or recapturing original execution evidence.'}
(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n');(out/'source.py').write_bytes(Path(__file__).read_bytes());packet=out.with_suffix('.tar.gz')
with tarfile.open(packet,'x:gz') as t:t.add(out,arcname=out.name)
packet.chmod(0o644);receipt={'archive':str(packet),'bytes':packet.stat().st_size,'sha256':sha256(packet.read_bytes()).hexdigest()}
target=root/'outputs/agent-admission-vault-scan-receipt-30a.json';target.write_text(json.dumps(receipt,indent=2)+'\n');target.chmod(0o644);print(json.dumps(receipt))
