"""Export official coverage.py HTML from the unchanged real CI database without rerunning tests or mutations."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
from hashlib import sha256
import json,os,re,shutil,subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');source=root/'data/ci/releases/llm-retrieval-jenkins-5/outputs'
session=json.loads((root/'data/runtime/ci/session.json').read_bytes())
assert datetime.fromisoformat(session['auto_stop_utc'])-datetime.now(timezone.utc)>timedelta(minutes=15)
out=root/'outputs/mcp-quality-ui-export-30a';out.mkdir();os.chown(out,10001,10001)
(out/'operator.py').write_bytes(Path(__file__).read_bytes())
old=(source/'api-tests/.coverage').read_bytes();original=json.loads((source/'api-tests/coverage.json').read_bytes())
for name in ['.coverage','coverage.json','junit.xml']:
 p=out/name;p.write_bytes((source/'api-tests'/name).read_bytes());os.chown(p,10001,10001)
tested=json.loads((source/'test-image.json').read_bytes());image=tested['image_id'];assert re.fullmatch(r'sha256:[0-9a-f]{64}',image)
(out/'test-image.json').write_text(json.dumps(tested,indent=2)+'\n')
command=['docker','run','--name','iot-mcp-quality-html-30a','--read-only','--network','none','--memory','512m','--memory-swap','512m','--cpus','.5','--pids-limit','128','--cap-drop','ALL','--security-opt','no-new-privileges',
 '--tmpfs','/tmp:rw,nosuid,size=64m','--mount','type=bind,src='+str(out)+',dst=/proof','--entrypoint','python',image,'-B','-m','coverage','html','--data-file=/proof/.coverage','-d','/proof/html']
result=subprocess.run(command,capture_output=True,timeout=120);(out/'html-console.txt').write_bytes(result.stdout+result.stderr);assert result.returncode==0
actual=json.loads(subprocess.check_output(['docker','inspect','iot-mcp-quality-html-30a']))[0]
(out/'container.json').write_text(json.dumps({'id':actual['Id'],'image':actual['Image'],'state':actual['State'],'user':actual['Config']['User'],'memory':actual['HostConfig']['Memory'],'network':actual['HostConfig']['NetworkMode']},indent=2)+'\n')
assert not actual['State']['OOMKilled'] and actual['State']['ExitCode']==0 and actual['Config']['User']=='10001:10001'
command=['docker','run','--name','iot-mcp-quality-json-30a','--read-only','--network','none','--memory','256m','--memory-swap','256m','--cpus','.5','--cap-drop','ALL','--security-opt','no-new-privileges',
 '--tmpfs','/tmp:rw,nosuid,size=64m','--mount','type=bind,src='+str(out)+',dst=/proof','--entrypoint','python',image,'-B','-m','coverage','json','--data-file=/proof/.coverage','-o','/proof/coverage-export.json']
result=subprocess.run(command,capture_output=True,timeout=90);(out/'json-console.txt').write_bytes(result.stdout+result.stderr);assert result.returncode==0
exported=json.loads((out/'coverage-export.json').read_bytes());assert exported['totals']==original['totals'] and exported['files']==original['files']
sources=out/'source';sources.mkdir()
for remote,name in [('/tests/mcp/test_tools.py','test_tools.py'),('/tests/mcp/test_contract_edges.py','test_contract_edges.py'),('/tests/mcp/test_decision_boundaries.py','test_decision_boundaries.py'),('/workspace/services/mcp_tools/app.py','app.py')]:
 subprocess.run(['docker','cp','iot-mcp-quality-html-30a:'+remote,str(sources/name)],check=True,capture_output=True,timeout=30)
assert (source/'api-tests/.coverage').read_bytes()==old
report={'passed':True,'checked_utc':datetime.now(timezone.utc).isoformat(),'job':'iot-llm-retrieval','build':5,'source_database_sha256':sha256(old).hexdigest(),
 'image_id':image,'original_totals':original['totals'],'report_totals_and_files_unchanged':True,'tests_rerun':False,'mutations_rerun':False,
 'source_sha256':{p.name:sha256(p.read_bytes()).hexdigest() for p in sources.iterdir()},'scope':'Official coverage HTML/JSON re-export from the original successful CI database and same immutable test image. Source readback is from that exact image. No test, model, deployment or mutation workload rerun.'}
(out/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
