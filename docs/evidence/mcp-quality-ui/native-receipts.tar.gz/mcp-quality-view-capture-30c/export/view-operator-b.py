"""Use an existing native unprivileged account for the same immutable report after preserving the failed host-UID launch."""
from pathlib import Path
from hashlib import sha256
import json,pwd,grp,subprocess,socket
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/mcp-quality-ui-export-30a'
proof=json.loads((out/'verification.json').read_bytes());assert proof['passed']
failed=subprocess.check_output(['systemctl','show','iot-mcp-quality-view-30a','-p','InvocationID','-p','ActiveState','-p','Result','-p','ExecMainStatus'])
(out/'view-failed-unit.txt').write_bytes(failed);assert b'ExecMainStatus=217' in failed and b'ActiveState=failed' in failed
(out/'view-failed-journal.txt').write_bytes(subprocess.check_output(['journalctl','-u','iot-mcp-quality-view-30a','--no-pager','-o','short-iso']))
user=pwd.getpwnam('nobody');group=grp.getgrnam('nogroup');assert user.pw_uid==65534 and group.gr_gid==65534
readable=subprocess.run(['runuser','-u','nobody','--','python3','-B','-c','from pathlib import Path; p=Path('+repr(str(out/'html/index.html'))+'); assert p.is_file() and p.read_bytes(); print("Original report readable by existing native account")'],capture_output=True,timeout=15)
(out/'view-readability.txt').write_bytes(readable.stdout+readable.stderr);assert readable.returncode==0
for name,pin in proof['source_sha256'].items():assert sha256((out/'source'/name).read_bytes()).hexdigest()==pin
with socket.socket() as sock:sock.bind(('127.0.0.1',21948))
cmd=['systemd-run','--unit=iot-mcp-quality-view-30b','--uid=nobody','--gid=nogroup','--property=NoNewPrivileges=yes',
 '--property=ProtectSystem=strict','--property=ProtectHome=yes','--property=PrivateTmp=yes','--property=RuntimeMaxSec=3600',
 'python3','-B','-m','http.server','21948','--bind','127.0.0.1','--directory',str(out)]
r=subprocess.run(cmd,capture_output=True,timeout=30);(out/'view-launch-b.txt').write_bytes(r.stdout+r.stderr);assert r.returncode==0
(out/'view-unit-b.txt').write_bytes(subprocess.check_output(['systemctl','show','iot-mcp-quality-view-30b','-p','InvocationID','-p','ActiveState','-p','User','-p','Group','-p','RuntimeMaxUSec']))
(out/'view-operator-b.py').write_bytes(Path(__file__).read_bytes());print((out/'view-unit-b.txt').read_text())
