"""Expose only the already exported official coverage and source bytes on a bounded loopback report server."""
from pathlib import Path
from hashlib import sha256
import json,socket,subprocess
root=Path('/srv/iot-data/workspace/iot-maintenance-platform');out=root/'outputs/mcp-quality-ui-export-30a'
proof=json.loads((out/'verification.json').read_bytes());assert proof['passed'] and not proof['tests_rerun'] and not proof['mutations_rerun']
aliases={}
for name,pin in proof['source_sha256'].items():
 original=out/'source'/name;assert sha256(original.read_bytes()).hexdigest()==pin
 alias=original.with_name(name+'.txt');assert not alias.exists();alias.write_bytes(original.read_bytes());aliases[name+'.txt']={'source':name,'sha256':pin}
(out/'source-browser-aliases.json').write_text(json.dumps({'scope':'Identical original source bytes with .txt suffix for the browser text/plain view. No code edits or synthetic screenshot.','files':aliases},indent=2)+'\n')
for p in out.rglob('*'):assert not p.is_symlink()
with socket.socket() as sock:sock.bind(('127.0.0.1',21948))
cmd=['systemd-run','--unit=iot-mcp-quality-view-30a','--uid=10001','--gid=10001','--property=NoNewPrivileges=yes','--property=ProtectSystem=strict',
 '--property=ProtectHome=yes','--property=PrivateTmp=yes','--property=RuntimeMaxSec=3600','--property=UMask=0022',
 'python3','-B','-m','http.server','21948','--bind','127.0.0.1','--directory',str(out)]
r=subprocess.run(cmd,capture_output=True,timeout=30);(out/'view-launch.txt').write_bytes(r.stdout+r.stderr);assert r.returncode==0
(out/'view-unit.txt').write_bytes(subprocess.check_output(['systemctl','show','iot-mcp-quality-view-30a','-p','InvocationID','-p','ActiveState','-p','RuntimeMaxUSec']))
(out/'view-operator.py').write_bytes(Path(__file__).read_bytes());print((out/'view-unit.txt').read_text())
